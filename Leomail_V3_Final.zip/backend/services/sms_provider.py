"""
Leomail v3 — SMS Provider
Abstract base + GrizzlySMS implementation.
SimSMS is in a separate file: simsms_provider.py
"""
import requests
from abc import ABC, abstractmethod
from loguru import logger


class SMSProvider(ABC):
    """Abstract SMS provider interface."""

    @abstractmethod
    def get_balance(self) -> float:
        ...

    @abstractmethod
    def order_number(self, service: str, country: str) -> dict:
        """Order a phone number. Returns {id, number} or {error}."""
        ...

    @abstractmethod
    def get_sms_code(self, order_id: str, timeout: int = 120) -> str | None:
        """Wait for and return SMS code, or None on timeout."""
        ...

    @abstractmethod
    def cancel_number(self, order_id: str) -> bool:
        """Cancel/release a number order."""
        ...


class GrizzlySMS(SMSProvider):
    """GrizzlySMS API — https://grizzlysms.com/"""

    BASE_URL = "https://api.grizzlysms.com/stubs/handler_api.php"

    def __init__(self, api_key: str):
        self.api_key = api_key

    def _request(self, action: str, **params) -> str:
        params["api_key"] = self.api_key
        params["action"] = action
        try:
            resp = requests.get(self.BASE_URL, params=params, timeout=15)
            return resp.text.strip()
        except Exception as e:
            logger.error(f"GrizzlySMS request error: {e}")
            return f"ERROR:{e}"

    def get_balance(self) -> float:
        result = self._request("getBalance")
        # Response: ACCESS_BALANCE:123.45
        if ":" in result:
            try:
                return float(result.split(":")[1])
            except ValueError:
                return 0.0
        return 0.0

    def order_number(self, service: str = "go", country: str = "0") -> dict:
        """
        Order a number.
        service: go=Google, ya=Yandex, ma=Mail.ru, mm=Microsoft
        country: 0=Russia, 1=Ukraine, etc.
        """
        result = self._request("getNumber", service=service, country=country)
        # Response: ACCESS_NUMBER:12345:79001234567
        if result.startswith("ACCESS_NUMBER"):
            parts = result.split(":")
            return {"id": parts[1], "number": parts[2]}
        return {"error": result}

    def get_sms_code(self, order_id: str, timeout: int = 120) -> str | None:
        """Poll for SMS code."""
        import time
        start = time.time()
        while time.time() - start < timeout:
            result = self._request("getStatus", id=order_id)
            if result.startswith("STATUS_OK"):
                # STATUS_OK:123456
                return result.split(":")[1]
            elif "STATUS_WAIT_CODE" in result:
                time.sleep(5)
                continue
            else:
                logger.warning(f"GrizzlySMS unexpected status: {result}")
                return None
        return None

    def cancel_number(self, order_id: str) -> bool:
        result = self._request("setStatus", id=order_id, status="8")
        return "ACCESS" in result
