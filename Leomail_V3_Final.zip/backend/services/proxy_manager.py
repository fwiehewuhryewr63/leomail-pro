"""
Leomail v3 — Proxy Manager
Import, rotate, and manage proxies with round-robin and GEO filtering.
1 proxy = 1 account (hard binding). Auto-reassign on proxy death.
"""
import random
from sqlalchemy.orm import Session
from loguru import logger
from ..models import Proxy, ProxyStatus, Account


class ProxyManager:
    """Manage proxy pool with rotation and account binding."""

    def __init__(self, db: Session):
        self.db = db
        self._rotation_index = 0

    def import_proxies(self, lines: list[str], proxy_type: str = "residential", geo: str = None) -> dict:
        """
        Parse and import proxy lines.
        Supported formats:
          host:port
          host:port:user:pass
          user:pass@host:port
          protocol://user:pass@host:port
        """
        added = 0
        skipped = 0

        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            parsed = self._parse_proxy_line(line)
            if not parsed:
                skipped += 1
                continue

            # Check duplicate
            existing = self.db.query(Proxy).filter(
                Proxy.host == parsed["host"],
                Proxy.port == parsed["port"],
            ).first()
            if existing:
                skipped += 1
                continue

            proxy = Proxy(
                host=parsed["host"],
                port=parsed["port"],
                username=parsed.get("username"),
                password=parsed.get("password"),
                protocol=parsed.get("protocol", "http"),
                proxy_type=proxy_type,
                geo=geo,
                status=ProxyStatus.ACTIVE,
            )
            self.db.add(proxy)
            added += 1

        self.db.commit()
        logger.info(f"Imported {added} proxies, skipped {skipped}")
        return {"added": added, "skipped": skipped}

    def _parse_proxy_line(self, line: str) -> dict | None:
        """Parse a single proxy line into components."""
        result = {"protocol": "http"}

        # Strip protocol prefix
        for proto in ["socks5://", "socks4://", "http://", "https://"]:
            if line.startswith(proto):
                result["protocol"] = proto.replace("://", "")
                line = line[len(proto):]
                break

        # user:pass@host:port
        if "@" in line:
            auth, server = line.rsplit("@", 1)
            parts = auth.split(":", 1)
            result["username"] = parts[0]
            result["password"] = parts[1] if len(parts) > 1 else ""
            server_parts = server.split(":")
            result["host"] = server_parts[0]
            result["port"] = int(server_parts[1]) if len(server_parts) > 1 else 80
        else:
            # host:port or host:port:user:pass
            parts = line.split(":")
            if len(parts) == 2:
                result["host"] = parts[0]
                result["port"] = int(parts[1])
            elif len(parts) == 4:
                result["host"] = parts[0]
                result["port"] = int(parts[1])
                result["username"] = parts[2]
                result["password"] = parts[3]
            else:
                return None

        return result

    def get_working_proxy(self, geo: str = None, exclude_ids: list[int] = None) -> Proxy | None:
        """
        Get next working proxy with round-robin rotation.
        Filters by GEO and status, excludes specified IDs.
        """
        query = self.db.query(Proxy).filter(Proxy.status == ProxyStatus.ACTIVE)

        if geo and geo.upper() != "ANY":
            query = query.filter(Proxy.geo == geo.upper())

        if exclude_ids:
            query = query.filter(~Proxy.id.in_(exclude_ids))

        proxies = query.order_by(Proxy.id).all()

        if not proxies:
            # Fallback: any active proxy
            proxies = self.db.query(Proxy).filter(Proxy.status == ProxyStatus.ACTIVE).all()

        if not proxies:
            return None

        # Round-robin rotation
        proxy = proxies[self._rotation_index % len(proxies)]
        self._rotation_index += 1

        return proxy

    def get_unbound_proxy(self, geo: str = None) -> Proxy | None:
        """Get an active proxy that is NOT bound to any account."""
        query = self.db.query(Proxy).filter(
            Proxy.status == ProxyStatus.ACTIVE,
            Proxy.bound_account_id == None,  # noqa: E711
        )
        if geo and geo.upper() != "ANY":
            query = query.filter(Proxy.geo == geo.upper())
        proxies = query.all()
        if proxies:
            return random.choice(proxies)
        return None

    def get_proxy_pool(self, count: int, geo: str = None) -> list[Proxy]:
        """Get N unique proxies for a batch operation (e.g. Birth)."""
        query = self.db.query(Proxy).filter(Proxy.status == ProxyStatus.ACTIVE)

        if geo and geo.upper() != "ANY":
            query = query.filter(Proxy.geo == geo.upper())

        proxies = query.all()

        if len(proxies) <= count:
            return proxies

        return random.sample(proxies, count)

    def bind_proxy_to_account(self, proxy: Proxy, account: Account):
        """Hard-bind a proxy to an account (1:1)."""
        proxy.bound_account_id = account.id
        account.proxy_id = proxy.id
        account.birth_ip = f"{proxy.host}:{proxy.port}"
        self.db.commit()
        logger.info(f"Proxy {proxy.host}:{proxy.port} bound to {account.email}")

    def refresh_proxy(self, proxy_id: int, new_host: str = None, new_port: int = None,
                      new_username: str = None, new_password: str = None) -> dict:
        """
        Refresh proxy connection data (same provider changed credentials).
        The IP identity stays the same, just auth/port may change.
        """
        proxy = self.db.query(Proxy).get(proxy_id)
        if not proxy:
            return {"status": "error", "message": "Proxy not found"}

        if new_host:
            proxy.host = new_host
        if new_port:
            proxy.port = new_port
        if new_username is not None:
            proxy.username = new_username
        if new_password is not None:
            proxy.password = new_password

        # Reset health
        proxy.status = ProxyStatus.ACTIVE
        proxy.fail_count = 0
        self.db.commit()

        bound_email = None
        if proxy.bound_account_id:
            account = self.db.query(Account).get(proxy.bound_account_id)
            bound_email = account.email if account else None

        logger.info(f"Proxy {proxy.host}:{proxy.port} refreshed (bound to: {bound_email or 'none'})")
        return {
            "status": "ok",
            "proxy_id": proxy.id,
            "bound_to": bound_email,
            "new_connection": proxy.to_string(),
        }

    def auto_reassign_dead_proxies(self) -> dict:
        """
        Find accounts bound to dead proxies and reassign them
        to available unbound active proxies from the pool.
        """
        reassigned = 0
        no_proxy = 0

        # Find all dead/expired proxies that have bound accounts
        dead_proxies = self.db.query(Proxy).filter(
            Proxy.status.in_([ProxyStatus.DEAD, ProxyStatus.EXPIRED]),
            Proxy.bound_account_id != None,  # noqa: E711
        ).all()

        for dead_proxy in dead_proxies:
            account = self.db.query(Account).get(dead_proxy.bound_account_id)
            if not account:
                dead_proxy.bound_account_id = None
                continue

            # Find a replacement (unbound, active, same geo if possible)
            replacement = self.get_unbound_proxy(geo=account.geo)
            if not replacement:
                replacement = self.get_unbound_proxy()  # any geo

            if replacement:
                # Unbind old
                dead_proxy.bound_account_id = None

                # Bind new
                self.bind_proxy_to_account(replacement, account)
                reassigned += 1
                logger.info(f"Auto-reassigned {account.email}: "
                            f"{dead_proxy.host}:{dead_proxy.port} → {replacement.host}:{replacement.port}")
            else:
                no_proxy += 1
                logger.warning(f"No free proxy for {account.email} (old proxy dead)")

        self.db.commit()
        return {"reassigned": reassigned, "no_proxy_available": no_proxy}

    def mark_dead(self, proxy_id: int):
        """Mark a proxy as dead and auto-reassign its account."""
        proxy = self.db.query(Proxy).get(proxy_id)
        if proxy:
            proxy.status = ProxyStatus.DEAD
            self.db.commit()

            # Auto-reassign if bound to account
            if proxy.bound_account_id:
                self.auto_reassign_dead_proxies()

    def get_stats(self) -> dict:
        """Get proxy pool statistics."""
        total = self.db.query(Proxy).count()
        active = self.db.query(Proxy).filter(Proxy.status == ProxyStatus.ACTIVE).count()
        dead = self.db.query(Proxy).filter(Proxy.status == ProxyStatus.DEAD).count()
        bound = self.db.query(Proxy).filter(Proxy.bound_account_id != None).count()  # noqa: E711
        free = self.db.query(Proxy).filter(
            Proxy.status == ProxyStatus.ACTIVE,
            Proxy.bound_account_id == None,  # noqa: E711
        ).count()

        return {
            "total": total,
            "active": active,
            "dead": dead,
            "expired": total - active - dead,
            "bound": bound,
            "free": free,
        }

