import requests
import time
from loguru import logger


class CaptchaProvider:
    def __init__(self, api_key: str = ""):
        self.api_key = api_key
        self.base_url = "http://api.cap.guru"

    def solve_recaptcha_v2(self, site_key, page_url):
        logger.info(f"Solving ReCaptcha v2 for {page_url}")
        # Implementation for cap.guru API
        try:
            res = requests.get(f"{self.base_url}/in.php?key={self.api_key}&method=userrecaptcha&googlekey={site_key}&pageurl={page_url}")
            if "OK|" in res.text:
                task_id = res.text.split("|")[1]
                return task_id
        except Exception as e:
            logger.error(f"Captcha submit failed: {e}")
        return None

    def solve_captcha(self, website_url: str, website_key: str) -> str | None:
        # Create Task
        params = {
            "key": self.api_key,
            "method": "userrecaptcha",
            "googlekey": website_key,
            "pageurl": website_url,
            "json": 1
        }
        try:
            resp = requests.get(f"{self.base_url}/in.php", params=params)
            data = resp.json()
            if data.get("status") != 1:
                logger.error(f"CapGuru Create Task Failed: {data}")
                return None
            
            request_id = data.get("request")
            logger.info(f"CapGuru Task ID: {request_id}")
            
            # Poll for Result
            for _ in range(30):
                time.sleep(2)
                res_params = {
                    "key": self.api_key,
                    "action": "get",
                    "id": request_id,
                    "json": 1
                }
                res_resp = requests.get(f"{self.base_url}/res.php", params=res_params)
                res_data = res_resp.json()
                
                if res_data.get("status") == 1:
                    return res_data.get("request")
                if res_data.get("request") == "ERROR_CAPTCHA_UNSOLVABLE":
                    return None
            
            return None
        except Exception as e:
            logger.error(f"CapGuru Error: {e}")
            return None
