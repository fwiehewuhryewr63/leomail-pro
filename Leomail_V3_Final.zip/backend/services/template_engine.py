"""
Leomail v3 — Template Engine
Variable substitution + spintax + uniqueness for each email.
"""
import re
from loguru import logger
from .spintax_engine import spin, add_uniqueness


# Variables we support
SUPPORTED_VARIABLES = ["LINK", "FIRSTNAME", "LASTNAME", "EMAILNAME"]


def detect_variables(text: str) -> list[str]:
    """Detect which template variables are used in text."""
    found = []
    for var in SUPPORTED_VARIABLES:
        if "{{" + var + "}}" in text:
            found.append(var)
    return found


def render_template(
    subject: str,
    body: str,
    recipient: dict,
    link_url: str = "",
    unique: bool = True,
) -> tuple[str, str]:
    """
    Render a template for a specific recipient.
    
    Args:
        subject: Template subject (may contain variables + spintax)
        body: Template body HTML (may contain variables + spintax)
        recipient: dict with keys: email, first_name, last_name
        link_url: URL to substitute for {{LINK}}
        unique: Whether to add invisible uniqueness markers
    
    Returns:
        (rendered_subject, rendered_body) — both fully unique
    """
    email = recipient.get("email", "")
    first_name = recipient.get("first_name", "")
    last_name = recipient.get("last_name", "")
    email_name = email.split("@")[0] if "@" in email else email

    # 1. Variable substitution
    replacements = {
        "{{LINK}}": link_url,
        "{{FIRSTNAME}}": first_name,
        "{{LASTNAME}}": last_name,
        "{{EMAILNAME}}": email_name,
    }

    rendered_subject = subject
    rendered_body = body

    for var, value in replacements.items():
        rendered_subject = rendered_subject.replace(var, value)
        rendered_body = rendered_body.replace(var, value)

    # 2. Spintax processing
    rendered_subject = spin(rendered_subject)
    rendered_body = spin(rendered_body)

    # 3. Uniqueness markers (body only, not subject — subject should be clean)
    if unique:
        rendered_body = add_uniqueness(rendered_body)

    return rendered_subject, rendered_body


def render_preview(subject: str, body: str) -> tuple[str, str]:
    """
    Render a preview with example data (for frontend display).
    """
    example_recipient = {
        "email": "john.doe@gmail.com",
        "first_name": "John",
        "last_name": "Doe",
    }
    return render_template(
        subject, body,
        recipient=example_recipient,
        link_url="https://example.com/offer",
        unique=False,
    )
