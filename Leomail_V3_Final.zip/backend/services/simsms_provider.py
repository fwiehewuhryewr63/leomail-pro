"""
Leomail v2.2 — SimSMS.org Provider
Full API integration with pricing, country availability, and max price control.
"""
import time
import requests
from loguru import logger

BASE_URL = "http://simsms.org/priemka.php"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"


class SimSmsProvider:
    """SimSMS.org API wrapper with pricing and country control."""

    # Service codes for email providers
    SERVICES = {
        "gmail": "opt4",
        "outlook": "opt1",
        "yahoo": "opt58",
        "mail_ru": "opt33",
    }

    def __init__(self, api_key: str):
        self.api_key = api_key

        params["apikey"] = self.api_key
        params["lang"] = "ru"
        headers = {"User-Agent": self.USER_AGENT}
        try:
            # Use http to avoid some SSL handshake issues on legacy APIs
            resp = requests.get(BASE_URL, params=params, headers=headers, timeout=20, verify=False)
            
            # Check for non-JSON response (e.g. Cloudflare or HTML error)
            if "application/json" not in resp.headers.get("Content-Type", "").lower() and resp.text.strip().startswith("<"):
                logger.error(f"SimSMS returned HTML: {resp.text[:200]}")
                return {"error": f"SimSMS returned invalid content (HTML). Check API key or IP ban."}

            data = resp.json()
            return data
        except requests.exceptions.JSONDecodeError:
             logger.error(f"SimSMS JSON Decode Error. Raw: {resp.text[:200]}")
             return {"error": "Invalid JSON response from SimSMS"}
        except Exception as e:
            logger.error(f"SimSMS API error: {e}")
            return {"error": str(e)}

    def get_balance(self) -> float:
        """Get current balance in rubles."""
        data = self._request(metod="get_balance")
        try:
            return float(data.get("balance", -1))
        except (ValueError, TypeError):
            return -1

    def get_prices(self, service: str = "gmail", country: str = "ru") -> dict:
        """
        Get pricing for a service+country combo.
        Returns: {price, currency, available_count}
        """
        service_code = self.SERVICES.get(service, "opt4")
        data = self._request(
            metod="get_prices",
            service=service_code,
            country=country
        )
        if "error" in data:
            return {"price": 0, "currency": "RUB", "available": 0, "error": data.get("error")}

        return {
            "price": float(data.get("price", 0)),
            "currency": "RUB",
            "available": int(data.get("count", 0)),
        }

    def get_available_countries(self, service: str = "gmail") -> list:
        """
        Get list of countries that have numbers for a given service.
        Returns: [{code, name, price, available}]
        """
        service_code = self.SERVICES.get(service, "opt4")
        data = self._request(
            metod="get_count_and_price",
            service=service_code
        )
        if isinstance(data, dict) and "error" in data:
            return []

        countries = []
        if isinstance(data, dict):
            for country_code, info in data.items():
                if isinstance(info, dict):
                    countries.append({
                        "code": country_code,
                        "price": float(info.get("price", 0)),
                        "available": int(info.get("count", 0)),
                    })
        return sorted(countries, key=lambda x: x["price"])

    def order_number(self, service: str = "gmail", country: str = "ru",
                     max_price: float = None) -> dict:
        """
        Order a phone number for SMS verification.
        max_price: refuse if price exceeds this (in RUB).
        Returns: {id, number} or {error}
        """
        # Check price first if max_price set
        if max_price is not None:
            prices = self.get_prices(service, country)
            if prices.get("price", 0) > max_price:
                return {
                    "error": f"Цена {prices['price']}₽ превышает лимит {max_price}₽",
                    "actual_price": prices.get("price", 0),
                    "max_price": max_price,
                }
            if prices.get("available", 0) == 0:
                return {"error": f"Нет доступных номеров для {service} в {country}"}

        service_code = self.SERVICES.get(service, "opt4")
        data = self._request(
            metod="get_number",
            service=service_code,
            country=country
        )

        if data.get("response") == "1":
            return {
                "id": data.get("id"),
                "number": data.get("number"),
                "country": country,
                "service": service,
            }
        else:
            error_map = {
                "2": "Нет свободных номеров",
                "3": "Недостаточно средств",
                "4": "Неверный API ключ",
            }
            code = str(data.get("response", ""))
            return {"error": error_map.get(code, f"Ошибка SimSMS: {data}")}

    def get_sms_code(self, order_id: str, timeout: int = 120) -> dict:
        """
        Wait for SMS code with timeout.
        Returns: {code} or {error}
        """
        start = time.time()
        while time.time() - start < timeout:
            data = self._request(metod="get_sms", id=order_id)
            response = str(data.get("response", ""))

            if response == "1":
                code = data.get("sms", "")
                # Extract digits from SMS
                import re
                digits = re.findall(r'\d{4,8}', str(code))
                return {
                    "code": digits[0] if digits else code,
                    "raw": code,
                    "wait_time": round(time.time() - start, 1),
                }
            elif response == "2":
                # Still waiting
                time.sleep(3)
                continue
            else:
                return {"error": f"Ошибка получения SMS: {data}"}

        return {"error": f"Таймаут {timeout}с — SMS не получено", "timeout": True}

    def set_status(self, order_id: str, status: int) -> dict:
        """
        Set activation status.
        status: 1=ready, 3=retry, 6=complete, 8=cancel
        """
        data = self._request(metod="set_status", id=order_id, status=status)
        return data
