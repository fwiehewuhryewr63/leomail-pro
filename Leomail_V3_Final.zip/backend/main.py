import sys
import os
import asyncio
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from loguru import logger

from .database import engine, Base
from .config import init_directories, load_config

# Import routers
from .routers import dashboard, birth, settings, proxies, farms, templates, databases, links, geo, resources
from .routers import sms, human_engine, errors, names, warmup, work, logs

app = FastAPI(title="Leomail", version="3.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register all routers
app.include_router(dashboard.router)
app.include_router(birth.router)
app.include_router(settings.router)
app.include_router(proxies.router)
app.include_router(farms.router)
app.include_router(templates.router)
app.include_router(databases.router)
app.include_router(links.router)
app.include_router(geo.router)
app.include_router(resources.router)
app.include_router(sms.router)
app.include_router(human_engine.router)
app.include_router(errors.router)
app.include_router(names.router)
app.include_router(warmup.router)
app.include_router(work.router)
app.include_router(logs.router)


@app.on_event("startup")
async def startup_event():
    # Setup log file
    from pathlib import Path as P
    log_path = P("user_data/logs/leomail.log")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logger.add(str(log_path), rotation="5 MB", retention="7 days", level="INFO",
               format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} | {message}")

    # Create all tables
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created/verified")

    # Initialize user_data directories
    init_directories()

    # Start proxy monitor background task
    config = load_config()
    proxy_cfg = config.get("proxy_monitor", {})
    interval = proxy_cfg.get("check_interval_sec", 60)
    max_fails = proxy_cfg.get("max_fail_count", 3)

    from .services.proxy_monitor import proxy_monitor_loop
    asyncio.create_task(proxy_monitor_loop(interval_sec=interval, max_fails=max_fails))
    logger.info(f"Proxy monitor started (every {interval}s)")

    logger.info("Leomail v3.0 Backend Started")


# Serve React frontend in production
if getattr(sys, 'frozen', False):
    # PyInstaller frozen EXE
    base_path = Path(sys._MEIPASS)
else:
    base_path = Path(__file__).parent.parent

frontend_path = base_path / "frontend" / "dist"

if frontend_path.exists():
    from fastapi.responses import FileResponse

    app.mount("/assets", StaticFiles(directory=str(frontend_path / "assets")), name="assets")

    @app.get("/{full_path:path}")
    async def serve_frontend(full_path: str):
        # Don't intercept API routes
        if full_path.startswith("api/"):
            from fastapi.responses import JSONResponse
            return JSONResponse({"error": "Not found"}, status_code=404)
        file_path = frontend_path / full_path
        if file_path.exists() and file_path.is_file():
            return FileResponse(str(file_path))
        return FileResponse(str(frontend_path / "index.html"))
