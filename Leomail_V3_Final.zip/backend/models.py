from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, JSON, Boolean, Float, Text, Table
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from .database import Base


# === ENUMS ===

class AccountStatus(str, enum.Enum):
    NEW = "new"
    WARMING = "warming"
    READY = "ready"
    SENDING = "sending"
    PAUSED = "paused"
    DEAD = "dead"
    BANNED = "banned"

class ProxyStatus(str, enum.Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    BANNED = "banned"
    DEAD = "dead"

class ProxyType(str, enum.Enum):
    MOBILE = "mobile"
    RESIDENTIAL = "residential"
    ISP = "isp"
    DATACENTER = "datacenter"

class TaskStatus(str, enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"

class ThreadType(str, enum.Enum):
    BIRTH = "birth"
    WARMUP = "warmup"
    WORK = "work"

class Gender(str, enum.Enum):
    MALE = "male"
    FEMALE = "female"
    RANDOM = "random"


# === Association table for Farm <-> Account ===
farm_accounts = Table(
    "farm_accounts", Base.metadata,
    Column("farm_id", Integer, ForeignKey("farms.id"), primary_key=True),
    Column("account_id", Integer, ForeignKey("accounts.id"), primary_key=True)
)


# === MODELS ===

class Proxy(Base):
    __tablename__ = "proxies"

    id = Column(Integer, primary_key=True, index=True)
    host = Column(String, nullable=False)
    port = Column(Integer, nullable=False)
    username = Column(String, nullable=True)
    password = Column(String, nullable=True)
    protocol = Column(String, default="http")  # http, socks5
    proxy_type = Column(String, default=ProxyType.RESIDENTIAL)  # mobile, residential, isp, datacenter
    status = Column(String, default=ProxyStatus.ACTIVE)
    geo = Column(String, nullable=True)  # US, DE, etc.
    
    # Monitoring
    last_check = Column(DateTime, nullable=True)
    response_time_ms = Column(Integer, nullable=True)
    fail_count = Column(Integer, default=0)
    
    # Binding
    bound_account_id = Column(Integer, nullable=True)  # 1:1 with account (birth IP)
    
    expires_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    accounts = relationship("Account", back_populates="proxy")

    def to_string(self):
        if self.username and self.password:
            return f"{self.protocol}://{self.username}:{self.password}@{self.host}:{self.port}"
        return f"{self.protocol}://{self.host}:{self.port}"

    def to_playwright(self):
        """Return dict for Playwright proxy config."""
        config = {"server": f"{self.protocol}://{self.host}:{self.port}"}
        if self.username:
            config["username"] = self.username
            config["password"] = self.password or ""
        return config


class Account(Base):
    __tablename__ = "accounts"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    password = Column(String, nullable=False)
    recovery_email = Column(String, nullable=True)
    recovery_phone = Column(String, nullable=True)

    provider = Column(String, index=True)  # gmail, outlook, yahoo, aol, hotmail
    status = Column(String, default=AccountStatus.NEW)

    # Identity (birth data)
    first_name = Column(String, nullable=True)
    last_name = Column(String, nullable=True)
    gender = Column(String, nullable=True)  # male, female
    birthday = Column(DateTime, nullable=True)
    geo = Column(String, nullable=True)  # US, DE, BR...
    language = Column(String, default="en")

    # Birth fingerprint
    birth_ip = Column(String, nullable=True)
    user_agent = Column(String, nullable=True)
    browser_profile_path = Column(String, nullable=True)  # path to saved profile

    # Warmup tracking
    warmup_day = Column(Integer, default=0)  # day of warmup (0 = not started)
    warmup_started_at = Column(DateTime, nullable=True)
    emails_sent_today = Column(Integer, default=0)
    total_emails_sent = Column(Integer, default=0)
    last_email_sent_at = Column(DateTime, nullable=True)
    bounces = Column(Integer, default=0)

    # Health
    health_score = Column(Float, default=100.0)  # 0-100

    # Proxy binding
    proxy_id = Column(Integer, ForeignKey("proxies.id"), nullable=True)
    proxy = relationship("Proxy", back_populates="accounts")

    # Metadata: cookies, fingerprint, etc.
    metadata_blob = Column(JSON, default={})

    # Farms (many-to-many)
    farms = relationship("Farm", secondary=farm_accounts, back_populates="accounts")

    created_at = Column(DateTime, default=datetime.utcnow)
    last_active = Column(DateTime, nullable=True)

    def to_export(self):
        """Export account to portable JSON format."""
        return {
            "email": self.email,
            "password": self.password,
            "provider": self.provider,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "gender": self.gender,
            "birthday": self.birthday.isoformat() if self.birthday else None,
            "geo": self.geo,
            "language": self.language,
            "birth_ip": self.birth_ip,
            "user_agent": self.user_agent,
            "warmup_day": self.warmup_day,
            "status": self.status,
            "health_score": self.health_score,
            "cookies": self.metadata_blob.get("cookies", []) if self.metadata_blob else [],
            "fingerprint": self.metadata_blob.get("fingerprint", {}) if self.metadata_blob else {},
        }


class Farm(Base):
    __tablename__ = "farms"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)

    accounts = relationship("Account", secondary=farm_accounts, back_populates="accounts")

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Template(Base):
    __tablename__ = "templates"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    subject = Column(String, nullable=False)  # may contain {{LINK}}, {{FIRSTNAME}}, etc.
    body = Column(Text, nullable=False)  # HTML, may contain {{LINK}}, {{FIRSTNAME}}, {{LASTNAME}}, {{EMAILNAME}}
    content_type = Column(String, default="html")  # html, plain
    language = Column(String, default="en")
    pack_name = Column(String, nullable=True)  # name of import pack (ZIP)
    variables = Column(JSON, default=[])  # detected variables: ["LINK", "FIRSTNAME", ...]

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class RecipientDatabase(Base):
    __tablename__ = "recipient_databases"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    file_path = Column(String, nullable=False)  # relative to user_data/databases/
    total_count = Column(Integer, default=0)
    used_count = Column(Integer, default=0)
    invalid_count = Column(Integer, default=0)
    with_name = Column(Boolean, default=False)  # True = email,FirstName,LastName format

    created_at = Column(DateTime, default=datetime.utcnow)


class LinkDatabase(Base):
    """File-based link packs (similar to recipient databases)."""
    __tablename__ = "link_databases"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)  # e.g. "Crypto Offers 2024"
    file_path = Column(String, nullable=False)  # relative to user_data/links/
    total_count = Column(Integer, default=0)
    
    created_at = Column(DateTime, default=datetime.utcnow)


class Link(Base):
    """(Deprecated in v3.1) Individual link tracking."""
    __tablename__ = "links"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    url = Column(String, nullable=False)
    click_count = Column(Integer, default=0)
    use_count = Column(Integer, default=0)
    active = Column(Boolean, default=True)

    created_at = Column(DateTime, default=datetime.utcnow)


class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)
    type = Column(String, index=True)  # birth, warmup, work
    status = Column(String, default=TaskStatus.PENDING)
    details = Column(String, nullable=True)

    # Progress
    total_items = Column(Integer, default=0)
    completed_items = Column(Integer, default=0)
    failed_items = Column(Integer, default=0)

    # Thread tracking
    thread_count = Column(Integer, default=1)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = Column(DateTime, nullable=True)

    @property
    def progress_pct(self):
        if self.total_items == 0:
            return 0
        return int((self.completed_items / self.total_items) * 100)


class ThreadLog(Base):
    """Per-thread activity log for live monitoring."""
    __tablename__ = "thread_logs"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=True)
    thread_index = Column(Integer, default=0)
    thread_type = Column(String)  # birth, warmup, work
    status = Column(String, default="idle")  # idle, running, paused, error, done
    current_action = Column(String, nullable=True)  # "filling name...", "solving captcha..."
    account_email = Column(String, nullable=True)
    proxy_info = Column(String, nullable=True)
    error_message = Column(String, nullable=True)
    screenshot_path = Column(String, nullable=True)

    started_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class NameDatabase(Base):
    """Uploaded name lists for Birth module. Each file: FirstName,LastName per line."""
    __tablename__ = "name_databases"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)  # display name, e.g. "US Male Names"
    file_path = Column(String, nullable=False)  # relative to user_data/names/
    country = Column(String, default="any")  # ISO: us, de, ru, any
    gender = Column(String, default="any")  # male, female, any
    total_count = Column(Integer, default=0)  # number of name pairs in file

    created_at = Column(DateTime, default=datetime.utcnow)
