"""
Leomail v3 — Anti-Detect Browser Engine
Full fingerprint randomization, device emulation, GEO-aware context, persistent sessions.
"""
import os
import json
import random
from pathlib import Path
from loguru import logger

try:
    from playwright.async_api import async_playwright, BrowserContext, Playwright
    HAS_PLAYWRIGHT = True
except ImportError:
    HAS_PLAYWRIGHT = False
    async_playwright = None
    BrowserContext = None
    Playwright = None

from ..data.geo_data import get_country


# ─── User-Agent Pool ───────────────────────────────────────────────────────────

CHROME_VERSIONS = [
    "120.0.6099.109", "120.0.6099.130", "120.0.6099.199", "120.0.6099.216",
    "121.0.6167.85", "121.0.6167.139", "121.0.6167.160", "121.0.6167.184",
    "122.0.6261.57", "122.0.6261.94", "122.0.6261.111", "122.0.6261.128",
    "123.0.6312.58", "123.0.6312.86", "123.0.6312.105", "123.0.6312.122",
    "124.0.6367.60", "124.0.6367.78", "124.0.6367.91", "124.0.6367.118",
    "125.0.6422.53", "125.0.6422.76", "125.0.6422.112", "125.0.6422.141",
    "126.0.6478.55", "126.0.6478.114", "126.0.6478.126", "126.0.6478.182",
    "127.0.6533.72", "127.0.6533.89", "127.0.6533.99", "127.0.6533.119",
    "128.0.6613.84", "128.0.6613.113", "128.0.6613.119", "128.0.6613.137",
    "129.0.6668.58", "129.0.6668.70", "129.0.6668.89", "129.0.6668.100",
    "130.0.6723.58", "130.0.6723.69", "130.0.6723.91", "130.0.6723.116",
    "131.0.6778.69", "131.0.6778.85", "131.0.6778.108", "131.0.6778.139",
]

EDGE_VERSIONS = [
    "120.0.2210.61", "120.0.2210.91", "121.0.2277.83", "121.0.2277.98",
    "122.0.2365.52", "122.0.2365.80", "123.0.2420.65", "123.0.2420.81",
    "124.0.2478.51", "124.0.2478.80", "125.0.2535.51", "125.0.2535.79",
    "126.0.2592.56", "126.0.2592.87", "127.0.2651.74", "127.0.2651.98",
    "128.0.2739.42", "128.0.2739.67", "129.0.2792.52", "129.0.2792.79",
    "130.0.2849.46", "130.0.2849.68", "131.0.2903.51", "131.0.2903.86",
]

WINDOWS_VERSIONS = [
    "Windows NT 10.0; Win64; x64",
    "Windows NT 10.0; WOW64",
    "Windows NT 11.0; Win64; x64",
]

MAC_VERSIONS = [
    "Macintosh; Intel Mac OS X 10_15_7",
    "Macintosh; Intel Mac OS X 11_6_8",
    "Macintosh; Intel Mac OS X 12_7_4",
    "Macintosh; Intel Mac OS X 13_6_4",
    "Macintosh; Intel Mac OS X 14_4_1",
    "Macintosh; Intel Mac OS X 14_7_2",
]

LINUX_VERSIONS = [
    "X11; Linux x86_64",
    "X11; Ubuntu; Linux x86_64",
]

MOBILE_ANDROID = [
    ("Pixel 7", "14", {"width": 412, "height": 915, "scale": 2.625}),
    ("Pixel 7 Pro", "14", {"width": 412, "height": 892, "scale": 3.5}),
    ("Pixel 8", "14", {"width": 412, "height": 915, "scale": 2.625}),
    ("SM-S918B", "14", {"width": 360, "height": 780, "scale": 3}),        # Galaxy S23 Ultra
    ("SM-A546B", "14", {"width": 412, "height": 915, "scale": 2.625}),    # Galaxy A54
    ("SM-G991B", "13", {"width": 360, "height": 800, "scale": 3}),        # Galaxy S21
    ("22101316G", "13", {"width": 393, "height": 873, "scale": 2.75}),    # Xiaomi 13
    ("2201117TG", "13", {"width": 412, "height": 915, "scale": 2.625}),   # Xiaomi 12
    ("CPH2451", "13", {"width": 412, "height": 915, "scale": 2.625}),     # OnePlus Nord CE 3
    ("V2227A", "13", {"width": 393, "height": 851, "scale": 2.75}),       # Vivo X90
]

MOBILE_IOS = [
    ("iPhone 15 Pro", "17.4", {"width": 393, "height": 852, "scale": 3}),
    ("iPhone 15", "17.4", {"width": 390, "height": 844, "scale": 3}),
    ("iPhone 14 Pro Max", "17.3", {"width": 430, "height": 932, "scale": 3}),
    ("iPhone 14", "17.2", {"width": 390, "height": 844, "scale": 3}),
    ("iPhone 13", "17.1", {"width": 390, "height": 844, "scale": 3}),
    ("iPhone SE 3", "17.0", {"width": 375, "height": 667, "scale": 2}),
    ("iPad Pro 12.9", "17.4", {"width": 1024, "height": 1366, "scale": 2}),
    ("iPad Air", "17.3", {"width": 820, "height": 1180, "scale": 2}),
]

DESKTOP_VIEWPORTS = [
    {"width": 1366, "height": 768},
    {"width": 1440, "height": 900},
    {"width": 1536, "height": 864},
    {"width": 1600, "height": 900},
    {"width": 1680, "height": 1050},
    {"width": 1920, "height": 1080},
    {"width": 2560, "height": 1440},
]


def _generate_desktop_ua() -> str:
    """Generate a random desktop user-agent string."""
    browser_type = random.choices(["chrome", "edge"], weights=[80, 20])[0]
    os_type = random.choices(["windows", "mac", "linux"], weights=[70, 22, 8])[0]

    if os_type == "windows":
        os_str = random.choice(WINDOWS_VERSIONS)
    elif os_type == "mac":
        os_str = random.choice(MAC_VERSIONS)
    else:
        os_str = random.choice(LINUX_VERSIONS)

    if browser_type == "chrome":
        ver = random.choice(CHROME_VERSIONS)
        return f"Mozilla/5.0 ({os_str}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{ver} Safari/537.36"
    else:
        c_ver = random.choice(CHROME_VERSIONS)
        e_ver = random.choice(EDGE_VERSIONS)
        return f"Mozilla/5.0 ({os_str}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{c_ver} Safari/537.36 Edg/{e_ver}"


def _generate_mobile_ua(device_info: tuple, platform: str) -> str:
    """Generate mobile user-agent string."""
    if platform == "android":
        name, android_ver, _ = device_info
        ver = random.choice(CHROME_VERSIONS[-16:])  # Recent Chrome versions
        return (
            f"Mozilla/5.0 (Linux; Android {android_ver}; {name}) "
            f"AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{ver} Mobile Safari/537.36"
        )
    else:  # ios
        name, ios_ver, _ = device_info
        webkit_ver = random.choice(["605.1.15", "604.1"])
        ver = random.choice(CHROME_VERSIONS[-8:])
        return (
            f"Mozilla/5.0 (iPhone; CPU iPhone OS {ios_ver.replace('.', '_')} like Mac OS X) "
            f"AppleWebKit/{webkit_ver} (KHTML, like Gecko) CriOS/{ver} Mobile/15E148 Safari/{webkit_ver}"
        )


# ─── Fingerprint Stealth Scripts ───────────────────────────────────────────────

STEALTH_SCRIPTS = [
    # Hide webdriver flag
    """Object.defineProperty(navigator, 'webdriver', { get: () => undefined });""",
    # Chrome runtime
    """window.chrome = { runtime: {}, loadTimes: function(){}, csi: function(){} };""",
    # Permissions
    """
    const originalQuery = window.navigator.permissions.query;
    window.navigator.permissions.query = (parameters) => (
        parameters.name === 'notifications' ?
        Promise.resolve({ state: Notification.permission }) :
        originalQuery(parameters)
    );
    """,
    # Plugin count (real Chrome has 5)
    """
    Object.defineProperty(navigator, 'plugins', {
        get: () => [
            { name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer' },
            { name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai' },
            { name: 'Native Client', filename: 'internal-nacl-plugin' },
            { name: 'Shockwave Flash', filename: 'pepflashplayer.dll' },
            { name: 'Widevine Content Decryption Module', filename: 'widevinecdmadapter.dll' },
        ]
    });
    """,
    # Language consistency
    """Object.defineProperty(navigator, 'languages', { get: () => ['en-US', 'en'] });""",
    # Hardware concurrency randomization
    f"""Object.defineProperty(navigator, 'hardwareConcurrency', {{ get: () => {random.choice([4, 8, 12, 16])} }});""",
    # Device memory
    f"""Object.defineProperty(navigator, 'deviceMemory', {{ get: () => {random.choice([4, 8, 16])} }});""",
    # Canvas fingerprint noise
    """
    const origToDataURL = HTMLCanvasElement.prototype.toDataURL;
    HTMLCanvasElement.prototype.toDataURL = function(type) {
        if (type === 'image/png') {
            const ctx = this.getContext('2d');
            if (ctx) {
                const imageData = ctx.getImageData(0, 0, this.width, this.height);
                for (let i = 0; i < imageData.data.length; i += 4) {
                    imageData.data[i] += (Math.random() * 2 - 1) | 0;
                }
                ctx.putImageData(imageData, 0, 0);
            }
        }
        return origToDataURL.apply(this, arguments);
    };
    """,
    # WebGL renderer randomization
    """
    const getParameter = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function(parameter) {
        if (parameter === 37445) return 'Google Inc. (NVIDIA)';
        if (parameter === 37446) return 'ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 SUPER Direct3D11 vs_5_0 ps_5_0, D3D11)';
        return getParameter.call(this, parameter);
    };
    """,
]

PROFILES_DIR = Path("user_data/profiles")


# ─── Browser Manager ──────────────────────────────────────────────────────────

class BrowserManager:
    """Anti-detect browser engine with device emulation and persistent sessions."""

    def __init__(self, headless: bool = False):
        self.headless = headless
        self.playwright: Playwright | None = None
        self.browser = None
        PROFILES_DIR.mkdir(parents=True, exist_ok=True)

    async def start(self):
        """Launch browser engine."""
        if not HAS_PLAYWRIGHT:
            raise RuntimeError("Playwright not installed. Run: pip install playwright && playwright install chromium")
        self.playwright = await async_playwright().start()
        self.browser = await self.playwright.chromium.launch(
            headless=self.headless,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-infobars",
                "--disable-background-timer-throttling",
                "--disable-backgrounding-occluded-windows",
                "--disable-renderer-backgrounding",
                "--window-size=1920,1080",
            ]
        )
        logger.info(f"Browser engine started (headless={self.headless})")

    async def stop(self):
        """Shutdown browser engine."""
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
        logger.info("Browser engine stopped")

    async def create_context(
        self,
        proxy=None,
        device_type: str = "desktop",
        geo: str = None,
        session_path: str = None,
    ) -> BrowserContext:
        """
        Create a new anti-detect browser context.

        Args:
            proxy: Proxy model instance or None
            device_type: "desktop" | "phone_android" | "phone_ios"
            geo: ISO country code for timezone/locale matching (auto from proxy if None)
            session_path: path to saved session.json for persistent login
        """
        # Resolve GEO
        country_code = geo
        if not country_code and proxy and hasattr(proxy, 'geo') and proxy.geo:
            country_code = proxy.geo
        country_data = get_country(country_code) if country_code else None

        # Timezone & locale from GEO
        timezone_id = country_data["tz"] if country_data else random.choice([
            "America/New_York", "America/Chicago", "America/Los_Angeles", "America/Denver",
            "Europe/London", "Europe/Berlin", "Europe/Paris",
        ])
        lang = country_data["lang"] if country_data else "en"
        locale_str = f"{lang}-{country_code}" if country_code else f"{lang}-US"

        # Proxy config
        proxy_config = None
        if proxy:
            if hasattr(proxy, 'to_playwright'):
                proxy_config = proxy.to_playwright()
            elif hasattr(proxy, 'host'):
                proxy_config = {"server": f"{proxy.protocol}://{proxy.host}:{proxy.port}"}
                if proxy.username:
                    proxy_config["username"] = proxy.username
                    proxy_config["password"] = proxy.password or ""

        # Build context options
        context_options = {
            "proxy": proxy_config,
            "locale": locale_str,
            "timezone_id": timezone_id,
            "permissions": ["geolocation"],
            "ignore_https_errors": True,
            "java_script_enabled": True,
        }

        # Device-specific configuration
        if device_type.startswith("phone_android"):
            device_info = random.choice(MOBILE_ANDROID)
            name, android_ver, screen = device_info
            context_options["user_agent"] = _generate_mobile_ua(device_info, "android")
            context_options["viewport"] = {"width": screen["width"], "height": screen["height"]}
            context_options["device_scale_factor"] = screen["scale"]
            context_options["is_mobile"] = True
            context_options["has_touch"] = True
            logger.debug(f"Emulating Android: {name} (Android {android_ver})")

        elif device_type.startswith("phone_ios"):
            device_info = random.choice(MOBILE_IOS)
            name, ios_ver, screen = device_info
            context_options["user_agent"] = _generate_mobile_ua(device_info, "ios")
            context_options["viewport"] = {"width": screen["width"], "height": screen["height"]}
            context_options["device_scale_factor"] = screen["scale"]
            context_options["is_mobile"] = True
            context_options["has_touch"] = True
            logger.debug(f"Emulating iOS: {name} (iOS {ios_ver})")

        else:
            # Desktop
            context_options["user_agent"] = _generate_desktop_ua()
            context_options["viewport"] = random.choice(DESKTOP_VIEWPORTS)
            context_options["device_scale_factor"] = random.choice([1, 1, 1, 1.25, 1.5, 2])
            context_options["is_mobile"] = False
            context_options["has_touch"] = False

        # Load persistent session if available
        if session_path and os.path.exists(session_path):
            try:
                context_options["storage_state"] = session_path
                logger.debug(f"Loading session: {session_path}")
            except Exception as e:
                logger.warning(f"Failed to load session {session_path}: {e}")

        # Create context
        context = await self.browser.new_context(**context_options)

        # Apply stealth scripts to every new page
        await context.add_init_script(script="\n".join(STEALTH_SCRIPTS))

        # Override language header to match locale
        await context.set_extra_http_headers({
            "Accept-Language": f"{locale_str},{lang};q=0.9,en;q=0.8",
        })

        logger.debug(
            f"Context created: device={device_type}, geo={country_code or 'random'}, "
            f"tz={timezone_id}, locale={locale_str}"
        )
        return context

    async def save_session(self, context: BrowserContext, account_id: int) -> str:
        """Save browser session (cookies, localStorage) for an account."""
        profile_dir = PROFILES_DIR / str(account_id)
        profile_dir.mkdir(parents=True, exist_ok=True)
        session_path = str(profile_dir / "session.json")

        state = await context.storage_state()
        with open(session_path, "w") as f:
            json.dump(state, f)

        logger.info(f"Session saved: account {account_id} → {session_path}")
        return session_path

    async def load_session_context(
        self,
        account_id: int,
        proxy=None,
        device_type: str = "desktop",
        geo: str = None,
    ) -> tuple[BrowserContext, str]:
        """Load a persistent session for an account. Returns (context, session_path)."""
        session_path = str(PROFILES_DIR / str(account_id) / "session.json")
        context = await self.create_context(
            proxy=proxy,
            device_type=device_type,
            geo=geo,
            session_path=session_path if os.path.exists(session_path) else None,
        )
        return context, session_path

    @staticmethod
    def get_session_path(account_id: int) -> str:
        """Get the session file path for an account."""
        return str(PROFILES_DIR / str(account_id) / "session.json")

    @staticmethod
    def has_session(account_id: int) -> bool:
        """Check if a saved session exists for an account."""
        return os.path.exists(PROFILES_DIR / str(account_id) / "session.json")

    async def close_context(self, context: BrowserContext):
        """Close a browser context."""
        try:
            await context.close()
        except Exception:
            pass
