"""
Leomail v3 — Warmup Module
Browser-based email warmup: open profile, compose, send, read, reply.
User controls ALL timing — everything in random ranges.
"""
import random
import asyncio
from datetime import datetime
from loguru import logger
from sqlalchemy.orm import Session

from ...database import SessionLocal
from ...models import Account, Farm, Task, TaskStatus, ThreadLog
from ..browser_manager import BrowserManager
from ...services.template_engine import render_template
from ...services.human_engine import human_engine
from ...config import load_config


class WarmupSession:
    """Single account warmup worker."""

    def __init__(
        self,
        account: Account,
        targets: list[Account],  # accounts to send TO (same farm or pool)
        browser_manager: BrowserManager,
        template_subject: str,
        template_body: str,
        delay_min: int,
        delay_max: int,
        emails_per_day_min: int,
        emails_per_day_max: int,
        same_provider: bool = False,
        thread_log: ThreadLog = None,
    ):
        self.account = account
        self.targets = targets
        self.browser_manager = browser_manager
        self.template_subject = template_subject
        self.template_body = template_body
        self.delay_min = delay_min
        self.delay_max = delay_max
        self.emails_per_day_min = emails_per_day_min
        self.emails_per_day_max = emails_per_day_max
        self.same_provider = same_provider
        self.thread_log = thread_log
        self.sent_count = 0
        self.error_count = 0

    async def run(self, db: Session):
        """Execute warmup for this account."""
        emails_today = random.randint(self.emails_per_day_min, self.emails_per_day_max)
        logger.info(f"Warmup [{self.account.email}]: sending {emails_today} emails")

        # Filter targets
        available_targets = list(self.targets)
        if self.same_provider:
            my_provider = self.account.provider
            available_targets = [t for t in available_targets if t.provider == my_provider]

        if not available_targets:
            logger.warning(f"Warmup [{self.account.email}]: no targets available")
            return

        # Load session
        context, session_path = await self.browser_manager.load_session_context(
            account_id=self.account.id,
            proxy=self.account.proxy,
            device_type="desktop",
            geo=self.account.geo,
        )

        try:
            page = await context.new_page()
            provider = self.account.provider or "gmail"

            # Navigate to mail
            if provider == "gmail":
                await page.goto("https://mail.google.com", wait_until="domcontentloaded", timeout=30000)
            elif provider in ("outlook", "hotmail"):
                await page.goto("https://outlook.live.com/mail", wait_until="domcontentloaded", timeout=30000)

            # Check if logged in (session still valid)
            await asyncio.sleep(random.uniform(2, 5))
            current_url = page.url

            if "signin" in current_url or "login" in current_url or "accounts.google.com" in current_url:
                logger.info(f"Warmup [{self.account.email}]: session expired, re-login needed")
                await self._relogin(page, provider)

            # Send emails
            for i in range(emails_today):
                target = random.choice(available_targets)

                # Render unique template
                recipient = {
                    "email": target.email,
                    "first_name": target.first_name or "",
                    "last_name": target.last_name or "",
                }
                subject, body = render_template(
                    self.template_subject, self.template_body,
                    recipient=recipient, unique=True,
                )

                # Update thread log
                if self.thread_log:
                    self._update_log(db, f"Sending email {i + 1}/{emails_today} to {target.email}")

                # Send
                try:
                    if provider == "gmail":
                        await self._send_gmail(page, target.email, subject, body)
                    elif provider in ("outlook", "hotmail"):
                        await self._send_outlook(page, target.email, subject, body)

                    self.sent_count += 1
                    logger.debug(f"Warmup [{self.account.email}] → {target.email} ✓")

                except Exception as e:
                    self.error_count += 1
                    logger.error(f"Warmup [{self.account.email}] send error: {e}")

                # Random delay (NEVER identical)
                delay = random.uniform(self.delay_min, self.delay_max)
                delay += random.uniform(-5, 5)  # extra jitter
                delay = max(5, delay)
                await asyncio.sleep(delay)

            # Read some incoming emails (human behavior)
            try:
                await self._read_inbox(page, provider)
            except Exception:
                pass

            # Save session
            await self.browser_manager.save_session(context, self.account.id)

            # Update account
            self.account.emails_sent_today = self.sent_count
            self.account.total_emails_sent = (self.account.total_emails_sent or 0) + self.sent_count
            self.account.last_email_sent_at = datetime.utcnow()
            self.account.warmup_day = (self.account.warmup_day or 0) + 1
            self.account.last_active = datetime.utcnow()
            db.commit()

        except Exception as e:
            logger.error(f"Warmup [{self.account.email}] fatal: {e}")
            self.error_count += 1
        finally:
            await self.browser_manager.close_context(context)

        return {"sent": self.sent_count, "errors": self.error_count}

    async def _send_gmail(self, page, to_email: str, subject: str, body: str):
        """Compose and send email in Gmail."""
        # Click Compose button
        await page.click('[gh="cm"], [data-tooltip="Compose"]', timeout=10000)
        await asyncio.sleep(random.uniform(1, 2.5))

        # Fill To
        to_field = page.locator('input[name="to"], [aria-label="To recipients"]')
        await to_field.fill("")
        await to_field.type(to_email, delay=random.randint(30, 80))
        await asyncio.sleep(random.uniform(0.5, 1.5))

        # Fill Subject
        subj_field = page.locator('input[name="subjectbox"]')
        await subj_field.type(subject, delay=random.randint(25, 65))
        await asyncio.sleep(random.uniform(0.5, 1))

        # Fill Body
        body_el = page.locator('[aria-label="Message Body"], [role="textbox"]').first
        await body_el.type(body, delay=random.randint(15, 45))
        await asyncio.sleep(random.uniform(0.5, 2))

        # Send
        await page.click('[aria-label="Send"], [data-tooltip="Send"]')
        await asyncio.sleep(random.uniform(2, 4))

    async def _send_outlook(self, page, to_email: str, subject: str, body: str):
        """Compose and send email in Outlook."""
        await page.click('[aria-label="New mail"], button:has-text("New mail")', timeout=10000)
        await asyncio.sleep(random.uniform(1, 3))

        # To
        to_field = page.locator('[aria-label="To"], input[role="combobox"]').first
        await to_field.type(to_email, delay=random.randint(30, 70))
        await asyncio.sleep(random.uniform(1, 2))
        await page.keyboard.press("Tab")

        # Subject
        subj_field = page.locator('[aria-label="Add a subject"]')
        await subj_field.type(subject, delay=random.randint(25, 60))

        # Body
        body_el = page.locator('[aria-label="Message body"], [role="textbox"]').first
        await body_el.type(body, delay=random.randint(15, 40))
        await asyncio.sleep(random.uniform(0.5, 2))

        # Send
        await page.click('[aria-label="Send"], button:has-text("Send")')
        await asyncio.sleep(random.uniform(2, 4))

    async def _read_inbox(self, page, provider: str):
        """Read a few emails to simulate human behavior."""
        if provider == "gmail":
            # Click on a recent unread email
            unread = page.locator('tr.zE').first
            if await unread.count():
                await unread.click()
                await asyncio.sleep(random.uniform(3, 8))
                # Go back
                await page.click('[aria-label="Back to Inbox"]')

    async def _relogin(self, page, provider: str):
        """Attempt re-login (placeholder — needs provider-specific flow)."""
        logger.warning(f"Re-login for {self.account.email} — manual session recovery needed")
        # TODO: per-provider login flow if session expired

    def _update_log(self, db: Session, action: str):
        if self.thread_log:
            self.thread_log.current_action = action
            self.thread_log.updated_at = datetime.utcnow()
            db.commit()


async def run_warmup_task(
    farm_ids: list[int],
    template_subject: str,
    template_body: str,
    emails_per_day_min: int = 1,
    emails_per_day_max: int = 5,
    delay_min: int = 60,
    delay_max: int = 300,
    same_provider: bool = False,
    threads: int = 5,
):
    """
    Run warmup for accounts in specified farms.
    Each account runs in its own browser context.
    """
    db = SessionLocal()
    try:
        # Get accounts from farms
        farms = db.query(Farm).filter(Farm.id.in_(farm_ids)).all()
        all_accounts = []
        for farm in farms:
            all_accounts.extend(farm.accounts)

        if not all_accounts:
            logger.error("Warmup: no accounts in selected farms")
            return

        # Filter: skip dead/banned accounts
        accounts = [a for a in all_accounts if a.status not in ("dead", "banned")]
        logger.info(f"Warmup: {len(accounts)} accounts from {len(farms)} farms, {threads} threads")

        # Create task record
        task = Task(
            type="warmup",
            status=TaskStatus.RUNNING,
            total_items=len(accounts),
            thread_count=threads,
            details=f"Warming {len(accounts)} accounts ({emails_per_day_min}-{emails_per_day_max} emails/day)",
        )
        db.add(task)
        db.commit()

        # Start browser engine
        browser_manager = BrowserManager(headless=False)
        await browser_manager.start()

        try:
            # Process accounts with concurrency limit
            semaphore = asyncio.Semaphore(threads)

            async def process_account(account):
                async with semaphore:


                    # Create thread log
                    thread_log = ThreadLog(
                        task_id=task.id,
                        thread_type="warmup",
                        status="running",
                        account_email=account.email,
                    )
                    db.add(thread_log)
                    db.commit()

                    session = WarmupSession(
                        account=account,
                        targets=accounts,
                        browser_manager=browser_manager,
                        template_subject=template_subject,
                        template_body=template_body,
                        delay_min=delay_min,
                        delay_max=delay_max,
                        emails_per_day_min=emails_per_day_min,
                        emails_per_day_max=emails_per_day_max,
                        same_provider=same_provider,
                        thread_log=thread_log,
                    )

                    result = await session.run(db)

                    # Update thread log
                    thread_log.status = "done"
                    thread_log.current_action = f"Sent {result['sent']}, errors {result['errors']}"
                    db.commit()

                    # Update task progress
                    task.completed_items = (task.completed_items or 0) + 1
                    db.commit()

            # Random start jitter for each account
            tasks = []
            for account in accounts:
                jitter = random.uniform(0, 60)  # 0-60s random start
                await asyncio.sleep(jitter)
                tasks.append(asyncio.create_task(process_account(account)))

            await asyncio.gather(*tasks, return_exceptions=True)

            task.status = TaskStatus.COMPLETED
            task.completed_at = datetime.utcnow()
            db.commit()

        finally:
            await browser_manager.stop()

    except Exception as e:
        logger.error(f"Warmup task failed: {e}")
    finally:
        db.close()
