"""
Leomail v3 — Work Module (Mass Mailing Engine)
Browser-based sending: open profile, compose with template variables + spintax, send, track.
"""
import random
import asyncio
from datetime import datetime
from loguru import logger
from sqlalchemy.orm import Session
from pathlib import Path

from ...database import SessionLocal
from ...models import Account, Farm, Task, TaskStatus, ThreadLog, Link, RecipientDatabase
from ..browser_manager import BrowserManager
from ...services.template_engine import render_template
from ...services.error_handler import error_handler
from ...config import load_config


def _load_recipients(db_record: RecipientDatabase) -> list[dict]:
    """Load recipients from a database file."""
    filepath = Path("user_data/databases") / db_record.file_path
    if not filepath.exists():
        return []

    recipients = []
    with open(filepath, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(",")
            if db_record.with_name and len(parts) >= 3:
                recipients.append({
                    "email": parts[0].strip(),
                    "first_name": parts[1].strip(),
                    "last_name": parts[2].strip(),
                })
            elif len(parts) >= 1:
                email = parts[0].strip()
                if "@" in email:
                    recipients.append({
                        "email": email,
                        "first_name": "",
                        "last_name": "",
                    })

    return recipients


class LinkRotator:
    """Rotates links with usage tracking and max_uses limit."""

    def __init__(self, links: list[Link], max_uses: int = 0):
        self.links = links
        self.max_uses = max_uses  # 0 = unlimited
        self.index = 0

    def next(self, db: Session) -> Link | None:
        """Get next available link."""
        if not self.links:
            return None

        # Find next link that hasn't exceeded max_uses
        for _ in range(len(self.links)):
            link = self.links[self.index % len(self.links)]
            self.index += 1

            if self.max_uses > 0 and link.use_count >= self.max_uses:
                continue

            return link

        # All links exhausted
        return None

    def record_use(self, link: Link, db: Session):
        """Record link usage."""
        link.use_count = (link.use_count or 0) + 1
        db.commit()


class WorkSession:
    """Single account sending worker."""

    def __init__(
        self,
        account: Account,
        browser_manager: BrowserManager,
        templates: list[tuple[str, str]],  # [(subject, body), ...]
        link_rotator: LinkRotator,
        delay_min: int,
        delay_max: int,
        emails_per_day_min: int,
        emails_per_day_max: int,
        thread_log: ThreadLog = None,
    ):
        self.account = account
        self.browser_manager = browser_manager
        self.templates = templates
        self.link_rotator = link_rotator
        self.delay_min = delay_min
        self.delay_max = delay_max
        self.emails_per_day_min = emails_per_day_min
        self.emails_per_day_max = emails_per_day_max
        self.thread_log = thread_log
        self.sent_count = 0
        self.error_count = 0
        self.bounce_count = 0

    async def run(self, recipients: list[dict], db: Session):
        """Execute sending for this account."""
        emails_today = random.randint(self.emails_per_day_min, self.emails_per_day_max)
        # Don't send more than we have recipients
        emails_today = min(emails_today, len(recipients))

        logger.info(f"Work [{self.account.email}]: sending {emails_today} emails")

        # Load session
        context, session_path = await self.browser_manager.load_session_context(
            account_id=self.account.id,
            proxy=self.account.proxy,
            device_type="desktop",
            geo=self.account.geo,
        )

        try:
            page = await context.new_page()
            provider = self.account.provider or "gmail"

            # Navigate to mail
            if provider == "gmail":
                await page.goto("https://mail.google.com", wait_until="domcontentloaded", timeout=30000)
            elif provider in ("outlook", "hotmail"):
                await page.goto("https://outlook.live.com/mail", wait_until="domcontentloaded", timeout=30000)

            await asyncio.sleep(random.uniform(2, 5))

            # Check session validity
            if "signin" in page.url or "login" in page.url:
                logger.warning(f"Work [{self.account.email}]: session expired, attempting re-login")
                # TODO: re-login flow
                return {"sent": 0, "errors": 1, "bounces": 0}

            # Send to recipients
            batch = recipients[:emails_today]
            for i, recipient in enumerate(batch):
                # Pick random template
                tmpl_subject, tmpl_body = random.choice(self.templates)

                # Get next link
                link = self.link_rotator.next(db)
                link_url = link.url if link else ""

                # Render with variables + spintax + uniqueness
                subject, body = render_template(
                    tmpl_subject, tmpl_body,
                    recipient=recipient,
                    link_url=link_url,
                    unique=True,
                )

                # Update thread log
                if self.thread_log:
                    self.thread_log.current_action = f"Sending {i + 1}/{len(batch)} → {recipient['email']}"
                    self.thread_log.updated_at = datetime.utcnow()
                    db.commit()

                try:
                    if provider == "gmail":
                        await self._send_gmail(page, recipient["email"], subject, body)
                    elif provider in ("outlook", "hotmail"):
                        await self._send_outlook(page, recipient["email"], subject, body)

                    self.sent_count += 1

                    # Record link usage
                    if link:
                        self.link_rotator.record_use(link, db)

                    logger.debug(f"Work [{self.account.email}] → {recipient['email']} ✓")

                except Exception as e:
                    error_msg = str(e)
                    self.error_count += 1
                    logger.error(f"Work [{self.account.email}] → {recipient['email']} ✗: {error_msg}")

                    # Error handling
                    action = error_handler.handle_send_error(
                        email=self.account.email,
                        error=error_msg,
                        recipient=recipient["email"],
                    )

                    if action.get("action") == "stop":
                        logger.warning(f"Work [{self.account.email}]: stopping (error handler)")
                        break
                    elif action.get("action") == "skip":
                        continue

                # Random delay (ALWAYS different)
                delay = random.uniform(self.delay_min, self.delay_max)
                delay += random.uniform(-3, 3)  # extra jitter
                delay = max(3, delay)
                await asyncio.sleep(delay)

            # Save session
            await self.browser_manager.save_session(context, self.account.id)

            # Update account stats
            self.account.total_emails_sent = (self.account.total_emails_sent or 0) + self.sent_count
            self.account.last_email_sent_at = datetime.utcnow()
            self.account.last_active = datetime.utcnow()
            self.account.status = "sending"
            db.commit()

        except Exception as e:
            logger.error(f"Work [{self.account.email}] fatal: {e}")
            self.error_count += 1
        finally:
            await self.browser_manager.close_context(context)

        return {"sent": self.sent_count, "errors": self.error_count, "bounces": self.bounce_count}

    async def _send_gmail(self, page, to_email: str, subject: str, body: str):
        """Compose and send in Gmail."""
        await page.click('[gh="cm"], [data-tooltip="Compose"]', timeout=10000)
        await asyncio.sleep(random.uniform(1, 2.5))

        to_field = page.locator('input[name="to"], [aria-label="To recipients"]')
        await to_field.fill("")
        await to_field.type(to_email, delay=random.randint(30, 80))
        await asyncio.sleep(random.uniform(0.5, 1.5))

        subj_field = page.locator('input[name="subjectbox"]')
        await subj_field.type(subject, delay=random.randint(25, 65))
        await asyncio.sleep(random.uniform(0.3, 1))

        body_el = page.locator('[aria-label="Message Body"], [role="textbox"]').first
        await body_el.type(body, delay=random.randint(10, 35))
        await asyncio.sleep(random.uniform(0.5, 2))

        await page.click('[aria-label="Send"], [data-tooltip="Send"]')
        await asyncio.sleep(random.uniform(2, 4))

    async def _send_outlook(self, page, to_email: str, subject: str, body: str):
        """Compose and send in Outlook."""
        await page.click('[aria-label="New mail"], button:has-text("New mail")', timeout=10000)
        await asyncio.sleep(random.uniform(1, 3))

        to_field = page.locator('[aria-label="To"], input[role="combobox"]').first
        await to_field.type(to_email, delay=random.randint(30, 70))
        await asyncio.sleep(random.uniform(1, 2))
        await page.keyboard.press("Tab")

        subj_field = page.locator('[aria-label="Add a subject"]')
        await subj_field.type(subject, delay=random.randint(25, 60))

        body_el = page.locator('[aria-label="Message body"], [role="textbox"]').first
        await body_el.type(body, delay=random.randint(10, 35))
        await asyncio.sleep(random.uniform(0.5, 2))

        await page.click('[aria-label="Send"], button:has-text("Send")')
        await asyncio.sleep(random.uniform(2, 4))


async def run_work_task(
    farm_ids: list[int],
    database_ids: list[int],
    link_database_ids: list[int],
    template_ids: list[int],
    emails_per_day_min: int = 25,
    emails_per_day_max: int = 75,
    delay_min: int = 30,
    delay_max: int = 180,
    max_link_uses: int = 0,
    threads: int = 10,
):
    """
    Run mass mailing campaign.
    """
    """
    from ...models import Template, LinkDatabase, Link

    db = SessionLocal()
    try:
        # Load farms + accounts
        farms = db.query(Farm).filter(Farm.id.in_(farm_ids)).all()
        all_accounts = []
        for farm in farms:
            all_accounts.extend(farm.accounts)
        accounts = [a for a in all_accounts if a.status in ("ready", "sending", "warming")]

        if not accounts:
            logger.error("Work: no eligible accounts")
            return

        # Load recipients
        all_recipients = []
        for db_id in database_ids:
            db_record = db.query(RecipientDatabase).get(db_id)
            if db_record:
                all_recipients.extend(_load_recipients(db_record))

        if not all_recipients:
            logger.error("Work: no recipients loaded")
            return

        # Load links from databases (files)
        all_links = []
        for ldb_id in link_database_ids:
            ldb = db.query(LinkDatabase).get(ldb_id)
            if ldb:
                # Load file content
                fpath = Path("user_data/links") / ldb.file_path
                if fpath.exists():
                    with open(fpath, "r", encoding="utf-8") as f:
                        lines = [l.strip() for l in f if l.strip().startswith("http")]
                        # Convert to temporary objects for Rotator
                        # We don't track per-link stats in DB for file-based links, 
                        # but we track usage in memory for max_link_uses
                        for url in lines:
                             all_links.append(Link(url=url, use_count=0))

        link_rotator = LinkRotator(all_links, max_uses=max_link_uses)

        # Load templates
        templates = db.query(Template).filter(Template.id.in_(template_ids)).all()
        # Group by pack to rotate packs or just flat list? Flat list for now
        template_pairs = [(t.subject, t.body) for t in templates]

        if not template_pairs:
            logger.error("Work: no templates")
            return

        logger.info(
            f"Work: {len(accounts)} accounts, {len(all_recipients)} recipients, "
            f"{len(links)} links, {len(template_pairs)} templates, {threads} threads"
        )

        # Create task
        task = Task(
            type="work",
            status=TaskStatus.RUNNING,
            total_items=len(all_recipients),
            thread_count=threads,
            details=f"Sending to {len(all_recipients)} recipients via {len(accounts)} accounts",
        )
        db.add(task)
        db.commit()

        # Distribute recipients across accounts
        # Split recipients evenly across accounts
        per_account = max(1, len(all_recipients) // len(accounts))
        account_batches = []
        for i, account in enumerate(accounts):
            start = i * per_account
            end = start + per_account if i < len(accounts) - 1 else len(all_recipients)
            batch = all_recipients[start:end]
            if batch:
                account_batches.append((account, batch))

        # Start browser engine
        browser_manager = BrowserManager(headless=False)
        await browser_manager.start()

        try:
            semaphore = asyncio.Semaphore(threads)

            async def process_account(account, recipients_batch):
                async with semaphore:
                    # Check time window


                    thread_log = ThreadLog(
                        task_id=task.id,
                        thread_type="work",
                        status="running",
                        account_email=account.email,
                    )
                    db.add(thread_log)
                    db.commit()

                    session = WorkSession(
                        account=account,
                        browser_manager=browser_manager,
                        templates=template_pairs,
                        link_rotator=link_rotator,
                        delay_min=delay_min,
                        delay_max=delay_max,
                        emails_per_day_min=emails_per_day_min,
                        emails_per_day_max=emails_per_day_max,
                        thread_log=thread_log,
                    )

                    result = await session.run(recipients_batch, db)

                    thread_log.status = "done"
                    thread_log.current_action = f"Done: {result['sent']} sent, {result['errors']} errors"
                    task.completed_items = (task.completed_items or 0) + result["sent"]
                    task.failed_items = (task.failed_items or 0) + result["errors"]
                    db.commit()

            # Launch all account workers with staggered start
            async_tasks = []
            for account, batch in account_batches:
                jitter = random.uniform(0, 30)
                await asyncio.sleep(jitter)
                async_tasks.append(asyncio.create_task(process_account(account, batch)))

            await asyncio.gather(*async_tasks, return_exceptions=True)

            task.status = TaskStatus.COMPLETED
            task.completed_at = datetime.utcnow()
            db.commit()

        finally:
            await browser_manager.stop()

    except Exception as e:
        logger.error(f"Work task failed: {e}")
    finally:
        db.close()
