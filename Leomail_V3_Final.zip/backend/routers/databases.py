from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import RecipientDatabase
from ..schemas import DatabaseUpload
from loguru import logger
from pathlib import Path
import re
import json

router = APIRouter(prefix="/api/databases", tags=["databases"])

DATABASES_DIR = Path("user_data/databases")


def _validate_email(email: str) -> bool:
    return bool(re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email.strip()))


@router.get("/")
async def list_databases(db: Session = Depends(get_db)):
    dbs = db.query(RecipientDatabase).order_by(RecipientDatabase.created_at.desc()).all()
    result = []
    for d in dbs:
        # Detect format from file
        has_names = False
        try:
            fp = Path(d.file_path)
            if fp.exists() and fp.suffix == '.json':
                sample = json.loads(fp.read_text(encoding='utf-8'))
                if sample and isinstance(sample, list) and sample[0].get('first_name'):
                    has_names = True
        except Exception:
            pass

        result.append({
            "id": d.id,
            "name": d.name,
            "total_count": d.total_count,
            "used_count": d.used_count,
            "invalid_count": d.invalid_count,
            "remaining": d.total_count - d.used_count,
            "with_name": has_names,
            "file_path": d.file_path,
            "created_at": d.created_at.isoformat() if d.created_at else None
        })
    return result


@router.post("/upload")
async def upload_database(req: DatabaseUpload, db: Session = Depends(get_db)):
    """
    Upload recipient database with 3 supported formats:
    1. email only           → {{EMAILNAME}}
    2. email,FirstName      → {{EMAILNAME}},{{FIRSTNAME}}
    3. email,First,Last     → {{EMAILNAME}},{{FIRSTNAME}},{{LASTNAME}}
    """
    DATABASES_DIR.mkdir(parents=True, exist_ok=True)

    valid_entries = []
    invalid_count = 0
    seen = set()

    for entry in req.entries:
        email = entry.email.strip().lower()
        if email and email not in seen:
            seen.add(email)
            if _validate_email(email):
                valid_entries.append({
                    "email": email,
                    "first_name": entry.first_name.strip() if entry.first_name else "",
                    "last_name": entry.last_name.strip() if entry.last_name else "",
                })
            else:
                invalid_count += 1

    if not valid_entries:
        return {"error": "No valid emails found"}

    # Save as JSON (preserves names)
    safe_name = re.sub(r'[^\w\-.]', '_', req.name)
    file_path = DATABASES_DIR / f"{safe_name}.json"
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(valid_entries, f, ensure_ascii=False, indent=2)

    # Save to DB
    rec_db = RecipientDatabase(
        name=req.name,
        file_path=str(file_path),
        total_count=len(valid_entries),
        invalid_count=invalid_count
    )
    db.add(rec_db)
    db.commit()
    db.refresh(rec_db)

    # Determine format type
    has_first = any(e['first_name'] for e in valid_entries)
    has_last = any(e['last_name'] for e in valid_entries)
    fmt = "email"
    if has_first and has_last:
        fmt = "email,firstname,lastname"
    elif has_first:
        fmt = "email,firstname"

    logger.info(f"Database '{req.name}' uploaded: {len(valid_entries)} entries (format: {fmt})")

    return {
        "id": rec_db.id,
        "name": rec_db.name,
        "total_count": len(valid_entries),
        "invalid_count": invalid_count,
        "format": fmt,
        "status": "uploaded"
    }


@router.get("/{db_id}")
async def get_database(db_id: int, db: Session = Depends(get_db)):
    rec = db.query(RecipientDatabase).filter(RecipientDatabase.id == db_id).first()
    if not rec:
        return {"error": "Database not found"}

    preview = []
    try:
        fp = Path(rec.file_path)
        if fp.exists():
            if fp.suffix == '.json':
                entries = json.loads(fp.read_text(encoding='utf-8'))
                for entry in entries[:50]:
                    parts = [entry['email']]
                    if entry.get('first_name'):
                        parts.append(entry['first_name'])
                    if entry.get('last_name'):
                        parts.append(entry['last_name'])
                    preview.append(','.join(parts))
            else:
                # Legacy .txt format
                with open(fp, "r", encoding="utf-8") as f:
                    for i, line in enumerate(f):
                        if i >= 50:
                            break
                        preview.append(line.strip())
    except Exception:
        pass

    return {
        "id": rec.id,
        "name": rec.name,
        "total_count": rec.total_count,
        "used_count": rec.used_count,
        "remaining": rec.total_count - rec.used_count,
        "preview": preview
    }


@router.get("/{db_id}/entries")
async def get_database_entries(db_id: int, offset: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """Get entries with full data (email, first_name, last_name) for template rendering."""
    rec = db.query(RecipientDatabase).filter(RecipientDatabase.id == db_id).first()
    if not rec:
        return {"error": "Database not found"}

    entries = []
    try:
        fp = Path(rec.file_path)
        if fp.exists() and fp.suffix == '.json':
            all_entries = json.loads(fp.read_text(encoding='utf-8'))
            entries = all_entries[offset:offset + limit]
        elif fp.exists():
            # Legacy .txt
            with open(fp, "r", encoding="utf-8") as f:
                lines = f.readlines()
            for line in lines[offset:offset + limit]:
                entries.append({"email": line.strip(), "first_name": "", "last_name": ""})
    except Exception:
        pass

    return {"entries": entries, "total": rec.total_count}


@router.delete("/{db_id}")
async def delete_database(db_id: int, db: Session = Depends(get_db)):
    rec = db.query(RecipientDatabase).filter(RecipientDatabase.id == db_id).first()
    if not rec:
        return {"error": "Database not found"}

    try:
        Path(rec.file_path).unlink(missing_ok=True)
    except Exception:
        pass

    db.delete(rec)
    db.commit()
    return {"status": "deleted"}
