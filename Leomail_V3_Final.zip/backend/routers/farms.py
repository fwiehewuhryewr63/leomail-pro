from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Farm, Account, farm_accounts
from ..schemas import FarmCreate, FarmMerge, FarmSplit
from loguru import logger

router = APIRouter(prefix="/api/farms", tags=["farms"])


@router.get("/")
async def list_farms(db: Session = Depends(get_db)):
    farms = db.query(Farm).all()
    result = []
    for farm in farms:
        accounts = farm.accounts
        providers = {}
        statuses = {"new": 0, "warming": 0, "ready": 0, "sending": 0, "dead": 0}
        for acc in accounts:
            providers[acc.provider] = providers.get(acc.provider, 0) + 1
            if acc.status in statuses:
                statuses[acc.status] += 1

        total = len(accounts)
        warmed = statuses["ready"] + statuses["sending"]
        progress = int((warmed / total) * 100) if total > 0 else 0

        result.append({
            "id": farm.id,
            "name": farm.name,
            "description": farm.description,
            "accounts_count": total,
            "providers": providers,
            "statuses": statuses,
            "warmup_progress": progress,
            "created_at": farm.created_at.isoformat() if farm.created_at else None
        })
    return result


@router.post("/")
async def create_farm(req: FarmCreate, db: Session = Depends(get_db)):
    farm = Farm(name=req.name, description=req.description)
    db.add(farm)
    db.commit()
    db.refresh(farm)
    return {"id": farm.id, "name": farm.name, "status": "created"}


@router.get("/{farm_id}")
async def get_farm(farm_id: int, db: Session = Depends(get_db)):
    farm = db.query(Farm).filter(Farm.id == farm_id).first()
    if not farm:
        return {"error": "Farm not found"}
    accounts = [
        {
            "id": a.id,
            "email": a.email,
            "provider": a.provider,
            "status": a.status,
            "warmup_day": a.warmup_day,
            "health_score": a.health_score,
            "gender": a.gender,
            "geo": a.geo,
            "proxy": a.proxy.to_string() if a.proxy else None,
        }
        for a in farm.accounts
    ]
    return {
        "id": farm.id,
        "name": farm.name,
        "description": farm.description,
        "accounts": accounts
    }


@router.delete("/{farm_id}")
async def delete_farm(farm_id: int, db: Session = Depends(get_db)):
    farm = db.query(Farm).filter(Farm.id == farm_id).first()
    if not farm:
        return {"error": "Farm not found"}
    db.delete(farm)
    db.commit()
    return {"status": "deleted", "id": farm_id}


@router.post("/merge")
async def merge_farms(req: FarmMerge, db: Session = Depends(get_db)):
    """Merge multiple farms into one new farm."""
    new_farm = Farm(name=req.target_name)
    db.add(new_farm)
    db.flush()

    merged_count = 0
    for source_id in req.source_farm_ids:
        source = db.query(Farm).filter(Farm.id == source_id).first()
        if source:
            for acc in source.accounts:
                if acc not in new_farm.accounts:
                    new_farm.accounts.append(acc)
                    merged_count += 1

    db.commit()
    return {
        "status": "merged",
        "new_farm_id": new_farm.id,
        "accounts_merged": merged_count
    }


@router.post("/split")
async def split_farm(req: FarmSplit, db: Session = Depends(get_db)):
    """Split a farm by provider, geo, or status."""
    farm = db.query(Farm).filter(Farm.id == req.farm_id).first()
    if not farm:
        return {"error": "Farm not found"}

    groups = {}
    for acc in farm.accounts:
        if req.split_by == "provider":
            key = acc.provider or "unknown"
        elif req.split_by == "geo":
            key = acc.geo or "unknown"
        elif req.split_by == "status":
            key = acc.status or "unknown"
        else:
            key = "all"
        groups.setdefault(key, []).append(acc)

    new_farms = []
    for key, accounts in groups.items():
        nf = Farm(name=f"{req.new_farm_name_prefix}_{key}")
        db.add(nf)
        db.flush()
        for acc in accounts:
            nf.accounts.append(acc)
        new_farms.append({"id": nf.id, "name": nf.name, "count": len(accounts)})

    db.commit()
    return {"status": "split", "new_farms": new_farms}


@router.get("/{farm_id}/export")
async def export_farm(farm_id: int, db: Session = Depends(get_db)):
    """Export farm accounts to portable JSON."""
    farm = db.query(Farm).filter(Farm.id == farm_id).first()
    if not farm:
        return {"error": "Farm not found"}

    return {
        "farm_name": farm.name,
        "exported_at": __import__("datetime").datetime.utcnow().isoformat(),
        "accounts": [acc.to_export() for acc in farm.accounts]
    }
