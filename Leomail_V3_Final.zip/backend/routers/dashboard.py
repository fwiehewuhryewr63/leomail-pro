from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Proxy, Account, Task, Farm, Template, RecipientDatabase, Link
from ..config import load_config, get_api_key

router = APIRouter(prefix="/api", tags=["dashboard"])


@router.get("/health")
async def health_check():
    config = load_config()
    return {
        "status": "online",
        "version": "2.0",
        "configured": {
            "sms": bool(get_api_key("grizzly")),
            "captcha": bool(get_api_key("capguru")),
            "ai": bool(get_api_key("aiml"))
        }
    }


@router.get("/dashboard")
async def dashboard(db: Session = Depends(get_db)):
    # Account stats
    total_accounts = db.query(Account).count()
    accounts_new = db.query(Account).filter(Account.status == "new").count()
    accounts_warming = db.query(Account).filter(Account.status == "warming").count()
    accounts_ready = db.query(Account).filter(Account.status == "ready").count()
    accounts_sending = db.query(Account).filter(Account.status == "sending").count()
    accounts_dead = db.query(Account).filter(Account.status.in_(["dead", "banned"])).count()

    # Proxy stats
    total_proxies = db.query(Proxy).count()
    proxies_alive = db.query(Proxy).filter(Proxy.status == "active").count()
    proxies_dead = db.query(Proxy).filter(Proxy.status == "dead").count()

    # Other counts
    farms_count = db.query(Farm).count()
    templates_count = db.query(Template).count()
    databases_count = db.query(RecipientDatabase).count()
    links_count = db.query(Link).count()

    # Active tasks
    running_tasks = db.query(Task).filter(Task.status == "running").count()

    return {
        "accounts": {
            "total": total_accounts,
            "new": accounts_new,
            "warming": accounts_warming,
            "ready": accounts_ready,
            "sending": accounts_sending,
            "dead": accounts_dead
        },
        "proxies": {
            "total": total_proxies,
            "alive": proxies_alive,
            "dead": proxies_dead,
        },
        "farms": farms_count,
        "templates": templates_count,
        "databases": databases_count,
        "links": links_count,
        "active_tasks": running_tasks
    }
