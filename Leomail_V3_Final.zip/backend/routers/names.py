"""
Leomail v3 — Names Resource API
Upload, manage, and query name lists for Birth module.
"""
import os
import random
from pathlib import Path
from fastapi import APIRouter, Depends, UploadFile, File, Form
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import NameDatabase
from loguru import logger

router = APIRouter(prefix="/api/names", tags=["names"])

NAMES_DIR = Path("user_data/names")


@router.get("/")
async def list_name_databases(db: Session = Depends(get_db)):
    """List all uploaded name databases."""
    dbs = db.query(NameDatabase).order_by(NameDatabase.created_at.desc()).all()
    return [{
        "id": d.id,
        "name": d.name,
        "country": d.country,
        "gender": d.gender,
        "total_count": d.total_count,
        "created_at": d.created_at.isoformat() if d.created_at else None,
    } for d in dbs]


@router.post("/upload")
async def upload_names(
    file: UploadFile = File(...),
    name: str = Form("Names"),
    country: str = Form("any"),
    gender: str = Form("any"),
    db: Session = Depends(get_db),
):
    """
    Upload a .txt file with names. Format: FirstName,LastName per line.
    Also supports: FirstName only (per line).
    """
    NAMES_DIR.mkdir(parents=True, exist_ok=True)

    content = await file.read()
    text = content.decode("utf-8", errors="ignore")
    lines = [l.strip() for l in text.splitlines() if l.strip()]

    if not lines:
        return {"error": "File is empty"}

    # Validate and count
    valid_lines = []
    for line in lines:
        parts = line.split(",")
        if len(parts) >= 2:
            valid_lines.append(f"{parts[0].strip()},{parts[1].strip()}")
        elif len(parts) == 1 and parts[0].strip():
            valid_lines.append(parts[0].strip())

    if not valid_lines:
        return {"error": "No valid names found. Format: FirstName,LastName (one per line)"}

    # Save file
    filename = f"{country}_{gender}_{len(valid_lines)}.txt"
    filepath = NAMES_DIR / filename
    with open(filepath, "w", encoding="utf-8") as f:
        f.write("\n".join(valid_lines))

    # Save to DB
    name_db = NameDatabase(
        name=name,
        file_path=filename,
        country=country.lower(),
        gender=gender.lower(),
        total_count=len(valid_lines),
    )
    db.add(name_db)
    db.commit()
    db.refresh(name_db)

    logger.info(f"Names uploaded: {name} → {len(valid_lines)} names ({country}/{gender})")
    return {
        "id": name_db.id,
        "name": name_db.name,
        "total_count": name_db.total_count,
        "country": name_db.country,
        "gender": name_db.gender,
    }


@router.delete("/{name_db_id}")
async def delete_name_database(name_db_id: int, db: Session = Depends(get_db)):
    """Delete a name database."""
    name_db = db.query(NameDatabase).get(name_db_id)
    if not name_db:
        return {"error": "Not found"}

    # Delete file
    filepath = NAMES_DIR / name_db.file_path
    if filepath.exists():
        os.remove(filepath)

    db.delete(name_db)
    db.commit()
    return {"status": "deleted"}


@router.get("/random")
async def get_random_name(country: str = "any", gender: str = "any", db: Session = Depends(get_db)):
    """Get a random name from uploaded databases."""
    result = pick_random_name(db, country, gender)
    if result:
        return {"first_name": result[0], "last_name": result[1]}
    return {"error": "No name databases uploaded. Upload a names file first."}


def pick_random_name(db: Session, country: str = "any", gender: str = "any") -> tuple | None:
    """
    Pick a random name from uploaded databases.
    Returns (first_name, last_name) or None.
    """
    # Find matching databases
    query = db.query(NameDatabase)
    if country != "any":
        query = query.filter(
            (NameDatabase.country == country.lower()) | (NameDatabase.country == "any")
        )
    if gender != "any":
        query = query.filter(
            (NameDatabase.gender == gender.lower()) | (NameDatabase.gender == "any")
        )

    name_dbs = query.all()
    if not name_dbs:
        # Fallback: any database
        name_dbs = db.query(NameDatabase).all()

    if not name_dbs:
        return None

    # Pick random database (weighted by count)
    weights = [d.total_count for d in name_dbs]
    chosen_db = random.choices(name_dbs, weights=weights, k=1)[0]

    # Read file and pick random line
    filepath = NAMES_DIR / chosen_db.file_path
    if not filepath.exists():
        return None

    with open(filepath, "r", encoding="utf-8") as f:
        lines = [l.strip() for l in f.readlines() if l.strip()]

    if not lines:
        return None

    line = random.choice(lines)
    parts = line.split(",")

    if len(parts) >= 2:
        return (parts[0].strip(), parts[1].strip())
    else:
        return (parts[0].strip(), "")
