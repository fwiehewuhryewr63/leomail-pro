from fastapi import APIRouter, Depends, UploadFile, File
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import LinkDatabase
from ..config import CONFIG_DIR
from loguru import logger
import shutil
import os

router = APIRouter(prefix="/api/links", tags=["links"])

LINKS_DIR = CONFIG_DIR / "links"
LINKS_DIR.mkdir(parents=True, exist_ok=True)


@router.get("/")
async def list_link_databases(db: Session = Depends(get_db)):
    """List all link packs."""
    dbs = db.query(LinkDatabase).order_by(LinkDatabase.created_at.desc()).all()
    return [{
        "id": d.id,
        "name": d.name,
        "total_count": d.total_count,
        "created_at": d.created_at.isoformat()
    } for d in dbs]


@router.post("/upload")
async def upload_link_database(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload a text file with links (one per line)."""
    try:
        content = await file.read()
        text = content.decode("utf-8", errors="ignore")
        
        # Parse and count
        lines = [l.strip() for l in text.split("\n") if l.strip().startswith("http")]
        count = len(lines)
        
        if count == 0:
            return {"error": "No valid links found (must start with http/https)"}

        # Save file
        filename = f"{int(os.path.getctime(os.path.join('.')) if os.path.exists('.') else 0)}_{file.filename}"
        file_path = LINKS_DIR / filename
        
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines))
            
        # Create DB entry
        link_db = LinkDatabase(
            name=file.filename,
            file_path=str(file_path.relative_to(CONFIG_DIR)),
            total_count=count
        )
        db.add(link_db)
        db.commit()
        
        return {"status": "ok", "count": count, "name": file.filename}
        
    except Exception as e:
        logger.error(f"Link upload error: {e}")
        return {"error": str(e)}


@router.delete("/{id}")
async def delete_link_database(id: int, db: Session = Depends(get_db)):
    link_db = db.query(LinkDatabase).filter(LinkDatabase.id == id).first()
    if not link_db:
        return {"error": "Not found"}
        
    # Try delete file
    try:
        full_path = CONFIG_DIR / link_db.file_path
        if full_path.exists():
            os.remove(full_path)
    except Exception:
        pass
        
    db.delete(link_db)
    db.commit()
    return {"status": "deleted"}
