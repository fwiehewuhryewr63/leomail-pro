"""
Leomail v3 — Birth Router
Pooled registration of Gmail/Outlook accounts with captcha, SMS, profiles.
"""
from fastapi import APIRouter, Depends, BackgroundTasks
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ..database import get_db, SessionLocal
from ..models import Proxy, ProxyStatus, Task, TaskStatus, Account, Farm, ThreadLog
from ..modules.browser_manager import BrowserManager
from ..services.captcha_provider import CaptchaProvider
from ..services.sms_provider import GrizzlySMS
from ..services.simsms_provider import SimSmsProvider
from ..services.proxy_manager import ProxyManager
from ..utils import generate_random_name, generate_birthday, generate_password, generate_username
from ..config import load_config, get_api_key
from loguru import logger
import asyncio
import random
from datetime import datetime

router = APIRouter(prefix="/api/birth", tags=["birth"])


class BirthRequest(BaseModel):
    provider: str = "outlook"  # gmail, outlook
    quantity: int = 1
    device_type: str = "desktop"  # desktop, phone_android, phone_ios
    geo: str = "any"
    sms_provider: str = "simsms"  # simsms, grizzly
    threads: int = 1
    farm_name: str = ""  # auto-generated if empty


def _get_sms_provider(provider_name: str):
    """Get configured SMS provider."""
    config = load_config()
    if provider_name == "grizzly":
        key = config.get("sms", {}).get("grizzly", {}).get("api_key", "")
        return GrizzlySMS(key) if key else None
    else:
        key = config.get("sms", {}).get("simsms", {}).get("api_key", "")
        return SimSmsProvider(key) if key else None


def _get_captcha_provider():
    key = get_api_key("capguru") or ""
    return CaptchaProvider(api_key=key) if key else None


async def register_single_outlook(
    browser_manager: BrowserManager,
    proxy: Proxy | None,
    device_type: str,
    geo: str,
    captcha_provider: CaptchaProvider | None,
    db: Session,
    thread_log: ThreadLog | None = None,
) -> Account | None:
    """Register a single Outlook account."""
    first_name, last_name = generate_random_name(db, country=geo)
    password = generate_password()
    birthday = generate_birthday()
    username = generate_username(first_name, last_name)

    context = await browser_manager.create_context(
        proxy=proxy,
        device_type=device_type,
        geo=geo if geo != "any" else None,
    )

    try:
        page = await context.new_page()

        # Update log
        if thread_log:
            thread_log.current_action = f"Opening signup page..."
            db.commit()

        await page.goto("https://signup.live.com/signup", wait_until="domcontentloaded", timeout=30000)
        await asyncio.sleep(random.uniform(2, 4))

        # Enter email
        email = f"{username}@outlook.com"
        if thread_log:
            thread_log.current_action = f"Entering email: {email}"
            db.commit()

        email_field = page.locator('#MemberName, input[name="MemberName"]')
        await email_field.type(email, delay=random.randint(40, 90))
        await asyncio.sleep(random.uniform(0.5, 1.5))
        await page.click('#iSignupAction, input[type="submit"]')
        await asyncio.sleep(random.uniform(2, 4))

        # Enter password
        if thread_log:
            thread_log.current_action = "Entering password..."
            db.commit()

        pwd_field = page.locator('#PasswordInput, input[name="Password"]')
        await pwd_field.type(password, delay=random.randint(35, 75))
        await asyncio.sleep(random.uniform(0.5, 1))
        await page.click('#iSignupAction, input[type="submit"]')
        await asyncio.sleep(random.uniform(2, 4))

        # Enter name
        if thread_log:
            thread_log.current_action = f"Entering name: {first_name} {last_name}"
            db.commit()

        fn_field = page.locator('#FirstName, input[name="FirstName"]')
        await fn_field.type(first_name, delay=random.randint(40, 80))
        ln_field = page.locator('#LastName, input[name="LastName"]')
        await ln_field.type(last_name, delay=random.randint(40, 80))
        await asyncio.sleep(random.uniform(0.5, 1))
        await page.click('#iSignupAction, input[type="submit"]')
        await asyncio.sleep(random.uniform(2, 4))

        # Enter birthday
        if thread_log:
            thread_log.current_action = "Entering birthday..."
            db.commit()

        # Month dropdown
        await page.select_option('#BirthMonth', str(birthday.month))
        await asyncio.sleep(random.uniform(0.3, 0.8))
        # Day dropdown
        await page.select_option('#BirthDay', str(birthday.day))
        await asyncio.sleep(random.uniform(0.3, 0.8))
        # Year
        year_field = page.locator('#BirthYear')
        await year_field.fill(str(birthday.year))
        await asyncio.sleep(random.uniform(0.5, 1))
        await page.click('#iSignupAction, input[type="submit"]')
        await asyncio.sleep(random.uniform(3, 6))

        # CAPTCHA handling
        captcha_frame = page.locator('#enforcementFrame, iframe[title*="captcha"]')
        if await captcha_frame.count() > 0 and captcha_provider:
            if thread_log:
                thread_log.current_action = "Solving captcha..."
                db.commit()

            try:
                site_key = "B7D8911C-5CC8-A9A3-35B0-554ACEE604DA"  # Outlook FunCaptcha key
                token = await asyncio.wait_for(
                    asyncio.to_thread(captcha_provider.solve_funcaptcha, site_key, page.url),
                    timeout=120,
                )
                if token:
                    await page.evaluate(f'document.getElementById("enforcementFrame").contentWindow.postMessage({{"token":"{token}"}}, "*")')
                    await asyncio.sleep(random.uniform(3, 6))
            except Exception as e:
                logger.warning(f"Captcha failed: {e}")

        # Save session
        session_path = await browser_manager.save_session(context, 0)  # temp ID

        # Check if registration succeeded
        if thread_log:
            thread_log.current_action = "Verifying registration..."
            db.commit()

        # Create account record
        account = Account(
            email=email,
            password=password,
            provider="outlook",
            first_name=first_name,
            last_name=last_name,
            gender="random",
            birthday=birthday,
            geo=geo,
            birth_ip=f"{proxy.host}" if proxy else None,
            user_agent=context._options.get("user_agent", ""),
            status="new",
        )
        db.add(account)
        db.commit()
        db.refresh(account)

        # Re-save session with real account ID
        account.browser_profile_path = await browser_manager.save_session(context, account.id)
        db.commit()

        logger.info(f"✅ Registered: {email}")
        return account

    except Exception as e:
        logger.error(f"❌ Registration failed: {e}")
        if thread_log:
            thread_log.error_message = str(e)[:500]
            db.commit()
        return None
    finally:
        await browser_manager.close_context(context)


async def run_birth_task(request: BirthRequest):
    """Run birth registration pool."""
    db = SessionLocal()
    try:
        # Create task record
        task = Task(
            type="birth",
            status=TaskStatus.RUNNING,
            total_items=request.quantity,
            thread_count=request.threads,
            details=f"Registering {request.quantity} {request.provider} accounts",
        )
        db.add(task)
        db.commit()

        # Create farm
        farm_name = request.farm_name or f"Birth_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        farm = Farm(name=farm_name, description=f"{request.quantity}x {request.provider}")
        db.add(farm)
        db.commit()

        # Get proxy pool
        proxy_manager = ProxyManager(db)
        proxy_pool = proxy_manager.get_proxy_pool(request.quantity, geo=request.geo)

        # Get providers
        captcha = _get_captcha_provider()
        sms = _get_sms_provider(request.sms_provider)

        # Start browser
        browser_manager = BrowserManager(headless=False)
        await browser_manager.start()

        try:
            semaphore = asyncio.Semaphore(request.threads)
            registered_accounts = []

            async def register_one(index: int):
                async with semaphore:
                    proxy = proxy_pool[index % len(proxy_pool)] if proxy_pool else None

                    thread_log = ThreadLog(
                        task_id=task.id,
                        thread_index=index,
                        thread_type="birth",
                        status="running",
                        proxy_info=proxy.to_string() if proxy else "No proxy",
                    )
                    db.add(thread_log)
                    db.commit()

                    account = None
                    if request.provider == "outlook":
                        account = await register_single_outlook(
                            browser_manager, proxy, request.device_type,
                            request.geo, captcha, db, thread_log,
                        )
                    elif request.provider == "gmail":
                        # Gmail registration flow (TODO: full implementation)
                        thread_log.current_action = "Gmail registration not fully implemented yet"
                        db.commit()
                        # Placeholder — needs full Gmail signup flow with SMS
                        pass

                    if account:
                        farm.accounts.append(account)
                        registered_accounts.append(account)
                        task.completed_items = (task.completed_items or 0) + 1
                        thread_log.status = "done"
                        thread_log.account_email = account.email
                    else:
                        task.failed_items = (task.failed_items or 0) + 1
                        thread_log.status = "error"

                    db.commit()

            # Staggered launch
            tasks = []
            for i in range(request.quantity):
                jitter = random.uniform(0, 5)
                await asyncio.sleep(jitter)
                tasks.append(asyncio.create_task(register_one(i)))

            await asyncio.gather(*tasks, return_exceptions=True)

            task.status = TaskStatus.COMPLETED
            task.completed_at = datetime.utcnow()
            db.commit()

            logger.info(f"Birth complete: {len(registered_accounts)}/{request.quantity} registered, farm: {farm_name}")

        finally:
            await browser_manager.stop()

    except Exception as e:
        logger.error(f"Birth task failed: {e}")
    finally:
        db.close()


@router.post("/start")
async def start_registration(request: BirthRequest, background_tasks: BackgroundTasks):
    """Start account registration in background."""
    background_tasks.add_task(run_birth_task, request)
    return {
        "status": "started",
        "message": f"Starting {request.quantity} {request.provider} registration(s), {request.threads} thread(s)",
    }
