"""
Leomail v3 — Warmup Router
API endpoints for starting and managing warmup campaigns.
"""
from fastapi import APIRouter, Depends, BackgroundTasks
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ..database import get_db
from ..modules.warmup.engine import run_warmup_task

router = APIRouter(prefix="/api/warmup", tags=["warmup"])


class WarmupRequest(BaseModel):
    farm_ids: list[int]
    template_subject: str = "{Hi|Hello|Hey}!"
    template_body: str = "{Just checking in|Wanted to say hi|Hope you're doing well}."
    emails_per_day_min: int = 1
    emails_per_day_max: int = 5
    delay_min: int = 60       # seconds
    delay_max: int = 300      # seconds
    same_provider: bool = False
    same_provider: bool = False
    threads: int = 5


@router.post("/start")
async def start_warmup(request: WarmupRequest, background_tasks: BackgroundTasks):
    """Start warmup campaign in background."""
    background_tasks.add_task(
        run_warmup_task,
        farm_ids=request.farm_ids,
        template_subject=request.template_subject,
        template_body=request.template_body,
        emails_per_day_min=request.emails_per_day_min,
        emails_per_day_max=request.emails_per_day_max,
        delay_min=request.delay_min,
        delay_max=request.delay_max,
        same_provider=request.same_provider,
        threads=request.threads,
    )
    return {
        "status": "started",
        "message": f"Warmup started for {len(request.farm_ids)} farm(s), {request.threads} threads",
    }
