"""
Leomail v3 — Work (Mailing) Router
API endpoints for starting and managing mass mailing campaigns.
"""
from fastapi import APIRouter, BackgroundTasks
from pydantic import BaseModel
from ..modules.work.engine import run_work_task

router = APIRouter(prefix="/api/work", tags=["work"])


class WorkRequest(BaseModel):
    farm_ids: list[int]
    database_ids: list[int]
    link_database_ids: list[int] = []
    template_ids: list[int]
    emails_per_day_min: int = 25
    emails_per_day_max: int = 75
    delay_min: int = 30        # seconds
    delay_max: int = 180       # seconds
    max_link_uses: int = 0     # 0 = unlimited
    threads: int = 10
    threads: int = 10


@router.post("/start")
async def start_work(request: WorkRequest, background_tasks: BackgroundTasks):
    """Start mass mailing campaign in background."""
    background_tasks.add_task(
        run_work_task,
        farm_ids=request.farm_ids,
        database_ids=request.database_ids,
        database_ids=request.database_ids,
        link_database_ids=request.link_database_ids,
        template_ids=request.template_ids,
        emails_per_day_min=request.emails_per_day_min,
        emails_per_day_max=request.emails_per_day_max,
        delay_min=request.delay_min,
        delay_max=request.delay_max,
        max_link_uses=request.max_link_uses,
        threads=request.threads,
        threads=request.threads,
    )
    return {
        "status": "started",
        "message": (
            f"Mailing started: {len(request.farm_ids)} farm(s), "
            f"{len(request.database_ids)} database(s), {request.threads} threads"
        ),
    }
