"""
Leomail v2.1 — Resource Calculator API
Serves server health + thread recommendations
"""
from fastapi import APIRouter
from ..services.resource_calculator import ResourceCalculator

router = APIRouter(prefix="/api/resources", tags=["resources"])


@router.get("/health")
async def server_health():
    """Overall server health for dashboard."""
    return ResourceCalculator.get_health_status()


@router.get("/threads/{task_type}")
async def recommend_threads(task_type: str, proxies: int = 999, active: int = 0):
    """
    Get recommended thread count for a task.
    task_type: birth | warmup | work
    proxies: how many free proxies are available
    active: how many threads are already running
    """
    if task_type not in ("birth", "warmup", "work"):
        return {"error": "task_type must be: birth, warmup, work"}
    return ResourceCalculator.get_max_threads(task_type, proxies, active)


@router.get("/system")
async def system_resources():
    """Raw system resource snapshot."""
    return ResourceCalculator.get_system_resources()
