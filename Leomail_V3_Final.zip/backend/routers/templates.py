from fastapi import APIRouter, Depends, UploadFile, File
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Template
from ..schemas import TemplateCreate
from loguru import logger
import zipfile
import json
import io
import re
import os


router = APIRouter(prefix="/api/templates", tags=["templates"])

TEMPLATE_VARS = ["LINK", "FIRSTNAME", "LASTNAME", "EMAILNAME"]


def detect_variables(text: str) -> list:
    """Detect {{VAR}} variables in text."""
    found = set()
    for var in TEMPLATE_VARS:
        if "{{" + var + "}}" in text.upper():
            found.add(var)
    return sorted(list(found))


@router.get("/packs")
async def list_template_packs(db: Session = Depends(get_db)):
    """List unique packs with count."""
    from sqlalchemy import func
    packs = db.query(
        Template.pack_name, func.count(Template.id)
    ).group_by(Template.pack_name).all()
    
    return [
        {"name": p[0], "count": p[1]} 
        for p in packs if p[0]
    ]


@router.get("/")
async def list_templates(db: Session = Depends(get_db)):
    templates = db.query(Template).order_by(Template.created_at.desc()).all()
    return [
        {
            "id": t.id,
            "name": t.name,
            "subject": t.subject,
            "content_type": t.content_type,
            "language": t.language,
            "pack_name": t.pack_name,
            "variables": t.variables or [],
            "created_at": t.created_at.isoformat() if t.created_at else None,
            "body_preview": t.body[:200] if t.body else ""
        }
        for t in templates
    ]


@router.post("/")
async def create_template(req: TemplateCreate, db: Session = Depends(get_db)):
    variables = detect_variables(req.subject + " " + req.body)
    template = Template(
        name=req.name,
        subject=req.subject,
        body=req.body,
        content_type=req.content_type,
        language=req.language,
        variables=variables,
    )
    db.add(template)
    db.commit()
    db.refresh(template)
    return {"id": template.id, "status": "created", "variables": variables}


@router.get("/{template_id}")
async def get_template(template_id: int, db: Session = Depends(get_db)):
    t = db.query(Template).filter(Template.id == template_id).first()
    if not t:
        return {"error": "Template not found"}
    return {
        "id": t.id,
        "name": t.name,
        "subject": t.subject,
        "body": t.body,
        "content_type": t.content_type,
        "language": t.language,
        "pack_name": t.pack_name,
        "variables": t.variables or [],
        "created_at": t.created_at.isoformat() if t.created_at else None,
    }


@router.delete("/{template_id}")
async def delete_template(template_id: int, db: Session = Depends(get_db)):
    t = db.query(Template).filter(Template.id == template_id).first()
    if not t:
        return {"error": "Template not found"}
    db.delete(t)
    db.commit()
    return {"status": "deleted"}


@router.delete("/pack/{pack_name}")
async def delete_pack(pack_name: str, db: Session = Depends(get_db)):
    """Delete all templates from a pack."""
    templates = db.query(Template).filter(Template.pack_name == pack_name).all()
    count = len(templates)
    for t in templates:
        db.delete(t)
    db.commit()
    return {"status": "deleted", "count": count}


@router.post("/import-zip")
async def import_zip(file: UploadFile = File(...), db: Session = Depends(get_db)):
    """
    Import templates from a ZIP archive.
    
    Supported formats:
    1. manifest.json + templates/*.html
    2. Flat .html files with first line "Subject: ..."
    """
    try:
        contents = await file.read()
        zf = zipfile.ZipFile(io.BytesIO(contents))
    except Exception as e:
        return {"error": f"Invalid ZIP file: {str(e)}"}

    file_list = zf.namelist()
    imported = 0
    errors = []
    pack_name = file.filename.replace(".zip", "") if file.filename else "imported"

    # Check for manifest.json
    manifest = None
    manifest_paths = [f for f in file_list if f.endswith("manifest.json")]
    if manifest_paths:
        try:
            manifest_data = zf.read(manifest_paths[0]).decode("utf-8")
            manifest = json.loads(manifest_data)
            if manifest.get("pack_name"):
                pack_name = manifest["pack_name"]
        except Exception as e:
            errors.append(f"manifest.json parse error: {e}")
            manifest = None

    if manifest and manifest.get("templates"):
        # Mode 1: manifest-based import
        base_dir = os.path.dirname(manifest_paths[0])
        for tmpl_info in manifest["templates"]:
            tmpl_file = tmpl_info.get("file", "")
            subject = tmpl_info.get("subject", "No Subject")
            name = tmpl_info.get("name", tmpl_file.replace(".html", ""))

            # Find the file in ZIP
            search_paths = [
                os.path.join(base_dir, "templates", tmpl_file).replace("\\", "/"),
                os.path.join(base_dir, tmpl_file).replace("\\", "/"),
                f"templates/{tmpl_file}",
                tmpl_file,
            ]
            body = None
            for sp in search_paths:
                if sp in file_list:
                    body = zf.read(sp).decode("utf-8", errors="replace")
                    break

            if body is None:
                errors.append(f"File not found: {tmpl_file}")
                continue

            variables = detect_variables(subject + " " + body)
            template = Template(
                name=name,
                subject=subject,
                body=body,
                content_type="html",
                pack_name=pack_name,
                variables=variables,
            )
            db.add(template)
            imported += 1
    else:
        # Mode 2: flat HTML files (fallback)
        html_files = [f for f in file_list if f.endswith((".html", ".htm")) and not f.startswith("__MACOSX")]
        for hf in html_files:
            try:
                content = zf.read(hf).decode("utf-8", errors="replace")
                lines = content.strip().split("\n", 1)

                # Check if first line is Subject:
                if lines[0].strip().lower().startswith("subject:"):
                    subject = lines[0].strip()[8:].strip()
                    body = lines[1].strip() if len(lines) > 1 else ""
                else:
                    subject = os.path.basename(hf).replace(".html", "").replace(".htm", "")
                    body = content

                name = os.path.basename(hf).replace(".html", "").replace(".htm", "")
                variables = detect_variables(subject + " " + body)

                template = Template(
                    name=name,
                    subject=subject,
                    body=body,
                    content_type="html",
                    pack_name=pack_name,
                    variables=variables,
                )
                db.add(template)
                imported += 1
            except Exception as e:
                errors.append(f"{hf}: {e}")

    db.commit()
    logger.info(f"Imported {imported} templates from ZIP '{pack_name}'")

    return {
        "status": "ok",
        "imported": imported,
        "errors": errors,
        "pack_name": pack_name,
    }
