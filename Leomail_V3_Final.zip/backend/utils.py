"""
Leomail v3 — Utilities
Name generation from uploaded databases (with fallback to human_engine).
"""
import random
import string
from datetime import datetime


def generate_random_name(db=None, country: str = "any", gender: str = "any") -> tuple[str, str]:
    """
    Generate a random name. Tries uploaded name databases first, falls back to built-in.
    Returns: (first_name, last_name)
    """
    # Try uploaded names database
    if db:
        try:
            from .routers.names import pick_random_name
            result = pick_random_name(db, country, gender)
            if result:
                return result
        except Exception:
            pass

    # Fallback: built-in names from human_engine
    try:
        from .services.human_engine import human_engine
        identity = human_engine.generate_identity(country if country != "any" else "us", gender if gender != "any" else None)
        return (identity.get("first_name", "Alex"), identity.get("last_name", "Johnson"))
    except Exception:
        pass

    # Ultimate fallback
    FALLBACK_FIRST = [
        "James", "Mary", "Robert", "Patricia", "John", "Jennifer", "Michael", "Linda",
        "David", "Elizabeth", "William", "Barbara", "Richard", "Susan", "Joseph", "Jessica",
        "Thomas", "Sarah", "Christopher", "Karen", "Daniel", "Lisa", "Matthew", "Nancy",
        "Anthony", "Betty", "Mark", "Margaret", "Donald", "Sandra",
    ]
    FALLBACK_LAST = [
        "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
        "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson",
        "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson",
        "White", "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson",
    ]
    return (random.choice(FALLBACK_FIRST), random.choice(FALLBACK_LAST))


def generate_birthday(min_year: int = 1985, max_year: int = 2003) -> datetime:
    """Generate a random birthday."""
    year = random.randint(min_year, max_year)
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    return datetime(year, month, day)


def generate_password(length: int = 14) -> str:
    """Generate a strong random password."""
    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    digits = string.digits
    special = "!@#$%&*"

    # Ensure at least one of each type
    password = [
        random.choice(lower),
        random.choice(lower),
        random.choice(upper),
        random.choice(upper),
        random.choice(digits),
        random.choice(digits),
        random.choice(special),
    ]

    # Fill remaining
    all_chars = lower + upper + digits + special
    password += [random.choice(all_chars) for _ in range(length - len(password))]

    random.shuffle(password)
    return ''.join(password)


def generate_username(first_name: str, last_name: str) -> str:
    """Generate a plausible email username from name."""
    patterns = [
        f"{first_name.lower()}.{last_name.lower()}",
        f"{first_name.lower()}{last_name.lower()}",
        f"{first_name.lower()}.{last_name.lower()}{random.randint(1, 99)}",
        f"{first_name.lower()}{random.randint(10, 999)}",
        f"{first_name[0].lower()}{last_name.lower()}{random.randint(1, 99)}",
        f"{last_name.lower()}.{first_name.lower()}{random.randint(1, 9)}",
    ]
    return random.choice(patterns)
