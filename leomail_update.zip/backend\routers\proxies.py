from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Proxy, ProxyStatus, Account
from ..schemas import ProxyImportRequest
from ..services.proxy_monitor import monitor_all_proxies
from loguru import logger

router = APIRouter(prefix="/api/proxies", tags=["proxies"])


@router.get("/")
async def list_proxies(db: Session = Depends(get_db)):
    proxies = db.query(Proxy).all()
    result = []
    for p in proxies:
        bound_to = None
        if p.bound_account_id:
            acc = db.query(Account).filter(Account.id == p.bound_account_id).first()
            bound_to = acc.email if acc else None

        result.append({
            "id": p.id,
            "host": p.host,
            "port": p.port,
            "protocol": p.protocol,
            "proxy_type": p.proxy_type,
            "status": p.status,
            "geo": p.geo,
            "response_time_ms": p.response_time_ms,
            "fail_count": p.fail_count,
            "bound_to": bound_to,
            "last_check": p.last_check.isoformat() if p.last_check else None,
            "expires_at": p.expires_at.isoformat() if p.expires_at else None,
        })
    return result


@router.get("/stats")
async def proxy_stats(db: Session = Depends(get_db)):
    total = db.query(Proxy).count()
    active = db.query(Proxy).filter(Proxy.status == "active").count()
    dead = db.query(Proxy).filter(Proxy.status == "dead").count()
    bound = db.query(Proxy).filter(Proxy.bound_account_id.isnot(None)).count()
    avg_time = db.query(Proxy).filter(Proxy.response_time_ms.isnot(None)).all()
    avg_ms = int(sum(p.response_time_ms for p in avg_time) / len(avg_time)) if avg_time else 0

    return {
        "total": total,
        "active": active,
        "dead": dead,
        "bound": bound,
        "free": active - bound,
        "avg_response_ms": avg_ms
    }


@router.post("/import")
async def import_proxies(req: ProxyImportRequest, db: Session = Depends(get_db)):
    added = 0
    for proxy_str in req.proxies:
        parts = proxy_str.strip().split(":")
        if len(parts) < 2:
            continue

        host = parts[0]
        port = int(parts[1])
        username = parts[2] if len(parts) > 2 else None
        password = parts[3] if len(parts) > 3 else None

        # Check duplicate
        exists = db.query(Proxy).filter(
            Proxy.host == host, Proxy.port == port
        ).first()
        if exists:
            continue

        proxy = Proxy(
            host=host,
            port=port,
            username=username,
            password=password,
            protocol=req.protocol,
            proxy_type=req.proxy_type,
            geo=req.geo,
            expires_at=req.expires_at
        )
        db.add(proxy)
        added += 1

    db.commit()
    logger.info(f"Imported {added} proxies")
    return {"imported": added, "total": db.query(Proxy).count()}


@router.delete("/{proxy_id}")
async def delete_proxy(proxy_id: int, db: Session = Depends(get_db)):
    proxy = db.query(Proxy).filter(Proxy.id == proxy_id).first()
    if not proxy:
        return {"error": "Proxy not found"}
    if proxy.bound_account_id:
        return {"error": "Proxy is bound to an account. Unbind first."}
    db.delete(proxy)
    db.commit()
    return {"status": "deleted"}


@router.post("/check")
async def check_all_proxies():
    """Manual trigger for proxy health check."""
    result = await monitor_all_proxies()
    return result


@router.post("/{proxy_id}/unbind")
async def unbind_proxy(proxy_id: int, db: Session = Depends(get_db)):
    proxy = db.query(Proxy).filter(Proxy.id == proxy_id).first()
    if not proxy:
        return {"error": "Proxy not found"}
    # Clear binding from account too
    if proxy.bound_account_id:
        acc = db.query(Account).filter(Account.id == proxy.bound_account_id).first()
        if acc:
            acc.proxy_id = None
    proxy.bound_account_id = None
    db.commit()
    return {"status": "unbound"}


@router.delete("/all")
async def delete_all_proxies(db: Session = Depends(get_db)):
    """Delete all proxies that are not bound to accounts."""
    bound = db.query(Proxy).filter(Proxy.bound_account_id.isnot(None)).count()
    deleted = db.query(Proxy).filter(
        (Proxy.bound_account_id.is_(None)) | (Proxy.bound_account_id == 0)
    ).delete(synchronize_session=False)
    db.commit()
    logger.info(f"Deleted {deleted} proxies (kept {bound} bound)")
    return {"deleted": deleted, "kept_bound": bound}

