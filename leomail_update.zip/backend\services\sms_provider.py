import abc
import requests
from loguru import logger

class SMSProvider(abc.ABC):
    @abc.abstractmethod
    def get_number(self, service: str, country: str) -> str:
        pass

    @abc.abstractmethod
    def get_code(self, activation_id: str) -> str | None:
        pass

    @abc.abstractmethod
    def get_balance(self) -> str:
        pass

class GrizzlySMS(SMSProvider):
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.grizzlysms.com/stubs/handler_api.php"

    def get_number(self, service: str, country: str) -> dict:
        # Simplified implementation
        params = {
            "api_key": self.api_key,
            "action": "getNumber",
            "service": service,
            "country": country
        }
        try:
            resp = requests.get(self.base_url, params=params)
            if "ACCESS_NUMBER" in resp.text:
                parts = resp.text.split(":")
                return {"id": parts[1], "number": parts[2]}
            logger.error(f"Grizzly Error: {resp.text}")
            return None
        except Exception as e:
            logger.error(f"Grizzly Connection Error: {e}")
            return None

    def get_balance(self) -> str:
        params = {
            "api_key": self.api_key,
            "action": "getBalance"
        }
        try:
            resp = requests.get(self.base_url, params=params)
            return resp.text # ACCESS_BALANCE:xxx
        except Exception as e:
            logger.error(f"Grizzly Balance Error: {e}")
            return "0"

    def get_code(self, activation_id: str) -> str | None:
        params = {
            "api_key": self.api_key,
            "action": "getStatus",
            "id": activation_id
        }
        try:
            resp = requests.get(self.base_url, params=params)
            if "STATUS_OK" in resp.text:
                return resp.text.split(":")[1]
            return None
        except Exception as e:
            logger.error(f"Grizzly Code Error: {e}")
            return None

class SimSMS(SMSProvider):
    def __init__(self, api_key: str):
        self.api_key = api_key
        # SimSMS implementation stub
        
    def get_number(self, service: str, country: str) -> str:
        logger.warning("SimSMS not fully implemented yet")
        return None

    def get_code(self, activation_id: str) -> str | None:
        return None

    def get_balance(self) -> str:
        return "N/A"
