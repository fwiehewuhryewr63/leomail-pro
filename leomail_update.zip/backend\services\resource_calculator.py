"""
Leomail v2.2 — Resource Calculator
Realistic thread calculation based on server resources + current load
"""
import psutil
from loguru import logger


class ResourceCalculator:
    """Calculate optimal thread counts based on server capabilities."""

    # Memory per thread type (MB) — realistic values
    MEMORY_PER_THREAD = {
        "birth": 280,       # Browser + proxy (lighter with stealth)
        "warmup": 60,       # IMAP/SMTP connections
        "work": 40,         # SMTP only
    }

    # CPU usage per thread (fraction of 1 core)
    # birth: ~15% of 1 core per browser tab
    # warmup: ~3% (mostly I/O wait)
    # work: ~2% (network bound)
    CPU_PER_THREAD_CORE_FRACTION = {
        "birth": 0.15,
        "warmup": 0.03,
        "work": 0.02,
    }

    @staticmethod
    def get_system_resources() -> dict:
        """Get current server resource snapshot."""
        mem = psutil.virtual_memory()
        cpu_percent = psutil.cpu_percent(interval=0.3)
        cpu_count = psutil.cpu_count(logical=True)

        return {
            "ram_total_mb": round(mem.total / 1024 / 1024),
            "ram_available_mb": round(mem.available / 1024 / 1024),
            "ram_used_percent": mem.percent,
            "cpu_cores": cpu_count,
            "cpu_used_percent": round(cpu_percent, 1),
            "cpu_available_percent": round(100 - cpu_percent, 1),
        }

    @staticmethod
    def get_max_threads(task_type: str, available_proxies: int = 999, active_threads: int = 0) -> dict:
        """
        Calculate recommended max threads for a task type.
        Returns: {recommended, absolute_max, limiting_factor, details}
        """
        resources = ResourceCalculator.get_system_resources()
        mem_per = ResourceCalculator.MEMORY_PER_THREAD.get(task_type, 80)
        cpu_per = ResourceCalculator.CPU_PER_THREAD_CORE_FRACTION.get(task_type, 0.1)

        # RAM-based limit (leave 25% for OS + overhead)
        usable_ram = resources["ram_available_mb"] * 0.75
        ram_limit = max(2, int(usable_ram / mem_per))

        # CPU-based limit: how many threads fit into available cores
        # Available cores = total_cores * (available_percent / 100) * safety_margin
        available_cores = resources["cpu_cores"] * (resources["cpu_available_percent"] / 100) * 0.85
        cpu_limit = max(2, int(available_cores / cpu_per))

        # Proxy-based limit (for birth, need 1 proxy per thread)
        proxy_limit = available_proxies if task_type == "birth" else 9999

        # Hard caps per type to stay sane
        hard_caps = {"birth": 50, "warmup": 300, "work": 500}
        cap = hard_caps.get(task_type, 200)

        # Final calculation
        absolute_max = min(ram_limit, cpu_limit, proxy_limit, cap)
        recommended = max(2, int(absolute_max * 0.7))  # 70% safe zone

        # Subtract active threads
        recommended = max(1, recommended - active_threads)
        absolute_max = max(1, absolute_max - active_threads)

        # Determine limiting factor
        limits = {"RAM": ram_limit, "CPU": cpu_limit, "Прокси": proxy_limit, "Hard cap": cap}
        limiting = min(limits, key=limits.get)

        return {
            "recommended": recommended,
            "absolute_max": absolute_max,
            "limiting_factor": limiting,
            "details": {
                "ram_limit": ram_limit,
                "cpu_limit": cpu_limit,
                "proxy_limit": proxy_limit if task_type == "birth" else "∞",
                "hard_cap": cap,
                "active_threads": active_threads,
            },
            "resources": resources,
        }

    @staticmethod
    def get_health_status() -> dict:
        """Overall server health for dashboard."""
        res = ResourceCalculator.get_system_resources()
        if res["ram_used_percent"] > 90 or res["cpu_used_percent"] > 90:
            status = "critical"
        elif res["ram_used_percent"] > 75 or res["cpu_used_percent"] > 75:
            status = "warning"
        else:
            status = "healthy"

        return {
            "status": status,
            "resources": res,
            "can_start_tasks": status != "critical",
        }
