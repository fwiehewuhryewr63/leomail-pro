from sqlalchemy.orm import Session
from ..models import Proxy, ProxyStatus
from ..schemas import ProxyImportRequest
from datetime import datetime
from loguru import logger

class ProxyManager:
    def __init__(self, db: Session):
        self.db = db

    def import_proxies(self, raw_list: list[str], expires_at: datetime | None = None) -> int:
        count = 0
        for line in raw_list:
            try:
                parts = line.strip().split(":")
                if len(parts) >= 4:
                    host, port, user, password = parts[0], int(parts[1]), parts[2], parts[3]
                    proxy = Proxy(
                        host=host,
                        port=port,
                        username=user,
                        password=password,
                        protocol="http", # Default, can be auto-detected later
                        expires_at=expires_at,
                        status=ProxyStatus.ACTIVE
                    )
                    self.db.add(proxy)
                    count += 1
                elif len(parts) == 2: # IP:PORT (Authless)
                    host, port = parts[0], int(parts[1])
                    proxy = Proxy(
                        host=host,
                        port=port,
                        protocol="http",
                        expires_at=expires_at,
                        status=ProxyStatus.ACTIVE
                    )
                    self.db.add(proxy)
                    count += 1
            except Exception as e:
                logger.error(f"Failed to parse proxy line '{line}': {e}")
        
        self.db.commit()
        return count

    def get_working_proxy(self):
        # Logic to return a random active proxy
        # TODO: Implement rotation logic
        return self.db.query(Proxy).filter(Proxy.status == ProxyStatus.ACTIVE).first()
