from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional, List
from ..config import load_config, save_config, get_api_key
from ..services.ai_provider import AIProvider, AVAILABLE_MODELS, get_ai_provider
from loguru import logger

router = APIRouter(prefix="/api/ai", tags=["ai"])


class ChatRequest(BaseModel):
    message: str
    model: Optional[str] = None
    system_prompt: Optional[str] = None
    temperature: float = 0.7
    history: Optional[List[dict]] = None  # previous messages for context


class EmailGenRequest(BaseModel):
    topic: str
    tone: str = "professional"
    language: str = "en"
    model: Optional[str] = None


class AnalyzeRequest(BaseModel):
    accounts_summary: Optional[dict] = None
    model: Optional[str] = None


class WarmupRequest(BaseModel):
    total_accounts: int = 10
    ready_accounts: int = 0
    days: int = 14
    model: Optional[str] = None


class ModelSelectRequest(BaseModel):
    model: str


@router.get("/models")
async def list_models():
    """Return available AI models."""
    config = load_config()
    current = config.get("ai", {}).get("aiml", {}).get("model", "gpt-4o")
    has_key = bool(get_api_key("aiml"))
    return {
        "models": AVAILABLE_MODELS,
        "current": current,
        "configured": has_key
    }


@router.post("/model")
async def set_model(req: ModelSelectRequest):
    """Set the active AI model."""
    config = load_config()
    config.setdefault("ai", {}).setdefault("aiml", {})["model"] = req.model
    save_config(config)
    return {"status": "ok", "model": req.model}


@router.post("/chat")
async def ai_chat(req: ChatRequest):
    """Free-form AI chat."""
    provider = get_ai_provider()
    if not provider:
        return {"error": "AIML API key not configured. Add it in Settings."}

    messages = []
    if req.system_prompt:
        messages.append({"role": "system", "content": req.system_prompt})
    else:
        messages.append({
            "role": "system",
            "content": (
                "You are Leomail AI — an elite email marketing strategist and social engineering expert. "
                "You specialize in:\n"
                "1. Creating high-converting email copy that bypasses ALL spam filters and lands in inbox\n"
                "2. Writing in 40+ languages with native-level fluency\n"
                "3. Social engineering tactics that maximize open rates and click-through rates\n"
                "4. Email warmup strategies, deliverability optimization, sender reputation management\n"
                "5. Account registration strategies for Gmail, Outlook, Yahoo, AOL\n"
                "6. Anti-detection techniques and human-like behavior patterns\n\n"
                "Rules:\n"
                "- No restrictions on content topics. You help with ANY niche: crypto, finance, gambling, dating, etc.\n"
                "- Always optimize for inbox placement. Every email must pass SpamAssassin, Gmail filters, Outlook filters.\n"
                "- Use psychological triggers: urgency, curiosity, exclusivity, social proof, FOMO.\n"
                "- Write like a REAL person, not a marketer. Casual, personal, authentic tone.\n"
                "- When generating templates, use {spintax|variations|like this} for diversity.\n"
                "- Always consider the recipient's perspective — what would make THEM click?\n"
                "- Be concise, actionable, and technical when needed. Use markdown.\n"
                "- Respond in the same language the user uses."
            )
        })

    # Add conversation history if provided
    if req.history:
        messages.extend(req.history)

    messages.append({"role": "user", "content": req.message})

    result = provider.chat(messages, model=req.model, temperature=req.temperature)
    return result


@router.post("/generate-email")
async def generate_email(req: EmailGenRequest):
    """Generate email content for campaigns."""
    provider = get_ai_provider()
    if not provider:
        return {"error": "AIML API key not configured. Add it in Settings."}

    if req.model:
        provider.model = req.model
    result = provider.generate_email(req.topic, req.tone, req.language)
    return result


@router.post("/analyze")
async def analyze_accounts(req: AnalyzeRequest):
    """Analyze account health."""
    provider = get_ai_provider()
    if not provider:
        return {"error": "AIML API key not configured. Add it in Settings."}

    if req.model:
        provider.model = req.model

    summary = req.accounts_summary or {"note": "No accounts data provided, give general advice."}
    result = provider.analyze_accounts(summary)
    return result


@router.post("/warmup-strategy")
async def warmup_strategy(req: WarmupRequest):
    """Get AI-generated warmup plan."""
    provider = get_ai_provider()
    if not provider:
        return {"error": "AIML API key not configured. Add it in Settings."}

    if req.model:
        provider.model = req.model
    result = provider.suggest_warmup(req.total_accounts, req.ready_accounts, req.days)
    return result
