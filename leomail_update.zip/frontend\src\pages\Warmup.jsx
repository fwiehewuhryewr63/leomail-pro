import React, { useState, useEffect } from 'react';
import { Flame, Play, Square, Clock, Mail, Link, FileText, TrendingUp } from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';

const API = 'http://localhost:8000/api';

export default function Warmup() {
    const { t } = useI18n();
    const [farms, setFarms] = useState([]);
    const [templates, setTemplates] = useState([]);
    const [links, setLinks] = useState([]);
    const [farmId, setFarmId] = useState('');
    const [duration, setDuration] = useState(21);
    const [templateId, setTemplateId] = useState('');
    const [linkId, setLinkId] = useState('');
    const [emailsPerDay, setEmailsPerDay] = useState(10);
    const [delayMin, setDelayMin] = useState(300);
    const [delayMax, setDelayMax] = useState(1800);
    const [running, setRunning] = useState(false);
    const [stats, setStats] = useState(null);

    useEffect(() => {
        fetch(`${API}/farms/`).then(r => r.json()).then(d => setFarms(Array.isArray(d) ? d : [])).catch(() => { });
        fetch(`${API}/templates/`).then(r => r.json()).then(d => setTemplates(Array.isArray(d) ? d : [])).catch(() => { });
        fetch(`${API}/links/`).then(r => r.json()).then(d => setLinks(Array.isArray(d) ? d : [])).catch(() => { });
    }, []);

    const startWarmup = () => {
        setRunning(true);
        fetch(`${API}/birth/start`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                type: 'warmup',
                farm_id: farmId,
                duration_days: duration,
                template_id: templateId || null,
                link_id: linkId || null,
                emails_per_day: emailsPerDay,
                delay_min_sec: delayMin,
                delay_max_sec: delayMax,
            })
        }).then(r => r.json()).catch(() => { });
    };

    const stopWarmup = () => {
        fetch(`${API}/birth/stop`, { method: 'POST' });
        setRunning(false);
    };

    const phases = [
        { label: t('phase1'), days: '1-3', emails: '1-3', desc: 'Отправка между аккаунтами одного провайдера' },
        { label: t('phase2'), days: '4-14', emails: '5-20', desc: 'Кросс-провайдер отправка, ответы на письма' },
        { label: t('phase3'), days: '15-30', emails: '20-100', desc: 'Полный объём, спинтакс шаблоны, ссылки' },
    ];

    return (
        <div className="page">
            <h2 className="page-title"><Flame size={24} /> {t('warmupTitle')}</h2>

            {/* Phases */}
            <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)', marginBottom: 16 }}>
                {phases.map((ph, i) => (
                    <div key={i} className="card">
                        <div className="card-title">
                            <TrendingUp size={13} style={{ marginRight: 6, color: 'var(--accent)' }} />
                            {ph.label}
                        </div>
                        <div style={{ fontSize: '0.88em', fontWeight: 700, color: 'var(--text-primary)', marginBottom: 4 }}>
                            Days {ph.days} — {ph.emails} {t('emailsPerDay').toLowerCase()}
                        </div>
                        <div style={{ fontSize: '0.78em', color: 'var(--text-muted)' }}>{ph.desc}</div>
                    </div>
                ))}
            </div>

            {/* Settings */}
            <div className="card" style={{ marginBottom: 16 }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                    <div className="form-group">
                        <label className="form-label"><Flame size={12} /> {t('selectFarm')}</label>
                        <select className="form-input" value={farmId} onChange={e => setFarmId(e.target.value)}>
                            <option value="">— {t('selectFarm')} —</option>
                            {farms.map(f => (
                                <option key={f.id} value={f.id}>{f.name} ({f.account_count || 0} акк.)</option>
                            ))}
                        </select>
                    </div>

                    <div className="form-group">
                        <label className="form-label"><Clock size={12} /> {t('warmupDuration')}</label>
                        <div style={{ display: 'flex', gap: 4 }}>
                            {[7, 14, 21, 30].map(d => (
                                <button key={d} className={`btn btn-sm ${duration === d ? 'btn-primary' : ''}`}
                                    onClick={() => setDuration(d)}>{d}</button>
                            ))}
                        </div>
                    </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 12 }}>
                    <div className="form-group">
                        <label className="form-label"><FileText size={12} /> {t('selectTemplate')}</label>
                        <select className="form-input" value={templateId} onChange={e => setTemplateId(e.target.value)}>
                            <option value="">Автогенерация (AI)</option>
                            {templates.map(t => (
                                <option key={t.id} value={t.id}>{t.name}</option>
                            ))}
                        </select>
                    </div>

                    <div className="form-group">
                        <label className="form-label"><Link size={12} /> LINKS</label>
                        <select className="form-input" value={linkId} onChange={e => setLinkId(e.target.value)}>
                            <option value="">Без ссылок</option>
                            {links.map(l => (
                                <option key={l.id} value={l.id}>{l.name} ({l.url})</option>
                            ))}
                        </select>
                    </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginTop: 12 }}>
                    <div className="form-group">
                        <label className="form-label"><Mail size={12} /> {t('emailsPerDay')}</label>
                        <input className="form-input" type="number" value={emailsPerDay}
                            onChange={e => setEmailsPerDay(parseInt(e.target.value))} />
                    </div>

                    <div className="form-group">
                        <label className="form-label">DELAY MIN (SEC)</label>
                        <input className="form-input" type="number" value={delayMin}
                            onChange={e => setDelayMin(parseInt(e.target.value))} />
                    </div>

                    <div className="form-group">
                        <label className="form-label">DELAY MAX (SEC)</label>
                        <input className="form-input" type="number" value={delayMax}
                            onChange={e => setDelayMax(parseInt(e.target.value))} />
                    </div>
                </div>
            </div>

            {/* Start/Stop */}
            <div style={{ display: 'flex', gap: 12 }}>
                {running ? (
                    <button className="btn btn-danger" onClick={stopWarmup} style={{ padding: '14px 32px' }}>
                        <Square size={16} /> {t('stopWork')}
                    </button>
                ) : (
                    <button className="btn btn-primary" onClick={startWarmup} style={{ padding: '14px 32px' }}
                        disabled={!farmId}>
                        <Play size={16} /> {t('startWarmup')}
                    </button>
                )}
            </div>
        </div>
    );
}
