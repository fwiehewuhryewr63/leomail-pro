from fastapi import APIRouter, Depends, UploadFile, File
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import RecipientDatabase
from ..schemas import DatabaseUpload
from loguru import logger
from pathlib import Path
import re

router = APIRouter(prefix="/api/databases", tags=["databases"])

DATABASES_DIR = Path("user_data/databases")


def _validate_email(email: str) -> bool:
    return bool(re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email.strip()))


@router.get("/")
async def list_databases(db: Session = Depends(get_db)):
    dbs = db.query(RecipientDatabase).order_by(RecipientDatabase.created_at.desc()).all()
    return [
        {
            "id": d.id,
            "name": d.name,
            "total_count": d.total_count,
            "used_count": d.used_count,
            "invalid_count": d.invalid_count,
            "remaining": d.total_count - d.used_count,
            "file_path": d.file_path,
            "created_at": d.created_at.isoformat() if d.created_at else None
        }
        for d in dbs
    ]


@router.post("/upload")
async def upload_database(req: DatabaseUpload, db: Session = Depends(get_db)):
    """Upload a list of emails as a recipient database."""
    DATABASES_DIR.mkdir(parents=True, exist_ok=True)

    # Validate and deduplicate
    valid_emails = []
    invalid_count = 0
    seen = set()
    for email in req.emails:
        email = email.strip().lower()
        if email and email not in seen:
            seen.add(email)
            if _validate_email(email):
                valid_emails.append(email)
            else:
                invalid_count += 1

    if not valid_emails:
        return {"error": "No valid emails found"}

    # Save to file
    safe_name = re.sub(r'[^\w\-.]', '_', req.name)
    file_path = DATABASES_DIR / f"{safe_name}.txt"
    with open(file_path, "w") as f:
        f.write("\n".join(valid_emails))

    # Save to DB
    rec_db = RecipientDatabase(
        name=req.name,
        file_path=str(file_path),
        total_count=len(valid_emails),
        invalid_count=invalid_count
    )
    db.add(rec_db)
    db.commit()
    db.refresh(rec_db)

    return {
        "id": rec_db.id,
        "name": rec_db.name,
        "total_count": len(valid_emails),
        "invalid_count": invalid_count,
        "status": "uploaded"
    }


@router.get("/{db_id}")
async def get_database(db_id: int, db: Session = Depends(get_db)):
    rec = db.query(RecipientDatabase).filter(RecipientDatabase.id == db_id).first()
    if not rec:
        return {"error": "Database not found"}

    # Read first 50 emails for preview
    preview = []
    try:
        with open(rec.file_path, "r") as f:
            for i, line in enumerate(f):
                if i >= 50:
                    break
                preview.append(line.strip())
    except Exception:
        pass

    return {
        "id": rec.id,
        "name": rec.name,
        "total_count": rec.total_count,
        "used_count": rec.used_count,
        "remaining": rec.total_count - rec.used_count,
        "preview": preview
    }


@router.delete("/{db_id}")
async def delete_database(db_id: int, db: Session = Depends(get_db)):
    rec = db.query(RecipientDatabase).filter(RecipientDatabase.id == db_id).first()
    if not rec:
        return {"error": "Database not found"}

    # Delete file
    try:
        Path(rec.file_path).unlink(missing_ok=True)
    except Exception:
        pass

    db.delete(rec)
    db.commit()
    return {"status": "deleted"}
