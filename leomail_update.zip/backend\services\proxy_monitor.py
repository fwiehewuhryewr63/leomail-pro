"""Proxy health monitoring service — background task that checks all active proxies."""
import asyncio
import requests
from datetime import datetime
from loguru import logger
from ..database import SessionLocal
from ..models import Proxy, ProxyStatus


CHECK_URL = "https://httpbin.org/ip"
TIMEOUT = 10


async def check_proxy(proxy: Proxy) -> dict:
    """Check a single proxy. Returns updated fields."""
    proxy_str = proxy.to_string()
    proxies_dict = {
        "http": proxy_str,
        "https": proxy_str,
    }

    try:
        start = datetime.utcnow()
        resp = await asyncio.get_event_loop().run_in_executor(
            None,
            lambda: requests.get(CHECK_URL, proxies=proxies_dict, timeout=TIMEOUT)
        )
        elapsed_ms = int((datetime.utcnow() - start).total_seconds() * 1000)

        if resp.status_code == 200:
            return {
                "alive": True,
                "response_time_ms": elapsed_ms,
                "ip": resp.json().get("origin", "unknown")
            }
        else:
            return {"alive": False, "response_time_ms": elapsed_ms, "ip": None}

    except Exception as e:
        logger.debug(f"Proxy check failed {proxy.host}:{proxy.port}: {e}")
        return {"alive": False, "response_time_ms": None, "ip": None}


async def monitor_all_proxies(max_fails: int = 3):
    """Check all active proxies. Mark dead ones."""
    db = SessionLocal()
    try:
        proxies = db.query(Proxy).filter(
            Proxy.status.in_([ProxyStatus.ACTIVE, "active"])
        ).all()

        if not proxies:
            return {"checked": 0, "alive": 0, "dead": 0}

        alive_count = 0
        dead_count = 0

        for proxy in proxies:
            result = await check_proxy(proxy)
            proxy.last_check = datetime.utcnow()

            if result["alive"]:
                proxy.response_time_ms = result["response_time_ms"]
                proxy.fail_count = 0
                alive_count += 1
            else:
                proxy.fail_count = (proxy.fail_count or 0) + 1
                if proxy.fail_count >= max_fails:
                    proxy.status = ProxyStatus.DEAD
                    dead_count += 1
                    logger.warning(f"Proxy DEAD: {proxy.host}:{proxy.port} (failed {max_fails} times)")

        db.commit()
        logger.info(f"Proxy monitor: {len(proxies)} checked, {alive_count} alive, {dead_count} newly dead")
        return {"checked": len(proxies), "alive": alive_count, "dead": dead_count}

    except Exception as e:
        logger.error(f"Proxy monitor error: {e}")
        db.rollback()
        return {"error": str(e)}
    finally:
        db.close()


async def proxy_monitor_loop(interval_sec: int = 60, max_fails: int = 3):
    """Background loop that continuously monitors proxies."""
    logger.info(f"Proxy monitor started (interval: {interval_sec}s, max_fails: {max_fails})")
    while True:
        try:
            await monitor_all_proxies(max_fails=max_fails)
        except Exception as e:
            logger.error(f"Proxy monitor loop error: {e}")
        await asyncio.sleep(interval_sec)
