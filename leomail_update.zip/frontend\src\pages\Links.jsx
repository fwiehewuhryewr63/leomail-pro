import React, { useState, useEffect, useRef } from 'react';
import {
    Link, Plus, Trash2, Upload, FileUp, Globe, CheckSquare, Square,
    Copy, Search, X
} from 'lucide-react';

const API = 'http://localhost:8000/api';

export default function Links() {
    const [links, setLinks] = useState([]);
    const [newUrl, setNewUrl] = useState('');
    const [importResult, setImportResult] = useState(null);
    const [dragOver, setDragOver] = useState(false);
    const [selectedIds, setSelectedIds] = useState(new Set());
    const [searchTerm, setSearchTerm] = useState('');
    const [viewMode, setViewMode] = useState('list'); // 'list' or 'domain'
    const fileRef = useRef();

    const load = () => fetch(`${API}/links/`).then(r => r.json()).then(setLinks).catch(() => { });
    useEffect(() => { load(); }, []);

    const addLink = async () => {
        if (!newUrl.trim()) return;
        await fetch(`${API}/links/`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: newUrl.split('//')[1]?.slice(0, 40) || newUrl, url: newUrl })
        });
        setNewUrl(''); load();
    };

    const deleteLink = async (id) => {
        await fetch(`${API}/links/${id}`, { method: 'DELETE' }); load();
    };

    const bulkDelete = async () => {
        if (!confirm(`Удалить ${selectedIds.size} ссылок?`)) return;
        for (const id of selectedIds) {
            await fetch(`${API}/links/${id}`, { method: 'DELETE' });
        }
        setSelectedIds(new Set()); load();
    };

    const importFile = async (file) => {
        const text = await file.text();
        const resp = await fetch(`${API}/links/import`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text })
        });
        const data = await resp.json();
        setImportResult(data); load();
    };

    const handleDrop = (e) => {
        e.preventDefault(); setDragOver(false);
        const file = e.dataTransfer.files[0];
        if (file) importFile(file);
    };

    const toggleSelect = (id) => {
        setSelectedIds(prev => {
            const next = new Set(prev);
            next.has(id) ? next.delete(id) : next.add(id);
            return next;
        });
    };

    const selectAll = () => {
        if (selectedIds.size === filteredLinks.length) {
            setSelectedIds(new Set());
        } else {
            setSelectedIds(new Set(filteredLinks.map(l => l.id)));
        }
    };

    const copySelected = () => {
        const urls = links.filter(l => selectedIds.has(l.id)).map(l => l.url).join('\n');
        navigator.clipboard.writeText(urls);
    };

    // Group by domain
    const getDomain = (url) => {
        try { return new URL(url).hostname; } catch { return 'unknown'; }
    };

    const domainGroups = links.reduce((acc, link) => {
        const d = getDomain(link.url);
        (acc[d] = acc[d] || []).push(link);
        return acc;
    }, {});

    const filteredLinks = links.filter(l =>
        !searchTerm || l.url.toLowerCase().includes(searchTerm.toLowerCase()) || l.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="page">
            <h2 className="page-title"><Link size={22} /> Ссылки</h2>

            {/* Drag-drop import zone */}
            <div
                onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleDrop}
                onClick={() => fileRef.current?.click()}
                style={{
                    padding: 28, borderRadius: 14, border: `2px dashed ${dragOver ? '#00ff41' : 'rgba(255,255,255,0.08)'}`,
                    background: dragOver ? 'rgba(0,255,65,0.04)' : 'rgba(255,255,255,0.015)',
                    textAlign: 'center', cursor: 'pointer', marginBottom: 14,
                    transition: 'all 0.25s'
                }}
            >
                <FileUp size={28} style={{ color: dragOver ? '#00ff41' : '#006611', marginBottom: 8 }} />
                <div style={{ fontSize: '0.82em', color: dragOver ? '#00ff41' : '#009922', fontWeight: 500 }}>
                    Перетащите .txt файл или нажмите для импорта
                </div>
                <div style={{ fontSize: '0.68em', color: '#006611', marginTop: 4 }}>Один URL на строку</div>
                <input ref={fileRef} type="file" accept=".txt,.csv" hidden onChange={e => e.target.files[0] && importFile(e.target.files[0])} />
            </div>

            {/* Import result */}
            {importResult && (
                <div className="card" style={{ marginBottom: 14 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                        <div className="card-title" style={{ margin: 0 }}>Результат импорта</div>
                        <button className="btn btn-sm" onClick={() => setImportResult(null)}><X size={12} /></button>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
                        <div style={{ textAlign: 'center', padding: 10, borderRadius: 8, background: 'rgba(0,255,65,0.06)' }}>
                            <div style={{ fontSize: '1.4em', fontWeight: 700, color: '#00ff41' }}>{importResult.imported}</div>
                            <div style={{ fontSize: '0.6em', color: '#006611' }}>ИМПОРТ</div>
                        </div>
                        <div style={{ textAlign: 'center', padding: 10, borderRadius: 8, background: 'rgba(245,158,11,0.06)' }}>
                            <div style={{ fontSize: '1.4em', fontWeight: 700, color: '#f59e0b' }}>{importResult.duplicates}</div>
                            <div style={{ fontSize: '0.6em', color: '#006611' }}>ДУБЛИ</div>
                        </div>
                        <div style={{ textAlign: 'center', padding: 10, borderRadius: 8, background: 'rgba(239,68,68,0.06)' }}>
                            <div style={{ fontSize: '1.4em', fontWeight: 700, color: '#ef4444' }}>{importResult.invalid}</div>
                            <div style={{ fontSize: '0.6em', color: '#006611' }}>НЕВАЛИД</div>
                        </div>
                        <div style={{ textAlign: 'center', padding: 10, borderRadius: 8, background: 'rgba(0,255,65,0.06)' }}>
                            <div style={{ fontSize: '1.4em', fontWeight: 700, color: '#00ff41' }}>{importResult.domains_count}</div>
                            <div style={{ fontSize: '0.6em', color: '#006611' }}>ДОМЕНОВ</div>
                        </div>
                    </div>
                </div>
            )}

            {/* Manual add */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
                <input className="form-input" value={newUrl} onChange={e => setNewUrl(e.target.value)}
                    placeholder="https://example.com/offer" onKeyDown={e => e.key === 'Enter' && addLink()}
                    style={{ flex: 1 }} />
                <button className="btn btn-primary" onClick={addLink}><Plus size={14} /> Добавить</button>
            </div>

            {/* Toolbar */}
            <div style={{ display: 'flex', gap: 8, marginBottom: 12, alignItems: 'center' }}>
                <div style={{ position: 'relative', flex: 1 }}>
                    <Search size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#006611' }} />
                    <input className="form-input" value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
                        placeholder="Поиск..." style={{ paddingLeft: 34 }} />
                </div>
                <div style={{ display: 'flex', gap: 4, background: 'rgba(255,255,255,0.02)', borderRadius: 8, padding: 3 }}>
                    <button onClick={() => setViewMode('list')} style={{
                        padding: '5px 12px', borderRadius: 6, border: 'none', cursor: 'pointer',
                        fontSize: '0.72em', fontWeight: 600, fontFamily: 'inherit',
                        background: viewMode === 'list' ? 'rgba(0,255,65,0.1)' : 'transparent',
                        color: viewMode === 'list' ? '#00ff41' : '#006611'
                    }}>Список</button>
                    <button onClick={() => setViewMode('domain')} style={{
                        padding: '5px 12px', borderRadius: 6, border: 'none', cursor: 'pointer',
                        fontSize: '0.72em', fontWeight: 600, fontFamily: 'inherit',
                        background: viewMode === 'domain' ? 'rgba(0,255,65,0.1)' : 'transparent',
                        color: viewMode === 'domain' ? '#00ff41' : '#006611'
                    }}><Globe size={12} /> Домены</button>
                </div>
                {selectedIds.size > 0 && (
                    <div style={{ display: 'flex', gap: 4 }}>
                        <button className="btn btn-sm" onClick={copySelected}><Copy size={12} /> Копировать ({selectedIds.size})</button>
                        <button className="btn btn-sm btn-danger" onClick={bulkDelete}><Trash2 size={12} /> Удалить</button>
                    </div>
                )}
            </div>

            {/* Links display */}
            {links.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', padding: 48, color: '#006611' }}>
                    <Link size={36} style={{ opacity: 0.3, marginBottom: 12 }} /><br />
                    Нет ссылок. Добавьте вручную или импортируйте файлом.
                </div>
            ) : viewMode === 'list' ? (
                <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                    <div style={{
                        padding: '8px 14px', display: 'flex', alignItems: 'center', gap: 8,
                        borderBottom: '1px solid rgba(255,255,255,0.04)', fontSize: '0.72em', color: '#006611'
                    }}>
                        <span onClick={selectAll} style={{ cursor: 'pointer', color: selectedIds.size === filteredLinks.length ? '#00ff41' : '#006611' }}>
                            {selectedIds.size === filteredLinks.length ? <CheckSquare size={14} /> : <Square size={14} />}
                        </span>
                        {links.length} ссылок · {Object.keys(domainGroups).length} доменов
                    </div>
                    {filteredLinks.map(l => (
                        <div key={l.id} style={{
                            display: 'flex', alignItems: 'center', gap: 10, padding: '8px 14px',
                            borderBottom: '1px solid rgba(255,255,255,0.02)', fontSize: '0.8em',
                            background: selectedIds.has(l.id) ? 'rgba(0,255,65,0.03)' : 'transparent',
                            transition: 'background 0.15s'
                        }}>
                            <span onClick={() => toggleSelect(l.id)} style={{ cursor: 'pointer', color: selectedIds.has(l.id) ? '#00ff41' : '#006611', flexShrink: 0 }}>
                                {selectedIds.has(l.id) ? <CheckSquare size={14} /> : <Square size={14} />}
                            </span>
                            <span style={{ flex: 1, color: '#009922', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{l.url}</span>
                            <span className="neon-tag neon-tag-cyan" style={{ flexShrink: 0 }}>{getDomain(l.url)}</span>
                            <button className="btn btn-sm btn-danger" onClick={() => deleteLink(l.id)} style={{ padding: '4px 8px' }}>
                                <Trash2 size={11} />
                            </button>
                        </div>
                    ))}
                </div>
            ) : (
                <div style={{ display: 'grid', gap: 10 }}>
                    {Object.entries(domainGroups).sort((a, b) => b[1].length - a[1].length).map(([domain, domLinks]) => (
                        <div key={domain} className="card">
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                    <Globe size={14} style={{ color: '#00ff41' }} />
                                    <span style={{ fontWeight: 600, fontSize: '0.88em' }}>{domain}</span>
                                    <span className="neon-tag neon-tag-cyan">{domLinks.length}</span>
                                </div>
                            </div>
                            {domLinks.map(l => (
                                <div key={l.id} style={{
                                    fontSize: '0.75em', color: '#009922', padding: '4px 0',
                                    borderTop: '1px solid rgba(255,255,255,0.02)',
                                    display: 'flex', justifyContent: 'space-between', alignItems: 'center'
                                }}>
                                    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>{l.url}</span>
                                    <button className="btn btn-sm btn-danger" onClick={() => deleteLink(l.id)} style={{ padding: '3px 6px', marginLeft: 8 }}>
                                        <Trash2 size={10} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}
