import React, { useRef, useEffect } from 'react';

export default function MatrixRain() {
    const canvasRef = useRef(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext('2d');

        const resize = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };
        resize();
        window.addEventListener('resize', resize);

        const chars = 'アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲン0123456789ABCDEF@#$%^&*()LEOMAIL';
        const fontSize = 14;
        const columns = Math.floor(canvas.width / fontSize);
        const drops = new Array(columns).fill(0).map(() => Math.random() * -100);
        const speeds = new Array(columns).fill(0).map(() => 0.3 + Math.random() * 0.7);

        const draw = () => {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            for (let i = 0; i < drops.length; i++) {
                const char = chars[Math.floor(Math.random() * chars.length)];
                const y = drops[i] * fontSize;

                // Head of the trail — brightest
                ctx.fillStyle = '#00ff41';
                ctx.font = `${fontSize}px 'Share Tech Mono', monospace`;
                ctx.shadowColor = '#00ff41';
                ctx.shadowBlur = 8;
                ctx.fillText(char, i * fontSize, y);

                // Previous character — dimmer
                ctx.shadowBlur = 0;
                ctx.fillStyle = 'rgba(0, 204, 51, 0.6)';
                ctx.fillText(chars[Math.floor(Math.random() * chars.length)], i * fontSize, y - fontSize);

                // Even older — very dim
                ctx.fillStyle = 'rgba(0, 102, 17, 0.3)';
                ctx.fillText(chars[Math.floor(Math.random() * chars.length)], i * fontSize, y - fontSize * 2);

                drops[i] += speeds[i];

                if (y > canvas.height && Math.random() > 0.975) {
                    drops[i] = 0;
                    speeds[i] = 0.3 + Math.random() * 0.7;
                }
            }
        };

        const interval = setInterval(draw, 45);

        return () => {
            clearInterval(interval);
            window.removeEventListener('resize', resize);
        };
    }, []);

    return (
        <canvas
            ref={canvasRef}
            id="matrix-rain"
            style={{
                position: 'fixed',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                zIndex: 0,
                pointerEvents: 'none',
                opacity: 0.15,
            }}
        />
    );
}
