@echo off
chcp 65001 >nul 2>nul
title LEOMAIL v2.2
color 0a
cd /d "%~dp0"

echo.
echo  ========================================
echo     LEOMAIL v2.2 — EMAIL GOD ENGINE
echo  ========================================
echo.

where python >nul 2>&1
if %errorLevel% neq 0 (
    echo  [ERROR] Python not found!
    echo  Run INSTALL.bat first.
    echo.
    set /p dummy=Press ENTER to close...
    exit /b 1
)

echo  Server: http://localhost:8000
echo  Press Ctrl+C to stop
echo.

python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000

echo.
echo  Server stopped.
set /p dummy=Press ENTER to close...
