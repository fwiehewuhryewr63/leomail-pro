import React, { useState, useEffect } from 'react';
import { Baby, Play, Square, Settings, Smartphone, Monitor, Globe2, Languages, Shield } from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';

const API = 'http://localhost:8000/api';

const PROVIDERS = [
    {
        id: 'outlook',
        name: 'Outlook',
        color: '#0078D4',
        device: 'desktop',
        deviceLabel: 'Desktop (Windows)',
        proxyType: 'residential',
        proxyLabel: 'Residential / ISP',
        sms: 'simsms',
    },
    {
        id: 'gmail',
        name: 'Gmail',
        color: '#EA4335',
        device: 'mobile',
        deviceLabel: 'Mobile (Android)',
        proxyType: 'mobile',
        proxyLabel: 'Mobile proxy ONLY',
        sms: 'grizzly',
    },
    {
        id: 'yahoo',
        name: 'Yahoo',
        color: '#6001D2',
        device: 'desktop',
        deviceLabel: 'Desktop (Windows)',
        proxyType: 'residential',
        proxyLabel: 'Residential / ISP',
        sms: 'grizzly',
    },
    {
        id: 'hotmail',
        name: 'Hotmail',
        color: '#0078D4',
        device: 'desktop',
        deviceLabel: 'Desktop (Windows)',
        proxyType: 'residential',
        proxyLabel: 'Residential / ISP',
        sms: 'simsms',
    },
    {
        id: 'aol',
        name: 'AOL',
        color: '#FF7900',
        device: 'desktop',
        deviceLabel: 'Desktop (Windows)',
        proxyType: 'residential',
        proxyLabel: 'Residential / ISP',
        sms: 'grizzly',
    },
];

const LANGUAGES = [
    { id: 'en', flag: '🇺🇸', label: 'English' },
    { id: 'ru', flag: '🇷🇺', label: 'Русский' },
    { id: 'de', flag: '🇩🇪', label: 'Deutsch' },
    { id: 'fr', flag: '🇫🇷', label: 'Français' },
    { id: 'es', flag: '🇪🇸', label: 'Español' },
    { id: 'pt', flag: '🇧🇷', label: 'Português' },
];

const GEOS = [
    { id: 'US', flag: '🇺🇸' }, { id: 'GB', flag: '🇬🇧' }, { id: 'DE', flag: '🇩🇪' },
    { id: 'FR', flag: '🇫🇷' }, { id: 'BR', flag: '🇧🇷' }, { id: 'RU', flag: '🇷🇺' },
    { id: 'ES', flag: '🇪🇸' }, { id: 'IN', flag: '🇮🇳' },
];

export default function Birth() {
    const { t } = useI18n();
    const [provider, setProvider] = useState('outlook');
    const [smsProvider, setSmsProvider] = useState('simsms');
    const [batchSize, setBatchSize] = useState(5);
    const [language, setLanguage] = useState('en');
    const [geo, setGeo] = useState('US');
    const [maxSmsPrice, setMaxSmsPrice] = useState(0.5);
    const [running, setRunning] = useState(false);
    const [progress, setProgress] = useState({ created: 0, failed: 0, total: 0, pct: 0 });
    const [autoFarm, setAutoFarm] = useState(true);
    const [farms, setFarms] = useState([]);
    const [farmId, setFarmId] = useState(null);

    useEffect(() => {
        fetch(`${API}/farms/`).then(r => r.json()).then(d => setFarms(Array.isArray(d) ? d : [])).catch(() => { });
    }, []);

    // When provider changes, update SMS provider
    useEffect(() => {
        const p = PROVIDERS.find(pr => pr.id === provider);
        if (p) setSmsProvider(p.sms);
    }, [provider]);

    const selectedProvider = PROVIDERS.find(p => p.id === provider);

    const startBirth = () => {
        setRunning(true);
        setProgress({ created: 0, failed: 0, total: batchSize, pct: 0 });
        fetch(`${API}/birth/start`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                provider: provider,
                batch_size: batchSize,
                sms_provider: smsProvider,
                max_sms_price: maxSmsPrice,
                language: language,
                geo: geo,
                auto_farm: autoFarm,
                farm_id: farmId,
            })
        }).then(r => r.json()).catch(() => { });
    };

    const stopBirth = () => {
        fetch(`${API}/birth/stop`, { method: 'POST' });
        setRunning(false);
    };

    // Poll status while running
    useEffect(() => {
        if (!running) return;
        const iv = setInterval(() => {
            fetch(`${API}/birth/status`)
                .then(r => r.json())
                .then(d => {
                    if (d.status === 'idle') { setRunning(false); clearInterval(iv); }
                    setProgress({
                        created: d.created || 0,
                        failed: d.failed || 0,
                        total: d.total || batchSize,
                        pct: d.total > 0 ? Math.round(((d.created + d.failed) / d.total) * 100) : 0,
                    });
                });
        }, 2000);
        return () => clearInterval(iv);
    }, [running]);

    return (
        <div className="page">
            <h2 className="page-title"><Baby size={24} /> {t('birthTitle')}</h2>

            {/* Provider selection */}
            <div className="card" style={{ marginBottom: 16 }}>
                <div className="card-title">{t('emailProvider')}</div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 8 }}>
                    {PROVIDERS.map(p => (
                        <button key={p.id} className={`btn ${provider === p.id ? 'btn-primary' : ''}`}
                            onClick={() => setProvider(p.id)}
                            style={{
                                borderColor: provider === p.id ? p.color : 'var(--border-default)',
                                flexDirection: 'column', height: 70, gap: 4,
                                background: provider === p.id ? `${p.color}22` : undefined,
                            }}>
                            <span style={{ fontWeight: 800, fontSize: '0.9em', color: provider === p.id ? p.color : undefined }}>{p.name}</span>
                            <span style={{ fontSize: '0.65em', color: 'var(--text-muted)' }}>
                                {p.device === 'mobile' ? '📱' : '💻'} {p.deviceLabel.split(' ')[0]}
                            </span>
                        </button>
                    ))}
                </div>
            </div>

            {/* Device & Proxy info */}
            {selectedProvider && (
                <div className="card" style={{ marginBottom: 16, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
                    <div>
                        <div className="card-title">
                            {selectedProvider.device === 'mobile' ? <Smartphone size={13} style={{ marginRight: 6 }} /> : <Monitor size={13} style={{ marginRight: 6 }} />}
                            BROWSER EMULATION
                        </div>
                        <div style={{ fontSize: '0.9em', fontWeight: 600, color: 'var(--text-primary)' }}>
                            {selectedProvider.deviceLabel}
                        </div>
                        <div style={{ fontSize: '0.78em', color: 'var(--text-muted)', marginTop: 4 }}>
                            Playwright {selectedProvider.device === 'mobile' ? 'Android Chrome' : 'Desktop Chrome'} с уникальным fingerprint
                        </div>
                    </div>
                    <div>
                        <div className="card-title"><Shield size={13} style={{ marginRight: 6 }} /> PROXY TYPE</div>
                        <div style={{ fontSize: '0.9em', fontWeight: 600, color: selectedProvider.proxyType === 'mobile' ? 'var(--warning)' : 'var(--success)' }}>
                            {selectedProvider.proxyLabel}
                        </div>
                        <div style={{ fontSize: '0.78em', color: 'var(--text-muted)', marginTop: 4 }}>
                            {selectedProvider.proxyType === 'mobile'
                                ? 'Gmail принимает ТОЛЬКО mobile proxy!'
                                : 'Residential/ISP proxy рекомендуется'}
                        </div>
                    </div>
                </div>
            )}

            {/* Settings */}
            <div className="card" style={{ marginBottom: 16 }}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
                    <div className="form-group">
                        <label className="form-label"><Languages size={12} /> LANGUAGE</label>
                        <select className="form-input" value={language} onChange={e => setLanguage(e.target.value)}>
                            {LANGUAGES.map(l => <option key={l.id} value={l.id}>{l.flag} {l.label}</option>)}
                        </select>
                    </div>

                    <div className="form-group">
                        <label className="form-label"><Globe2 size={12} /> GEO</label>
                        <select className="form-input" value={geo} onChange={e => setGeo(e.target.value)}>
                            {GEOS.map(g => <option key={g.id} value={g.id}>{g.flag} {g.id}</option>)}
                        </select>
                    </div>

                    <div className="form-group">
                        <label className="form-label">{t('batchSize')}</label>
                        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                            {[5, 10, 25, 50].map(n => (
                                <button key={n} className={`btn btn-sm ${batchSize === n ? 'btn-primary' : ''}`}
                                    onClick={() => setBatchSize(n)}>{n}</button>
                            ))}
                        </div>
                    </div>

                    <div className="form-group">
                        <label className="form-label">{t('maxSmsPrice')}</label>
                        <input className="form-input" type="number" step="0.1" value={maxSmsPrice}
                            onChange={e => setMaxSmsPrice(parseFloat(e.target.value))} />
                    </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 12 }}>
                    <div className="form-group">
                        <label className="form-label">{t('smsProvider')}</label>
                        <select className="form-input" value={smsProvider} onChange={e => setSmsProvider(e.target.value)}>
                            <option value="grizzly">Grizzly SMS</option>
                            <option value="simsms">SimSMS</option>
                        </select>
                    </div>

                    <div className="form-group">
                        <label className="form-label">AUTO-ASSIGN TO FARM</label>
                        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                            <div className={`toggle-track ${autoFarm ? 'active' : ''}`} onClick={() => setAutoFarm(!autoFarm)}>
                                <div className="toggle-knob" />
                            </div>
                            {autoFarm && farms.length > 0 && (
                                <select className="form-input" style={{ width: 200 }} value={farmId || ''} onChange={e => setFarmId(e.target.value)}>
                                    <option value="">Auto-create new</option>
                                    {farms.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                                </select>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            {/* Progress */}
            {running && (
                <div className="card" style={{ marginBottom: 16 }}>
                    <div className="card-title">{t('birthProgress')}</div>
                    <div className="progress-bar" style={{ marginBottom: 12 }}>
                        <div className="progress-fill" style={{ width: `${progress.pct}%` }} />
                    </div>
                    <div style={{ display: 'flex', gap: 20, fontSize: '0.85em' }}>
                        <span style={{ color: 'var(--success)', fontWeight: 700 }}>{t('accountsCreated')}: {progress.created}</span>
                        <span style={{ color: 'var(--danger)', fontWeight: 700 }}>{t('accountsFailed')}: {progress.failed}</span>
                        <span style={{ color: 'var(--text-muted)' }}>{progress.pct}% ({progress.created + progress.failed}/{progress.total})</span>
                    </div>
                </div>
            )}

            {/* Start/Stop */}
            <div style={{ display: 'flex', gap: 12 }}>
                {running ? (
                    <button className="btn btn-danger" onClick={stopBirth} style={{ padding: '14px 32px' }}>
                        <Square size={16} /> {t('stopBirth')}
                    </button>
                ) : (
                    <button className="btn btn-primary" onClick={startBirth} style={{ padding: '14px 32px' }}>
                        <Play size={16} /> {t('startBirth')}
                    </button>
                )}
            </div>
        </div>
    );
}
