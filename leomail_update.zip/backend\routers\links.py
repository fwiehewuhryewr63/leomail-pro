from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Link
from ..schemas import LinkCreate, LinkUpdate
from loguru import logger

router = APIRouter(prefix="/api/links", tags=["links"])


@router.get("/")
async def list_links(db: Session = Depends(get_db)):
    links = db.query(Link).order_by(Link.created_at.desc()).all()
    return [
        {
            "id": l.id,
            "name": l.name,
            "url": l.url,
            "click_count": l.click_count,
            "active": l.active,
            "created_at": l.created_at.isoformat() if l.created_at else None
        }
        for l in links
    ]


@router.post("/")
async def create_link(req: LinkCreate, db: Session = Depends(get_db)):
    link = Link(name=req.name, url=req.url)
    db.add(link)
    db.commit()
    db.refresh(link)
    return {"id": link.id, "status": "created"}


@router.put("/{link_id}")
async def update_link(link_id: int, req: LinkUpdate, db: Session = Depends(get_db)):
    link = db.query(Link).filter(Link.id == link_id).first()
    if not link:
        return {"error": "Link not found"}
    if req.name is not None:
        link.name = req.name
    if req.url is not None:
        link.url = req.url
    if req.active is not None:
        link.active = req.active
    db.commit()
    return {"status": "updated"}


@router.delete("/{link_id}")
async def delete_link(link_id: int, db: Session = Depends(get_db)):
    link = db.query(Link).filter(Link.id == link_id).first()
    if not link:
        return {"error": "Link not found"}
    db.delete(link)
    db.commit()
    return {"status": "deleted"}


class LinksImport(BaseModel):
    text: str  # one URL per line


@router.post("/import")
async def import_links(req: LinksImport, db: Session = Depends(get_db)):
    """Import links from text (one per line). Validates, deduplicates, analyzes domains."""
    import re
    lines = [l.strip() for l in req.text.strip().split("\n") if l.strip()]
    url_pattern = re.compile(r'^https?://.+')

    existing_urls = set(l.url.lower() for l in db.query(Link.url).all())

    imported = 0
    duplicates = 0
    invalid = 0
    domains = set()

    for line in lines:
        if not url_pattern.match(line):
            invalid += 1
            continue
        if line.lower() in existing_urls:
            duplicates += 1
            continue

        # Extract domain for analytics
        try:
            from urllib.parse import urlparse
            domain = urlparse(line).netloc
            domains.add(domain)
        except:
            pass

        # Auto-name from domain+path
        name = line.split("//")[-1][:50]
        link = Link(name=name, url=line)
        db.add(link)
        existing_urls.add(line.lower())
        imported += 1

    db.commit()
    return {
        "total_lines": len(lines),
        "imported": imported,
        "duplicates": duplicates,
        "invalid": invalid,
        "domains": list(domains),
        "domains_count": len(domains),
    }
