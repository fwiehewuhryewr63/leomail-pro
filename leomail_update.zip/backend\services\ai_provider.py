"""
AIML API Provider — OpenAI-compatible client for AI/ML API.
Base URL: https://api.aimlapi.com/v1
Supports model selection: gpt-4o, claude-3.5-sonnet, llama-3, mistral, etc.
"""
import requests
from loguru import logger
from ..config import load_config


AIML_BASE_URL = "https://api.aimlapi.com/v1"

# Popular models available on AIML API
AVAILABLE_MODELS = [
    {"id": "gpt-4o", "name": "GPT-4o", "provider": "OpenAI"},
    {"id": "gpt-4o-mini", "name": "GPT-4o Mini", "provider": "OpenAI"},
    {"id": "o3-mini", "name": "o3-mini", "provider": "OpenAI"},
    {"id": "claude-3-5-sonnet-20241022", "name": "Claude 3.5 Sonnet", "provider": "Anthropic"},
    {"id": "claude-3-5-haiku-20241022", "name": "Claude 3.5 Haiku", "provider": "Anthropic"},
    {"id": "mistralai/Mistral-Small-24B-Instruct-2501", "name": "Mistral Small 25", "provider": "Mistral"},
    {"id": "meta-llama/Llama-3.3-70B-Instruct-Turbo", "name": "Llama 3.3 70B", "provider": "Meta"},
    {"id": "deepseek/deepseek-chat", "name": "DeepSeek V3", "provider": "DeepSeek"},
    {"id": "google/gemini-2.0-flash", "name": "Gemini 2.0 Flash", "provider": "Google"},
]


class AIProvider:
    def __init__(self, api_key: str, model: str = "gpt-4o"):
        self.api_key = api_key
        self.model = model
        self.base_url = AIML_BASE_URL

    def chat(self, messages: list, model: str = None, temperature: float = 0.7, max_tokens: int = 2048) -> dict:
        """Send chat completion request to AIML API."""
        if not self.api_key:
            return {"error": "AIML API key not configured. Go to Settings to add it."}

        use_model = model or self.model
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": use_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens
        }

        try:
            resp = requests.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=60
            )
            if resp.status_code != 200:
                logger.error(f"AIML API Error {resp.status_code}: {resp.text[:200]}")
                return {"error": f"API returned {resp.status_code}: {resp.text[:200]}"}

            data = resp.json()
            content = data.get("choices", [{}])[0].get("message", {}).get("content", "")
            usage = data.get("usage", {})
            return {
                "content": content,
                "model": use_model,
                "tokens_used": usage.get("total_tokens", 0)
            }
        except requests.Timeout:
            return {"error": "Request timed out. Try a faster model."}
        except Exception as e:
            logger.error(f"AIML chat error: {e}")
            return {"error": str(e)}

    def generate_email(self, topic: str, tone: str = "professional", language: str = "en") -> dict:
        """Generate email content for mailing campaigns."""
        system = (
            "You are an expert email copywriter. Generate a complete email with subject line and body. "
            "Output format:\nSUBJECT: <subject>\n\n<body>\n\n"
            f"Tone: {tone}. Language: {language}."
        )
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": f"Write an email about: {topic}"}
        ]
        return self.chat(messages)

    def analyze_accounts(self, accounts_summary: dict) -> dict:
        """Analyze account health and suggest actions."""
        system = (
            "You are an email deliverability expert. Analyze the accounts summary and provide "
            "actionable recommendations for improving account health, warmup strategy, and sending reputation."
        )
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": f"Analyze these email accounts:\n{accounts_summary}"}
        ]
        return self.chat(messages)

    def suggest_warmup(self, total_accounts: int, ready_accounts: int, days_available: int = 14) -> dict:
        """Get AI-powered warmup strategy."""
        system = (
            "You are an email warmup strategist. Create a detailed day-by-day warmup plan. "
            "Include: daily email volume, sending intervals, content variety tips, and risk factors."
        )
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": (
                f"Create a warmup plan for {total_accounts} total accounts "
                f"({ready_accounts} ready), over {days_available} days."
            )}
        ]
        return self.chat(messages)


def get_ai_provider() -> AIProvider | None:
    """Factory: create AIProvider from config."""
    config = load_config()
    ai_cfg = config.get("ai", {}).get("aiml", {})
    key = ai_cfg.get("api_key", "")
    model = ai_cfg.get("model", "gpt-4o")
    if not key:
        return None
    return AIProvider(api_key=key, model=model)
