import random
import string
from datetime import datetime, timedelta

FIRST_NAMES = ["James", "Mary", "Robert", "Patricia", "John", "Jennifer", "Michael", "Linda", "David", "Elizabeth"]
LAST_NAMES = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"]

def generate_random_name():
    return random.choice(FIRST_NAMES), random.choice(LAST_NAMES)

def generate_random_birthday(min_age=19, max_age=45):
    end_date = datetime.now() - timedelta(days=min_age*365)
    start_date = datetime.now() - timedelta(days=max_age*365)
    
    random_days = random.randint(0, (end_date - start_date).days)
    birthday = start_date + timedelta(days=random_days)
    return birthday

def generate_random_password(length=12):
    chars = string.ascii_letters + string.digits + "!@#$%"
    return "".join(random.choice(chars) for _ in range(length))
