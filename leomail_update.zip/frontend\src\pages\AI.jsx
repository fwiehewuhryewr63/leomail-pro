import React, { useState, useEffect, useRef } from 'react';
import { Brain, Send, Loader, Sparkles, Trash2 } from 'lucide-react';

const API = 'http://localhost:8000/api';

export default function AI() {
    const [models, setModels] = useState([]);
    const [model, setModel] = useState('');
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const messagesEnd = useRef(null);

    useEffect(() => {
        fetch(`${API}/ai/models`).then(r => r.json()).then(d => { setModels(d.models || []); if (d.current) setModel(d.current); }).catch(() => { });
    }, []);

    useEffect(() => { messagesEnd.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

    const sendMessage = async () => {
        if (!input.trim() || loading) return;
        const userMsg = { role: 'user', content: input };
        setMessages(p => [...p, userMsg]);
        setInput('');
        setLoading(true);
        try {
            const resp = await fetch(`${API}/ai/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: input, model, context: messages.slice(-10) }) });
            const data = await resp.json();
            setMessages(p => [...p, { role: 'assistant', content: data.response || data.error || 'Нет ответа' }]);
        } catch (e) {
            setMessages(p => [...p, { role: 'assistant', content: `Ошибка: ${e.message}` }]);
        } finally { setLoading(false); }
    };

    const quickActions = [
        { label: '📧 Генерация email', prompt: 'Сгенерируй профессиональное продающее email-письмо для крипто-инвестиционной платформы. Включи тему и тело.' },
        { label: '🔍 Анализ аккаунтов', prompt: 'Проанализируй мою текущую стратегию рассылки и дай рекомендации по улучшению deliverability.' },
        { label: '🔥 Стратегия прогрева', prompt: 'Предложи оптимальную стратегию прогрева для 50 новых Outlook аккаунтов. Учти cross-provider warmup.' },
        { label: '📊 Оптимизация', prompt: 'Какие настройки рассылки (задержки, лимиты, время отправки) оптимальны для 100 аккаунтов и 50K базы?' },
    ];

    return (
        <div className="page" style={{ display: 'flex', flexDirection: 'column', height: 'calc(100vh - 56px)' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
                <h2 className="page-title" style={{ margin: 0 }}><Brain size={22} /> AI Ассистент</h2>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    {models.length > 0 && (
                        <select className="form-input" value={model} onChange={e => setModel(e.target.value)} style={{ width: 220, padding: '6px 10px', fontSize: '0.75em' }}>
                            {models.map(m => <option key={m} value={m}>{m}</option>)}
                        </select>
                    )}
                    {messages.length > 0 && (
                        <button className="btn btn-sm" onClick={() => setMessages([])}><Trash2 size={13} /></button>
                    )}
                </div>
            </div>

            {/* Quick actions */}
            {messages.length === 0 && (
                <div style={{ marginBottom: 16 }}>
                    <div style={{ fontSize: '0.72em', color: '#475569', fontWeight: 500, marginBottom: 8 }}>Быстрые действия</div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                        {quickActions.map((qa, i) => (
                            <div key={i} className="card" onClick={() => { setInput(qa.prompt); }} style={{ cursor: 'pointer', padding: 14 }}>
                                <div style={{ fontSize: '0.82em', fontWeight: 500 }}>{qa.label}</div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Messages */}
            <div style={{ flex: 1, overflow: 'auto', marginBottom: 12, paddingRight: 4 }}>
                {messages.map((msg, i) => (
                    <div key={i} style={{
                        display: 'flex', justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start',
                        marginBottom: 10
                    }}>
                        <div style={{
                            maxWidth: '80%', padding: '12px 16px', borderRadius: 14,
                            background: msg.role === 'user' ? 'linear-gradient(135deg, #00cc33, #009922)' : 'rgba(255,255,255,0.04)',
                            border: msg.role === 'user' ? 'none' : '1px solid rgba(255,255,255,0.06)',
                            color: msg.role === 'user' ? 'white' : '#e2e8f0',
                            fontSize: '0.85em', lineHeight: 1.6, whiteSpace: 'pre-wrap'
                        }}>
                            {msg.content}
                        </div>
                    </div>
                ))}
                {loading && (
                    <div style={{ display: 'flex', justifyContent: 'flex-start', marginBottom: 10 }}>
                        <div style={{ padding: '12px 16px', borderRadius: 14, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', gap: 8 }}>
                            <Sparkles size={14} className="spin" style={{ color: '#00cc33' }} /> <span style={{ fontSize: '0.82em', color: '#475569' }}>Думаю...</span>
                        </div>
                    </div>
                )}
                <div ref={messagesEnd} />
            </div>

            {/* Input */}
            <div style={{ display: 'flex', gap: 8 }}>
                <input className="form-input" value={input} onChange={e => setInput(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && !e.shiftKey && sendMessage()}
                    placeholder="Спроси у AI про email-маркетинг, прогрев, шаблоны..."
                    style={{ flex: 1, borderRadius: 12 }} />
                <button className="btn btn-primary" onClick={sendMessage} disabled={loading || !input.trim()} style={{ padding: '10px 20px', borderRadius: 12 }}>
                    {loading ? <Loader size={16} className="spin" /> : <Send size={16} />}
                </button>
            </div>
        </div>
    );
}
