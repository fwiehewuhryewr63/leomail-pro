@echo off
chcp 65001 >nul
title LEOMAIL v2.3 UPDATE

echo ════════════════════════════════════════════
echo          LEOMAIL v2.3 — UPDATE
echo ════════════════════════════════════════════
echo.
echo Это скрипт обновления. Он:
echo   1. Обновит бэкенд и фронтенд
echo   2. Пересоберёт интерфейс
echo   3. СОХРАНИТ все ваши данные (аккаунты, фермы, прокси, ключи)
echo.

set "SCRIPT_DIR=%~dp0"
set "INSTALL_DIR=%USERPROFILE%\Desktop\Leomail"

:: Check if Leomail is already installed
if not exist "%INSTALL_DIR%" (
    echo [ERROR] Leomail не найден в %INSTALL_DIR%
    echo Сначала запустите INSTALL.bat
    pause
    exit /b 1
)

:: Check if update folder has the needed files
if not exist "%SCRIPT_DIR%backend" (
    echo [ERROR] Папка backend не найдена в %SCRIPT_DIR%
    echo Убедитесь что этот файл лежит в корне обновления Leomail
    pause
    exit /b 1
)

echo [1/5] Останавливаю Leomail...
taskkill /f /fi "WINDOWTITLE eq LEOMAIL*" >nul 2>&1
timeout /t 2 >nul

echo [2/5] Создаю бэкап базы данных...
if exist "%INSTALL_DIR%\user_data" (
    if not exist "%INSTALL_DIR%\backups" mkdir "%INSTALL_DIR%\backups"
    set "BACKUP_NAME=backup_%date:~-4,4%%date:~-7,2%%date:~-10,2%_%time:~0,2%%time:~3,2%"
    set "BACKUP_NAME=%BACKUP_NAME: =0%"
    xcopy "%INSTALL_DIR%\user_data\*" "%INSTALL_DIR%\backups\%BACKUP_NAME%\" /E /I /Q >nul 2>&1
    echo    Бэкап сохранён в backups\
) else (
    echo    Папка user_data не найдена, пропускаю бэкап
)

echo [3/5] Обновляю бэкенд...
:: Remove old backend (keep user_data!)
if exist "%INSTALL_DIR%\backend" rmdir /s /q "%INSTALL_DIR%\backend"
xcopy "%SCRIPT_DIR%backend" "%INSTALL_DIR%\backend\" /E /I /Q >nul

echo [4/5] Обновляю фронтенд...
:: Remove old src, keep node_modules and dist temporarily
if exist "%INSTALL_DIR%\frontend\src" rmdir /s /q "%INSTALL_DIR%\frontend\src"
xcopy "%SCRIPT_DIR%frontend\src" "%INSTALL_DIR%\frontend\src\" /E /I /Q >nul

:: Copy config files
copy /y "%SCRIPT_DIR%frontend\package.json" "%INSTALL_DIR%\frontend\package.json" >nul 2>&1
copy /y "%SCRIPT_DIR%frontend\vite.config.js" "%INSTALL_DIR%\frontend\vite.config.js" >nul 2>&1
copy /y "%SCRIPT_DIR%frontend\index.html" "%INSTALL_DIR%\frontend\index.html" >nul 2>&1

:: Install any new dependencies
echo    Проверяю зависимости...
cd /d "%INSTALL_DIR%\frontend"
call npm install --silent >nul 2>&1

echo [5/5] Пересобираю интерфейс...
call npm run build >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Сборка завершилась с ошибкой. Попробуйте вручную:
    echo    cd %INSTALL_DIR%\frontend
    echo    npm run build
) else (
    echo    Интерфейс собран успешно!
)

:: Copy updated START.bat if exists
if exist "%SCRIPT_DIR%START.bat" copy /y "%SCRIPT_DIR%START.bat" "%INSTALL_DIR%\START.bat" >nul

echo.
echo ════════════════════════════════════════════
echo          ОБНОВЛЕНИЕ ЗАВЕРШЕНО!
echo ════════════════════════════════════════════
echo.
echo  Данные сохранены: аккаунты, фермы, прокси, ключи
echo  Бэкап создан в: backups\
echo.
echo  Запустите START.bat чтобы запустить Leomail
echo.
pause
