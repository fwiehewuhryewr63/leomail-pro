from fastapi import APIRouter, Depends, BackgroundTasks
from sqlalchemy.orm import Session
from ..database import get_db
from ..schemas import RegistrationRequest
from ..modules.birth.outlook import OutlookRegistration
from ..modules.browser_manager import BrowserManager
from ..services.captcha_provider import CaptchaProvider
from ..services.sms_provider import GrizzlySMS
from ..models import Proxy, ProxyStatus, Task, TaskStatus
from ..config import get_api_key
from loguru import logger

router = APIRouter(prefix="/api/birth", tags=["birth"])

# Dependency to get configured providers
def get_captcha_service():
    return CaptchaProvider(api_key=get_api_key("capguru") or "")

def get_sms_service():
    key = get_api_key("grizzly") or ""
    return GrizzlySMS(key) if key else None

async def run_registration_task(request: RegistrationRequest, db: Session, captcha_service: CaptchaProvider, sms_service: GrizzlySMS):
    # Track as task
    task = Task(type="registration", details=f"Registering {request.quantity} accounts", status=TaskStatus.RUNNING)
    db.add(task)
    db.commit()
    
    browser_manager = BrowserManager(headless=False)
    await browser_manager.start()
    
    try:
        if request.provider == "outlook":
            reg_service = OutlookRegistration(browser_manager, captcha_service, db)
            
            # Get Proxy
            proxy = None
            if request.proxy_id:
                proxy = db.query(Proxy).get(request.proxy_id)
            else:
                proxy = db.query(Proxy).filter(Proxy.status == ProxyStatus.ACTIVE).first()

            # Run (Single instance for now)
            await reg_service.register(proxy)
            
    except Exception as e:
        logger.error(f"Task Failed: {e}")
    finally:
        await browser_manager.stop()

@router.post("/start")
async def start_registration(
    request: RegistrationRequest, 
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    captcha_service: CaptchaProvider = Depends(get_captcha_service),
    sms_service: GrizzlySMS = Depends(get_sms_service)
):
    background_tasks.add_task(run_registration_task, request, db, captcha_service, sms_service)
    return {"status": "started", "message": f"Starting {request.quantity} registration(s) for {request.provider}"}
