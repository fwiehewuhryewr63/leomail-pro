import React, { useState, useEffect } from 'react';
import { FileText, Plus, Sparkles, Trash2, Eye, Loader, X, Link } from 'lucide-react';

const API = 'http://localhost:8000/api';

export default function Templates() {
    const [templates, setTemplates] = useState([]);
    const [tab, setTab] = useState('list');
    const [loading, setLoading] = useState(false);
    const [preview, setPreview] = useState(null);
    const [name, setName] = useState('');
    const [subject, setSubject] = useState('');
    const [body, setBody] = useState('');
    const [aiTopic, setAiTopic] = useState('');
    const [aiLang, setAiLang] = useState('en');
    const [aiVariations, setAiVariations] = useState(5);
    const [languages, setLanguages] = useState([]);
    const [links, setLinks] = useState([]);
    const [selectedLinks, setSelectedLinks] = useState([]);

    const load = () => fetch(`${API}/templates/`).then(r => r.json()).then(setTemplates).catch(() => { });
    useEffect(() => {
        load();
        fetch(`${API}/geo/languages`).then(r => r.json()).then(setLanguages).catch(() => { });
        fetch(`${API}/links/`).then(r => r.json()).then(setLinks).catch(() => { });
    }, []);

    const toggleLink = (url) => {
        setSelectedLinks(prev => prev.includes(url) ? prev.filter(u => u !== url) : [...prev, url]);
    };

    const createManual = async () => {
        if (!name || !subject || !body) return;
        await fetch(`${API}/templates/`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, subject, body }) });
        setName(''); setSubject(''); setBody(''); setTab('list'); load();
    };

    const generateAI = async () => {
        if (!aiTopic) return;
        setLoading(true);
        try {
            const resp = await fetch(`${API}/templates/generate`, {
                method: 'POST', headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    topic: aiTopic,
                    tone: 'auto', // AI decides best tone automatically
                    language: aiLang,
                    links: selectedLinks.length > 0 ? selectedLinks : [],
                    variations: aiVariations
                })
            });
            const data = await resp.json();
            if (data.error) { alert(data.error); return; }
            setPreview(data); load();
        } finally { setLoading(false); }
    };

    const deleteTemplate = async (id) => { if (!confirm('Удалить шаблон?')) return; await fetch(`${API}/templates/${id}`, { method: 'DELETE' }); load(); };
    const viewTemplate = async (id) => setPreview(await (await fetch(`${API}/templates/${id}`)).json());

    const Tab = ({ id, icon, label }) => (
        <button onClick={() => setTab(id)} style={{
            padding: '8px 18px', borderRadius: 10, border: 'none', cursor: 'pointer', fontFamily: 'inherit',
            fontSize: '0.78em', fontWeight: 600, letterSpacing: 0.5, display: 'flex', alignItems: 'center', gap: 6,
            background: tab === id ? 'rgba(0,255,65,0.1)' : 'transparent',
            color: tab === id ? '#00ff41' : '#009922', transition: 'all 0.2s'
        }}>{icon} {label}</button>
    );

    return (
        <div className="page">
            <h2 className="page-title"><FileText size={22} /> Шаблоны</h2>

            <div style={{ display: 'flex', gap: 4, marginBottom: 16, background: 'rgba(255,255,255,0.02)', borderRadius: 12, padding: 4 }}>
                <Tab id="list" label="Список" />
                <Tab id="create" icon={<Plus size={13} />} label="Создать" />
                <Tab id="ai" icon={<Sparkles size={13} />} label="AI Генерация" />
            </div>

            {tab === 'list' && (
                templates.length === 0 ? (
                    <div className="card" style={{ textAlign: 'center', padding: 48, color: '#006611' }}>
                        <FileText size={36} style={{ opacity: 0.3, marginBottom: 12 }} /><br />Нет шаблонов. Создайте вручную или сгенерируйте через AI.
                    </div>
                ) : (
                    <div style={{ display: 'grid', gap: 8 }}>
                        {templates.map(t => (
                            <div key={t.id} className="card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <div style={{ flex: 1 }}>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                                        <span style={{ fontWeight: 600, fontSize: '0.9em' }}>{t.name}</span>
                                        {t.ai_generated && <span className="neon-tag neon-tag-cyan">AI</span>}
                                    </div>
                                    <div style={{ fontSize: '0.72em', color: '#006611', marginTop: 3 }}>
                                        {t.subject} · {t.language} · {t.variations_count} вар.
                                    </div>
                                </div>
                                <div style={{ display: 'flex', gap: 4 }}>
                                    <button className="btn btn-sm" onClick={() => viewTemplate(t.id)}><Eye size={13} /></button>
                                    <button className="btn btn-sm btn-danger" onClick={() => deleteTemplate(t.id)}><Trash2 size={13} /></button>
                                </div>
                            </div>
                        ))}
                    </div>
                )
            )}

            {tab === 'create' && (
                <div className="card">
                    <div className="card-title">Создать шаблон</div>
                    <div className="form-group"><label className="form-label">Название</label><input className="form-input" value={name} onChange={e => setName(e.target.value)} placeholder="Название шаблона..." /></div>
                    <div className="form-group"><label className="form-label">Тема письма</label><input className="form-input" value={subject} onChange={e => setSubject(e.target.value)} placeholder="Subject line..." /></div>
                    <div className="form-group"><label className="form-label">Тело (HTML)</label><textarea className="form-input" value={body} onChange={e => setBody(e.target.value)} placeholder="<p>Контент письма...</p>" rows={10} /></div>
                    <button className="btn btn-primary" onClick={createManual}>Сохранить</button>
                </div>
            )}

            {tab === 'ai' && (
                <div className="card">
                    <div className="card-title"><Sparkles size={13} style={{ marginRight: 6 }} /> AI Генератор писем</div>

                    {/* Auto-tone notice */}
                    <div style={{
                        padding: '10px 14px', borderRadius: 10, marginBottom: 16,
                        background: 'rgba(0,255,65,0.05)', border: '1px solid rgba(0,255,65,0.1)',
                        fontSize: '0.75em', color: '#00ff41', display: 'flex', alignItems: 'center', gap: 8
                    }}>
                        <Sparkles size={14} />
                        AI автоматически выбирает максимально эффективный тон для каждого шаблона
                    </div>

                    <div className="form-group"><label className="form-label">Тема / о чём письмо</label><input className="form-input" value={aiTopic} onChange={e => setAiTopic(e.target.value)} placeholder="Крипто-платформа с 300% доходностью..." /></div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                        <div className="form-group">
                            <label className="form-label">Язык</label>
                            <select className="form-input" value={aiLang} onChange={e => setAiLang(e.target.value)}>
                                {languages.length > 0 ? (
                                    languages.map(l => <option key={l.code} value={l.code}>{l.native_name || l.name}</option>)
                                ) : (
                                    <><option value="en">English</option><option value="es">Español</option><option value="pt">Português</option><option value="de">Deutsch</option><option value="ru">Русский</option></>
                                )}
                            </select>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Вариации</label>
                            <select className="form-input" value={aiVariations} onChange={e => setAiVariations(+e.target.value)}>
                                <option value={10}>10</option><option value={100}>100</option><option value={1000}>1 000</option><option value={10000}>10 000</option><option value={100000}>100 000</option><option value={1000000}>1 000 000</option>
                            </select>
                        </div>
                    </div>

                    {/* Link picker from existing links */}
                    <div className="form-group">
                        <label className="form-label"><Link size={12} /> Ссылки (выберите или добавьте)</label>
                        {links.length > 0 ? (
                            <div style={{
                                maxHeight: 140, overflow: 'auto', border: '1px solid rgba(255,255,255,0.06)',
                                borderRadius: 10, padding: 6
                            }}>
                                {links.map(l => (
                                    <div key={l.id} onClick={() => toggleLink(l.url)} style={{
                                        padding: '6px 10px', borderRadius: 6, cursor: 'pointer', fontSize: '0.78em',
                                        display: 'flex', alignItems: 'center', gap: 8, marginBottom: 2,
                                        background: selectedLinks.includes(l.url) ? 'rgba(0,255,65,0.08)' : 'transparent',
                                        color: selectedLinks.includes(l.url) ? '#00ff41' : '#009922',
                                        transition: 'all 0.15s'
                                    }}>
                                        <span style={{
                                            width: 14, height: 14, borderRadius: 4,
                                            border: `2px solid ${selectedLinks.includes(l.url) ? '#00ff41' : '#006611'}`,
                                            background: selectedLinks.includes(l.url) ? '#00ff41' : 'transparent',
                                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                                            fontSize: '0.7em', color: '#fff', flexShrink: 0
                                        }}>{selectedLinks.includes(l.url) ? '✓' : ''}</span>
                                        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{l.url}</span>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div style={{ fontSize: '0.75em', color: '#006611', padding: 10 }}>
                                Нет добавленных ссылок. Добавьте на странице Ссылки.
                            </div>
                        )}
                        {selectedLinks.length > 0 && (
                            <div style={{ fontSize: '0.68em', color: '#00ff41', marginTop: 4 }}>
                                Выбрано: {selectedLinks.length}
                            </div>
                        )}
                    </div>

                    <button className="btn btn-primary" onClick={generateAI} disabled={loading} style={{ width: '100%', padding: 14, borderRadius: 12 }}>
                        {loading ? <><Loader size={14} className="spin" /> Генерация...</> : <><Sparkles size={14} /> Сгенерировать</>}
                    </button>
                </div>
            )}

            {preview && (
                <div className="modal-overlay" onClick={() => setPreview(null)}>
                    <div className="card modal-content" onClick={e => e.stopPropagation()}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                            <div className="card-title" style={{ margin: 0 }}>Предпросмотр</div>
                            <button className="btn btn-sm" onClick={() => setPreview(null)}><X size={14} /></button>
                        </div>
                        <div style={{ fontSize: '0.82em', marginBottom: 8, color: '#009922' }}><strong>Subject:</strong> {preview.subject}</div>
                        <div style={{ background: '#05060a', padding: 20, borderRadius: 12, fontSize: '0.85em', lineHeight: 1.6, maxHeight: 400, overflow: 'auto', color: '#009922' }}
                            dangerouslySetInnerHTML={{ __html: preview.body }} />
                        {preview.variations_count > 1 && <div style={{ fontSize: '0.72em', color: '#006611', marginTop: 8 }}>{preview.variations_count} вариаций (spintax)</div>}
                    </div>
                </div>
            )}
        </div>
    );
}
