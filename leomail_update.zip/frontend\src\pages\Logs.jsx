import React from 'react';
import { Terminal as TermIcon } from 'lucide-react';

export default function Logs() {
    return (
        <div>
            <h2 className="page-title"><TermIcon size={24} /> SYSTEM LOGS</h2>

            <div className="card">
                <div className="terminal" style={{ maxHeight: 500, minHeight: 400 }}>
                    <div className="log-line">
                        <span className="log-time">[SYSTEM]</span> Leomail v0.1 initialized
                    </div>
                    <div className="log-line">
                        <span className="log-time">[SYSTEM]</span> Waiting for tasks...
                    </div>
                    <div className="log-line" style={{ opacity: 0.4 }}>
                        &gt; _
                    </div>
                </div>
            </div>
        </div>
    );
}
