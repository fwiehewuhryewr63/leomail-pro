import React, { useState, useEffect } from 'react';
import {
    Send, Play, Square, AlertTriangle, CheckCircle, XCircle,
    Clock, Shield, FileText, Link, Database, TrendingUp, Zap
} from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';

const API = 'http://localhost:8000/api';

export default function Work() {
    const { t } = useI18n();
    const [templates, setTemplates] = useState([]);
    const [databases, setDatabases] = useState([]);
    const [links, setLinks] = useState([]);
    const [farms, setFarms] = useState([]);
    const [templateId, setTemplateId] = useState('');
    const [dbId, setDbId] = useState('');
    const [linkId, setLinkId] = useState('');
    const [farmId, setFarmId] = useState('');
    const [speed, setSpeed] = useState(50);
    const [aiVariations, setAiVariations] = useState(true);
    const [running, setRunning] = useState(false);
    const [stats, setStats] = useState({ sent: 0, delivered: 0, bounced: 0, errors: 0 });
    const [issues, setIssues] = useState({ rate_limit: 0, mailer_daemon: 0, send_error: 0, suspended: 0, not_found: 0 });

    useEffect(() => {
        fetch(`${API}/templates/`).then(r => r.json()).then(d => setTemplates(Array.isArray(d) ? d : [])).catch(() => { });
        fetch(`${API}/databases/`).then(r => r.json()).then(d => setDatabases(Array.isArray(d) ? d : [])).catch(() => { });
        fetch(`${API}/links/`).then(r => r.json()).then(d => setLinks(Array.isArray(d) ? d : [])).catch(() => { });
        fetch(`${API}/farms/`).then(r => r.json()).then(d => setFarms(Array.isArray(d) ? d : [])).catch(() => { });
    }, []);

    const startWork = () => {
        setRunning(true);
        setStats({ sent: 0, delivered: 0, bounced: 0, errors: 0 });
        fetch(`${API}/birth/start`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                type: 'work',
                template_id: templateId,
                database_id: dbId,
                link_id: linkId || null,
                farm_id: farmId,
                speed: speed,
                ai_variations: aiVariations,
            })
        }).then(r => r.json()).catch(() => { });
    };

    const stopWork = () => {
        fetch(`${API}/birth/stop`, { method: 'POST' });
        setRunning(false);
    };

    // Issue categories with explanations
    const issueCards = [
        {
            key: 'rate_limit',
            label: t('issueRateLimit'),
            icon: Clock,
            color: 'var(--warning)',
            desc: 'Лимит отправки превышен → авто-пауза',
            critical: true,
        },
        {
            key: 'mailer_daemon',
            label: t('issueMailerDaemon'),
            icon: AlertTriangle,
            color: 'var(--danger)',
            desc: 'Ошибка доставки / bounce → учитывается',
            critical: true,
        },
        {
            key: 'send_error',
            label: 'Send Error',
            icon: XCircle,
            color: 'var(--danger)',
            desc: 'Ошибка отправки → учитывается',
            critical: true,
        },
        {
            key: 'suspended',
            label: t('issueSuspended'),
            icon: Shield,
            color: '#e74c3c',
            desc: 'Аккаунт заблокирован → исключён',
            critical: true,
        },
        {
            key: 'not_found',
            label: 'Recipient Not Found',
            icon: CheckCircle,
            color: 'var(--text-muted)',
            desc: 'Получатель не найден — НЕ штрафуется',
            critical: false,
        },
    ];

    return (
        <div className="page">
            <h2 className="page-title">
                <Send size={24} /> {t('workTitle')}
                {running && (
                    <span className="badge badge-success" style={{ marginLeft: 12 }}>
                        <Zap size={10} /> {t('running247')}
                    </span>
                )}
            </h2>

            {/* Settings */}
            <div className="card" style={{ marginBottom: 16 }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                    <div className="form-group">
                        <label className="form-label"><FileText size={12} /> {t('selectTemplate')}</label>
                        <select className="form-input" value={templateId} onChange={e => setTemplateId(e.target.value)}>
                            <option value="">— Select —</option>
                            {templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                        </select>
                    </div>

                    <div className="form-group">
                        <label className="form-label"><Database size={12} /> {t('targetDatabase')}</label>
                        <select className="form-input" value={dbId} onChange={e => setDbId(e.target.value)}>
                            <option value="">— Select —</option>
                            {databases.map(d => (
                                <option key={d.id} value={d.id}>
                                    {d.name} ({d.total_count - d.used_count} remaining)
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 12 }}>
                    <div className="form-group">
                        <label className="form-label"><Link size={12} /> LINKS DATABASE</label>
                        <select className="form-input" value={linkId} onChange={e => setLinkId(e.target.value)}>
                            <option value="">— No links —</option>
                            {links.map(l => <option key={l.id} value={l.id}>{l.name} ({l.url})</option>)}
                        </select>
                    </div>

                    <div className="form-group">
                        <label className="form-label">FARM (ACCOUNTS)</label>
                        <select className="form-input" value={farmId} onChange={e => setFarmId(e.target.value)}>
                            <option value="">— Select farm —</option>
                            {farms.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                        </select>
                    </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 12 }}>
                    <div className="form-group">
                        <label className="form-label">{t('sendingSpeed')}</label>
                        <input className="form-input" type="number" value={speed}
                            onChange={e => setSpeed(parseInt(e.target.value))} />
                    </div>

                    <div className="form-group">
                        <label className="form-label">{t('aiVariations')}</label>
                        <div className={`toggle-track ${aiVariations ? 'active' : ''}`} onClick={() => setAiVariations(!aiVariations)}>
                            <div className="toggle-knob" />
                        </div>
                    </div>
                </div>
            </div>

            {/* Live Stats when running */}
            {running && (
                <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 16 }}>
                    <div className="card">
                        <div className="card-title"><Send size={13} style={{ marginRight: 6 }} /> {t('sent')}</div>
                        <div className="card-value">{stats.sent}</div>
                    </div>
                    <div className="card">
                        <div className="card-title"><CheckCircle size={13} style={{ marginRight: 6, color: 'var(--success)' }} /> {t('delivered')}</div>
                        <div className="card-value" style={{ WebkitTextFillColor: 'var(--success)' }}>{stats.delivered}</div>
                    </div>
                    <div className="card">
                        <div className="card-title"><XCircle size={13} style={{ marginRight: 6, color: 'var(--danger)' }} /> {t('bounced')}</div>
                        <div className="card-value" style={{ WebkitTextFillColor: 'var(--danger)' }}>{stats.bounced}</div>
                    </div>
                    <div className="card">
                        <div className="card-title"><AlertTriangle size={13} style={{ marginRight: 6, color: 'var(--warning)' }} /> ERRORS</div>
                        <div className="card-value" style={{ WebkitTextFillColor: 'var(--warning)' }}>{stats.errors}</div>
                    </div>
                </div>
            )}

            {/* Issue Monitoring */}
            <div className="card" style={{ marginBottom: 16 }}>
                <div className="card-title"><AlertTriangle size={13} style={{ marginRight: 6 }} /> {t('accountIssues')}</div>
                <div style={{ fontSize: '0.78em', color: 'var(--text-muted)', marginBottom: 12 }}>
                    Все ошибки кроме "Recipient Not Found" → авто-исключение аккаунта
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 8 }}>
                    {issueCards.map(ic => (
                        <div key={ic.key} style={{
                            padding: '12px', borderRadius: 'var(--radius-sm)',
                            border: `1px solid ${ic.critical ? 'rgba(225,112,85,0.15)' : 'var(--border-subtle)'}`,
                            background: ic.critical ? 'rgba(225,112,85,0.03)' : 'transparent',
                        }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                                <ic.icon size={14} style={{ color: ic.color }} />
                                <span style={{ fontSize: '0.78em', fontWeight: 700, color: ic.color }}>{ic.label}</span>
                            </div>
                            <div style={{ fontSize: '1.4em', fontWeight: 800, color: ic.critical ? 'var(--danger)' : 'var(--text-muted)' }}>
                                {issues[ic.key] || 0}
                            </div>
                            <div style={{ fontSize: '0.68em', color: 'var(--text-muted)', marginTop: 4 }}>
                                {ic.desc}
                            </div>
                            {!ic.critical && (
                                <span className="badge badge-info" style={{ marginTop: 4, fontSize: '0.6em' }}>FORGIVEN</span>
                            )}
                        </div>
                    ))}
                </div>
            </div>

            {/* Start/Stop */}
            <div style={{ display: 'flex', gap: 12 }}>
                {running ? (
                    <button className="btn btn-danger" onClick={stopWork} style={{ padding: '14px 32px' }}>
                        <Square size={16} /> {t('stopWork')}
                    </button>
                ) : (
                    <button className="btn btn-primary" onClick={startWork} style={{ padding: '14px 32px' }}
                        disabled={!templateId || !dbId}>
                        <Play size={16} /> {t('startWork')}
                    </button>
                )}
            </div>
        </div>
    );
}
