import random
try:
    from playwright.async_api import async_playwright, BrowserContext, Page
    from playwright_stealth import Stealth
except ImportError:
    async_playwright = None
    BrowserContext = None
    Page = None
    Stealth = None
from loguru import logger
from ..models import Proxy

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/120.0.0.0 Safari/537.36"
]

class BrowserManager:
    def __init__(self, headless: bool = False):
        self.headless = headless
        self.playwright = None
        self.browser = None

    async def start(self):
        self.playwright = await async_playwright().start()
        # Launch Chrome (Channel="chrome" makes it look more legit than Chromium)
        self.browser = await self.playwright.chromium.launch(
            headless=self.headless,
            channel="chrome", 
            args=[
                "--disable-blink-features=AutomationControlled",
                "--no-sandbox"
            ]
        )
    
    async def stop(self):
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()

    async def create_context(self, proxy: Proxy = None) -> BrowserContext:
        proxy_config = None
        if proxy:
            proxy_config = {
                "server": proxy.to_string(), # Needs update in models.py to return clean string
            }
            # Handle auth separately if needed, but Playwright accepts username:password in server URL usually
            # Or split it:
            if proxy.username:
                proxy_config = {
                    "server": f"{proxy.protocol}://{proxy.host}:{proxy.port}",
                    "username": proxy.username,
                    "password": proxy.password
                }
            else:
                 proxy_config = {
                    "server": f"{proxy.protocol}://{proxy.host}:{proxy.port}"
                }

        user_agent = random.choice(USER_AGENTS)
        
        context = await self.browser.new_context(
            user_agent=user_agent,
            viewport={"width": 1920, "height": 1080},
            proxy=proxy_config,
            locale="en-US",
            timezone_id="America/New_York", # Should match proxy ideally
            permissions=["geolocation"]
        )
        
        # Apply Stealth
        stealth = Stealth()
        await stealth.apply_stealth_async(context)
        
        return context

    async def close_context(self, context: BrowserContext):
        await context.close()
