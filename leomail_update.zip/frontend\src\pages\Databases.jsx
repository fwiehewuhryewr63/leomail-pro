import React, { useState, useEffect } from 'react';
import { Database, Upload, Trash2, Eye, CheckCircle, X } from 'lucide-react';

const API = 'http://localhost:8000/api';

export default function Databases() {
    const [databases, setDatabases] = useState([]);
    const [showUpload, setShowUpload] = useState(false);
    const [uploadName, setUploadName] = useState('');
    const [uploadText, setUploadText] = useState('');
    const [preview, setPreview] = useState(null);

    const load = () => fetch(`${API}/databases/`).then(r => r.json()).then(setDatabases).catch(() => { });
    useEffect(() => { load(); }, []);

    const uploadDB = async () => {
        if (!uploadName || !uploadText.trim()) return;
        const emails = uploadText.split('\n').map(e => e.trim()).filter(e => e);
        const data = await (await fetch(`${API}/databases/upload`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: uploadName, emails }) })).json();
        if (data.error) { alert(data.error); return; }
        setUploadName(''); setUploadText(''); setShowUpload(false); load();
    };

    const deleteDB = async (id) => { if (!confirm('Удалить базу?')) return; await fetch(`${API}/databases/${id}`, { method: 'DELETE' }); load(); };
    const viewDB = async (id) => setPreview(await (await fetch(`${API}/databases/${id}`)).json());

    const handleFile = (e) => {
        const file = e.dataTransfer?.files[0] || e.target?.files[0];
        if (file) {
            if (!uploadName) setUploadName(file.name.replace(/\.[^/.]+$/, ""));
            const reader = new FileReader();
            reader.onload = (ev) => setUploadText(ev.target.result);
            reader.readAsText(file);
        }
    };

    return (
        <div className="page">
            <h2 className="page-title"><Database size={22} /> Базы получателей</h2>

            <button className="btn btn-primary" onClick={() => setShowUpload(!showUpload)} style={{ marginBottom: 16 }}>
                <Upload size={14} /> Загрузить базу
            </button>

            {showUpload && (
                <div className="card" style={{ marginBottom: 16 }}>
                    <div className="card-title">Загрузка email-ов</div>
                    <div className="form-group"><label className="form-label">Название</label><input className="form-input" value={uploadName} onChange={e => setUploadName(e.target.value)} placeholder="USA Finance 2024..." /></div>
                    <div className="form-group">
                        <label className="form-label">Email-ы (вставьте или перетащите файл)</label>
                        <div onDrop={e => { e.preventDefault(); handleFile(e); }} onDragOver={e => e.preventDefault()}
                            style={{ border: '2px dashed rgba(0,255,65,0.2)', borderRadius: 12, padding: 8 }}>
                            <textarea className="form-input" value={uploadText} onChange={e => setUploadText(e.target.value)}
                                placeholder="one@email.com&#10;two@email.com&#10;&#10;Или перетащите .txt/.csv файл сюда" rows={8}
                                style={{ border: 'none', fontFamily: 'JetBrains Mono, monospace', fontSize: '0.82em' }} />
                        </div>
                        <div style={{ fontSize: '0.7em', color: '#475569', marginTop: 6 }}>
                            {uploadText ? `${uploadText.split('\n').filter(l => l.trim()).length} строк` : 'Поддержка .txt и .csv'}
                        </div>
                    </div>
                    <input type="file" accept=".txt,.csv" onChange={handleFile} style={{ display: 'none' }} id="file-input" />
                    <div style={{ display: 'flex', gap: 8 }}>
                        <button className="btn btn-primary" onClick={uploadDB}><CheckCircle size={14} /> Загрузить</button>
                        <label htmlFor="file-input" className="btn" style={{ cursor: 'pointer' }}>Обзор файла</label>
                    </div>
                </div>
            )}

            {databases.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', padding: 48, color: '#475569' }}>
                    <Database size={36} style={{ opacity: 0.3, marginBottom: 12 }} /><br />Нет баз. Загрузите email-ы получателей.
                </div>
            ) : (
                <div style={{ display: 'grid', gap: 8 }}>
                    {databases.map(d => (
                        <div key={d.id} className="card">
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <div>
                                    <div style={{ fontWeight: 600, fontSize: '0.9em' }}>{d.name}</div>
                                    <div style={{ fontSize: '0.72em', color: '#475569', marginTop: 3 }}>
                                        {d.total_count.toLocaleString()} всего · {d.used_count.toLocaleString()} использовано · {d.remaining.toLocaleString()} осталось
                                        {d.invalid_count > 0 && <span style={{ color: '#ef4444' }}> · {d.invalid_count} невалидных</span>}
                                    </div>
                                </div>
                                <div style={{ display: 'flex', gap: 4 }}>
                                    <button className="btn btn-sm" onClick={() => viewDB(d.id)}><Eye size={13} /></button>
                                    <button className="btn btn-sm btn-danger" onClick={() => deleteDB(d.id)}><Trash2 size={13} /></button>
                                </div>
                            </div>
                            <div style={{ marginTop: 8, width: '100%', height: 4, background: '#030903', borderRadius: 2, overflow: 'hidden' }}>
                                <div style={{ width: `${d.total_count > 0 ? (d.used_count / d.total_count * 100) : 0}%`, height: '100%', background: 'linear-gradient(90deg, #00cc33, #009922)', borderRadius: 2 }} />
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {preview && (
                <div className="modal-overlay" onClick={() => setPreview(null)}>
                    <div className="card modal-content" onClick={e => e.stopPropagation()}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                            <div className="card-title" style={{ margin: 0 }}>{preview.name}</div>
                            <button className="btn btn-sm" onClick={() => setPreview(null)}><X size={14} /></button>
                        </div>
                        <div style={{ fontSize: '0.75em', color: '#475569', marginBottom: 12 }}>Первые {preview.preview?.length} из {preview.total_count}</div>
                        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '0.78em', maxHeight: 320, overflow: 'auto' }}>
                            {preview.preview?.map((e, i) => <div key={i} style={{ padding: '3px 0', borderBottom: '1px solid rgba(255,255,255,0.02)', color: '#94a3b8' }}>{e}</div>)}
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
