import React, { useState, useEffect } from 'react';
import { Layers, Cpu, MemoryStick, HardDrive, RefreshCw, AlertTriangle, CheckCircle } from 'lucide-react';

const API = 'http://localhost:8000/api';

export default function Threads() {
    const [health, setHealth] = useState(null);
    const [recs, setRecs] = useState({});

    const load = () => {
        fetch(`${API}/resources/health`).then(r => r.json()).then(setHealth);
        ['birth', 'warmup', 'work'].forEach(t =>
            fetch(`${API}/resources/threads/${t}`).then(r => r.json()).then(d => setRecs(p => ({ ...p, [t]: d })))
        );
    };
    useEffect(() => { load(); }, []);

    const statusColor = { healthy: '#22c55e', warning: '#f59e0b', critical: '#ef4444' };
    const statusLabels = { healthy: 'Здоров', warning: 'Нагрузка', critical: 'Перегрузка' };

    const Bar = ({ value, max, color }) => (
        <div style={{ height: 6, borderRadius: 3, background: '#030903', flex: 1, overflow: 'hidden' }}>
            <div style={{
                width: `${Math.min(100, (value / max) * 100)}%`, height: '100%', borderRadius: 3,
                background: `linear-gradient(90deg, ${color}80, ${color})`, transition: 'width 0.5s'
            }} />
        </div>
    );

    const taskMeta = {
        birth: { name: '🍼 Birth', desc: 'Браузер + прокси', memPerThread: '350MB', cpuPerThread: '50%' },
        warmup: { name: '🔥 Warmup', desc: 'IMAP/SMTP соединения', memPerThread: '80MB', cpuPerThread: '10%' },
        work: { name: '📨 Work', desc: 'SMTP отправка', memPerThread: '60MB', cpuPerThread: '5%' },
    };

    return (
        <div className="page">
            <h2 className="page-title"><Layers size={22} /> Потоки — Smart Threads</h2>

            {/* Server health */}
            <div className="card" style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    {health && (
                        <>
                            <div style={{
                                width: 10, height: 10, borderRadius: '50%',
                                background: statusColor[health.status] || '#475569',
                                boxShadow: `0 0 8px ${statusColor[health.status] || '#475569'}60`,
                                animation: health.status === 'critical' ? 'pulse 1s infinite' : undefined
                            }} />
                            <span style={{ fontWeight: 600, color: statusColor[health.status] }}>
                                Сервер: {statusLabels[health.status]}
                            </span>
                        </>
                    )}
                </div>
                <button className="btn btn-sm" onClick={load}><RefreshCw size={13} /> Обновить</button>
            </div>

            {/* Resources bars */}
            {health?.resources && (
                <div className="card" style={{ marginBottom: 16 }}>
                    <div className="card-title">Ресурсы сервера</div>
                    <div style={{ display: 'grid', gap: 12 }}>
                        {/* RAM */}
                        <div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.78em', marginBottom: 4 }}>
                                <span style={{ color: '#94a3b8' }}>RAM</span>
                                <span style={{ color: health.resources.ram_used_percent > 80 ? '#ef4444' : '#94a3b8' }}>
                                    {health.resources.ram_available_mb} MB свободно / {health.resources.ram_total_mb} MB ({health.resources.ram_used_percent}%)
                                </span>
                            </div>
                            <Bar value={health.resources.ram_used_percent} max={100}
                                color={health.resources.ram_used_percent > 80 ? '#ef4444' : health.resources.ram_used_percent > 60 ? '#f59e0b' : '#22c55e'} />
                        </div>
                        {/* CPU */}
                        <div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.78em', marginBottom: 4 }}>
                                <span style={{ color: '#94a3b8' }}>CPU</span>
                                <span style={{ color: health.resources.cpu_used_percent > 80 ? '#ef4444' : '#94a3b8' }}>
                                    {health.resources.cpu_cores} ядер · {health.resources.cpu_used_percent}% загрузка
                                </span>
                            </div>
                            <Bar value={health.resources.cpu_used_percent} max={100}
                                color={health.resources.cpu_used_percent > 80 ? '#ef4444' : health.resources.cpu_used_percent > 60 ? '#f59e0b' : '#22c55e'} />
                        </div>
                    </div>
                </div>
            )}

            {/* Thread recommendations by type */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
                {['birth', 'warmup', 'work'].map(type => {
                    const rec = recs[type];
                    const meta = taskMeta[type];
                    return (
                        <div key={type} className="card">
                            <div style={{ fontSize: '1.2em', marginBottom: 8 }}>{meta.name}</div>
                            <div style={{ fontSize: '0.72em', color: '#475569', marginBottom: 12 }}>{meta.desc}</div>

                            {rec ? (
                                <>
                                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
                                        <div>
                                            <span style={{ fontSize: '2em', fontWeight: 700, color: '#00cc33' }}>{rec.recommended}</span>
                                            <span style={{ fontSize: '0.72em', color: '#475569', marginLeft: 6 }}>рекомендуется</span>
                                        </div>
                                        <span style={{ fontSize: '0.72em', color: '#475569' }}>макс: {rec.absolute_max}</span>
                                    </div>

                                    <div style={{ fontSize: '0.68em', color: '#94a3b8', lineHeight: 1.8, borderTop: '1px solid rgba(255,255,255,0.03)', paddingTop: 8 }}>
                                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                            <span>По RAM</span><span>{rec.details.ram_limit}</span>
                                        </div>
                                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                            <span>По CPU</span><span>{rec.details.cpu_limit}</span>
                                        </div>
                                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                            <span>По прокси</span><span>{rec.details.proxy_limit}</span>
                                        </div>
                                        <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600, marginTop: 4 }}>
                                            <span>Лимит</span><span style={{ color: '#f59e0b' }}>{rec.limiting_factor}</span>
                                        </div>
                                    </div>

                                    <div style={{ fontSize: '0.65em', color: '#334155', marginTop: 8 }}>
                                        {meta.memPerThread}/поток · {meta.cpuPerThread} CPU/поток
                                    </div>
                                </>
                            ) : (
                                <div style={{ color: '#475569', fontSize: '0.82em' }}>Загрузка...</div>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
}
