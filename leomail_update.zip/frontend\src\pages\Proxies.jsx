import React, { useState, useEffect, useRef } from 'react';
import { Shield, Upload, Trash2, RefreshCw, CheckCircle, XCircle, Clock, Wifi, WifiOff } from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';

const API = 'http://localhost:8000/api';

export default function Proxies() {
    const { t } = useI18n();
    const [proxies, setProxies] = useState([]);
    const [loading, setLoading] = useState(false);
    const [checking, setChecking] = useState(false);
    const [dragover, setDragover] = useState(false);
    const [uploadText, setUploadText] = useState('');
    const [showUpload, setShowUpload] = useState(false);
    const [proxyType, setProxyType] = useState('residential');
    const [protocol, setProtocol] = useState('socks5');
    const [geo, setGeo] = useState('');
    const fileRef = useRef();

    useEffect(() => { loadProxies(); }, []);

    const loadProxies = () => {
        fetch(`${API}/proxies/`)
            .then(r => r.json())
            .then(d => setProxies(Array.isArray(d) ? d : []))
            .catch(() => { });
    };

    const parseProxyLines = (text) => {
        return text.trim().split('\n').map(l => l.trim()).filter(l => l && l.includes(':'));
    };

    const handleUpload = () => {
        const lines = parseProxyLines(uploadText);
        if (lines.length === 0) return;
        setLoading(true);
        fetch(`${API}/proxies/import`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                proxies: lines,
                protocol: protocol,
                proxy_type: proxyType,
                geo: geo || null,
            })
        })
            .then(r => r.json())
            .then(() => { loadProxies(); setUploadText(''); setShowUpload(false); })
            .catch(() => { })
            .finally(() => setLoading(false));
    };

    const handleFile = (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => { setUploadText(ev.target.result); setShowUpload(true); };
        reader.readAsText(file);
    };

    const handleDrop = (e) => {
        e.preventDefault();
        setDragover(false);
        const file = e.dataTransfer.files?.[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => { setUploadText(ev.target.result); setShowUpload(true); };
        reader.readAsText(file);
    };

    const checkAll = () => {
        setChecking(true);
        fetch(`${API}/proxies/check`, { method: 'POST' })
            .then(r => r.json())
            .then(() => { setTimeout(loadProxies, 3000); })
            .catch(() => { })
            .finally(() => setTimeout(() => setChecking(false), 3000));
    };

    const deleteProxy = (id) => {
        fetch(`${API}/proxies/${id}`, { method: 'DELETE' })
            .then(() => loadProxies())
            .catch(() => { });
    };

    const deleteAll = () => {
        fetch(`${API}/proxies/all`, { method: 'DELETE' })
            .then(() => { setProxies([]); loadProxies(); })
            .catch(() => { });
    };

    const alive = proxies.filter(p => p.status === 'active').length;
    const dead = proxies.filter(p => p.status === 'dead').length;
    const total = proxies.length;

    return (
        <div className="page">
            <h2 className="page-title">
                <Shield size={24} /> {t('proxyManager')}
            </h2>

            {/* Stats */}
            <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
                <div className="card">
                    <div className="card-title"><Wifi size={13} style={{ marginRight: 6, color: 'var(--accent)' }} /> {t('totalProxies')}</div>
                    <div className="card-value">{total}</div>
                </div>
                <div className="card">
                    <div className="card-title"><CheckCircle size={13} style={{ marginRight: 6, color: 'var(--success)' }} /> {t('alive')}</div>
                    <div className="card-value" style={{ WebkitTextFillColor: 'var(--success)' }}>{alive}</div>
                </div>
                <div className="card">
                    <div className="card-title"><XCircle size={13} style={{ marginRight: 6, color: 'var(--danger)' }} /> {t('dead')}</div>
                    <div className="card-value" style={{ WebkitTextFillColor: 'var(--danger)' }}>{dead}</div>
                </div>
            </div>

            {/* Actions */}
            <div style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap' }}>
                <button className="btn btn-primary" onClick={() => setShowUpload(!showUpload)}>
                    <Upload size={15} /> {t('uploadProxies')}
                </button>
                <button className="btn btn-success" onClick={checkAll} disabled={checking || total === 0}>
                    <RefreshCw size={15} className={checking ? 'spin' : ''} /> {checking ? t('checking') : t('checkAll')}
                </button>
                {total > 0 && (
                    <button className="btn btn-danger" onClick={deleteAll}>
                        <Trash2 size={15} /> {t('deleteAll')}
                    </button>
                )}
                <input type="file" ref={fileRef} accept=".txt" style={{ display: 'none' }} onChange={handleFile} />
            </div>

            {/* Upload zone */}
            {showUpload && (
                <div className="card" style={{ marginBottom: 16 }}>
                    <div className="card-title"><Upload size={13} style={{ marginRight: 6 }} /> {t('addProxies')}</div>

                    {/* Import settings */}
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 12 }}>
                        <div className="form-group">
                            <label className="form-label">PROTOCOL</label>
                            <select className="form-input" value={protocol} onChange={e => setProtocol(e.target.value)}>
                                <option value="socks5">SOCKS5</option>
                                <option value="http">HTTP</option>
                                <option value="https">HTTPS</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label className="form-label">{t('type')}</label>
                            <select className="form-input" value={proxyType} onChange={e => setProxyType(e.target.value)}>
                                <option value="mobile">Mobile</option>
                                <option value="residential">Residential</option>
                                <option value="isp">ISP</option>
                                <option value="datacenter">Datacenter</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label className="form-label">GEO</label>
                            <input className="form-input" value={geo} onChange={e => setGeo(e.target.value)} placeholder="US, DE..." />
                        </div>
                    </div>

                    <div
                        className={`upload-zone ${dragover ? 'dragover' : ''}`}
                        onDragOver={e => { e.preventDefault(); setDragover(true); }}
                        onDragLeave={() => setDragover(false)}
                        onDrop={handleDrop}
                        onClick={() => fileRef.current?.click()}
                        style={{ marginBottom: 12 }}
                    >
                        <Upload size={28} />
                        <p>{t('dropFileHere')}</p>
                        <span>{t('proxyFormat')}</span>
                    </div>

                    <div className="form-label">{t('orPasteManually')}</div>
                    <textarea
                        className="form-input"
                        rows={6}
                        placeholder="ip:port:login:password&#10;ip:port:login:password&#10;..."
                        value={uploadText}
                        onChange={e => setUploadText(e.target.value)}
                    />

                    <div style={{ display: 'flex', gap: 8, marginTop: 12, alignItems: 'center' }}>
                        <button className="btn btn-primary" onClick={handleUpload} disabled={!uploadText.trim() || loading}>
                            {loading ? t('adding') : t('addToDatabase')}
                        </button>
                        <span style={{ fontSize: '0.8em', color: 'var(--text-muted)' }}>
                            {uploadText.trim() ? `${parseProxyLines(uploadText).length} ${t('proxiesDetected')}` : ''}
                        </span>
                    </div>
                </div>
            )}

            {/* Proxy Table */}
            {total > 0 && (
                <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
                    <table className="data-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>{t('host')}</th>
                                <th>{t('port')}</th>
                                <th>{t('type')}</th>
                                <th>{t('status')}</th>
                                <th>{t('responseTime')}</th>
                                <th>GEO</th>
                                <th>BOUND</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            {proxies.map((p, i) => (
                                <tr key={p.id || i}>
                                    <td style={{ color: 'var(--text-muted)', fontSize: '0.8em' }}>{i + 1}</td>
                                    <td style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '0.85em' }}>{p.host}</td>
                                    <td style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '0.85em' }}>{p.port}</td>
                                    <td><span className="badge badge-accent">{(p.proxy_type || 'RES').toUpperCase()}</span></td>
                                    <td>
                                        {p.status === 'active' ? (
                                            <span className="badge badge-success"><CheckCircle size={10} /> ALIVE</span>
                                        ) : p.status === 'dead' ? (
                                            <span className="badge badge-danger"><XCircle size={10} /> DEAD</span>
                                        ) : (
                                            <span className="badge badge-warning"><Clock size={10} /> {p.status || '—'}</span>
                                        )}
                                    </td>
                                    <td style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: '0.85em', color: 'var(--text-muted)' }}>
                                        {p.response_time_ms ? `${p.response_time_ms}ms` : '—'}
                                    </td>
                                    <td style={{ fontSize: '0.85em' }}>{p.geo || '—'}</td>
                                    <td style={{ fontSize: '0.78em', color: 'var(--text-muted)' }}>{p.bound_to || '—'}</td>
                                    <td>
                                        <button className="btn btn-sm btn-danger" onClick={() => deleteProxy(p.id)}>
                                            <Trash2 size={12} />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}

            {total === 0 && !showUpload && (
                <div className="card" style={{ textAlign: 'center', padding: 48 }}>
                    <WifiOff size={40} style={{ color: 'var(--text-muted)', marginBottom: 12 }} />
                    <p style={{ color: 'var(--text-secondary)', fontSize: '0.95em', fontWeight: 600 }}>{t('noProxies')}</p>
                    <p style={{ color: 'var(--text-muted)', fontSize: '0.82em', marginTop: 4 }}>{t('uploadToStart')}</p>
                </div>
            )}
        </div>
    );
}
