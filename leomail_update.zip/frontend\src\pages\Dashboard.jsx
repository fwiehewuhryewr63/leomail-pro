import React, { useState, useEffect } from 'react';
import {
    LayoutDashboard, Users, Baby, Flame, Send, Activity,
    Shield, FileText, Zap, ArrowRight, TrendingUp
} from 'lucide-react';
import { useI18n } from '../i18n/I18nContext';
import { useNavigate } from 'react-router-dom';

const API = 'http://localhost:8000/api';

export default function Dashboard() {
    const [s, setS] = useState({});
    const { t } = useI18n();
    const navigate = useNavigate();

    useEffect(() => {
        fetch(`${API}/dashboard/stats`)
            .then(r => r.json())
            .then(setS)
            .catch(() => { });
    }, []);

    const cards = [
        { label: t('totalAccounts'), value: s.total_accounts || 0, icon: Users, onClick: () => navigate('/accounts') },
        { label: t('totalFarms'), value: s.total_farms || 0, icon: Flame, onClick: () => navigate('/farms') },
        { label: t('totalProxies'), value: s.total_proxies || 0, icon: Shield, onClick: () => navigate('/proxies') },
        { label: t('totalTemplates'), value: s.total_templates || 0, icon: FileText, onClick: () => navigate('/templates') },
    ];

    const lifecycle = [
        { label: t('statusNew'), count: s.status_new || 0, color: 'var(--info)' },
        { label: t('statusWarmup'), count: s.status_warmup || 0, color: 'var(--warning)' },
        { label: t('statusReady'), count: s.status_ready || 0, color: 'var(--success)' },
        { label: t('statusWorking'), count: s.status_working || 0, color: 'var(--accent)' },
        { label: t('statusPaused'), count: s.status_paused || 0, color: 'var(--text-muted)' },
        { label: t('statusDead'), count: s.status_dead || 0, color: 'var(--danger)' },
    ];

    const totalLife = lifecycle.reduce((a, l) => a + l.count, 0) || 1;

    return (
        <div className="page">
            <h2 className="page-title">
                <LayoutDashboard size={24} /> {t('dashboardTitle')}
                <span style={{
                    marginLeft: 'auto', fontSize: '0.42em', fontWeight: 600,
                    color: 'var(--text-muted)', letterSpacing: 2
                }}>v2.3</span>
            </h2>

            {/* Stats grid */}
            <div className="stats-grid">
                {cards.map((c, i) => (
                    <div key={i} className="card card-clickable" onClick={c.onClick}>
                        <div className="card-title">
                            <c.icon size={13} style={{ marginRight: 6, color: 'var(--accent)' }} /> {c.label}
                        </div>
                        <div className="card-value">{c.value}</div>
                    </div>
                ))}
            </div>

            {/* Lifecycle */}
            <div className="card" style={{ marginBottom: 16 }}>
                <div className="card-title">
                    <Activity size={14} style={{ marginRight: 6, color: 'var(--accent)' }} />
                    {t('lifecycleTitle')}
                </div>

                {/* Bar */}
                <div style={{
                    height: 10, borderRadius: 5, overflow: 'hidden',
                    display: 'flex', marginBottom: 16,
                    background: 'rgba(255,255,255,0.04)'
                }}>
                    {lifecycle.map((l, i) => l.count > 0 ? (
                        <div key={i} style={{
                            width: `${(l.count / totalLife) * 100}%`,
                            background: l.color,
                            transition: 'width 0.6s ease'
                        }} />
                    ) : null)}
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
                    {lifecycle.map((l, i) => (
                        <div key={i} style={{ textAlign: 'center', minWidth: 70 }}>
                            <div style={{ fontSize: '0.68em', color: 'var(--text-muted)', letterSpacing: 1.2, fontWeight: 700, textTransform: 'uppercase' }}>{l.label}</div>
                            <div style={{ fontSize: '1.3em', fontWeight: 800, color: l.color }}>{l.count}</div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Quick Actions */}
            <div className="action-grid">
                <div className="action-card" onClick={() => navigate('/birth')}>
                    <Zap size={28} />
                    <h3>{t('birth')}</h3>
                    <p>{t('registerAccounts')}</p>
                </div>
                <div className="action-card" onClick={() => navigate('/warmup')}>
                    <TrendingUp size={28} />
                    <h3>{t('warmup')}</h3>
                    <p>{t('warmupAccounts')}</p>
                </div>
                <div className="action-card" onClick={() => navigate('/work')}>
                    <Send size={28} />
                    <h3>{t('work')}</h3>
                    <p>{t('startMailing')}</p>
                </div>
                <div className="action-card" onClick={() => navigate('/proxies')}>
                    <Shield size={28} />
                    <h3>{t('proxies')}</h3>
                    <p>{t('manageProxies')}</p>
                </div>
            </div>
        </div>
    );
}
