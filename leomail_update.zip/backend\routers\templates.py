from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import get_db
from ..models import Template
from ..schemas import TemplateCreate, TemplateAIGenerate
from ..services.ai_provider import get_ai_provider
from loguru import logger

router = APIRouter(prefix="/api/templates", tags=["templates"])


@router.get("/")
async def list_templates(db: Session = Depends(get_db)):
    templates = db.query(Template).order_by(Template.created_at.desc()).all()
    return [
        {
            "id": t.id,
            "name": t.name,
            "subject": t.subject,
            "content_type": t.content_type,
            "ai_generated": t.ai_generated,
            "language": t.language,
            "variations_count": t.variations_count,
            "created_at": t.created_at.isoformat() if t.created_at else None,
            "body_preview": t.body[:200] if t.body else ""
        }
        for t in templates
    ]


@router.post("/")
async def create_template(req: TemplateCreate, db: Session = Depends(get_db)):
    template = Template(
        name=req.name,
        subject=req.subject,
        body=req.body,
        content_type=req.content_type,
        language=req.language,
        ai_generated=False
    )
    db.add(template)
    db.commit()
    db.refresh(template)
    return {"id": template.id, "status": "created"}


@router.get("/{template_id}")
async def get_template(template_id: int, db: Session = Depends(get_db)):
    t = db.query(Template).filter(Template.id == template_id).first()
    if not t:
        return {"error": "Template not found"}
    return {
        "id": t.id,
        "name": t.name,
        "subject": t.subject,
        "body": t.body,
        "content_type": t.content_type,
        "ai_generated": t.ai_generated,
        "language": t.language,
        "variations_count": t.variations_count,
    }


@router.delete("/{template_id}")
async def delete_template(template_id: int, db: Session = Depends(get_db)):
    t = db.query(Template).filter(Template.id == template_id).first()
    if not t:
        return {"error": "Template not found"}
    db.delete(t)
    db.commit()
    return {"status": "deleted"}


@router.post("/generate")
async def ai_generate_template(req: TemplateAIGenerate, db: Session = Depends(get_db)):
    """Use AI to generate email template with spintax variations."""
    provider = get_ai_provider()
    if not provider:
        return {"error": "AIML API key not configured. Add it in Settings."}

    # Build prompt
    links_text = ""
    if req.links:
        links_text = f"\nPartner links to weave into the email naturally: {', '.join(req.links)}"

    system = (
        "You are an expert email copywriter. Generate a professional email template.\n"
        "Output EXACTLY in this format:\n"
        "SUBJECT: <subject line>\n\n"
        "<email body in HTML format>\n\n"
        "The email should feel personal, not spammy. Use proper HTML formatting.\n"
        f"Language: {req.language}. Tone: {req.tone}.\n"
        f"{links_text}\n"
        "IMPORTANT: Make the partner links look organic, not like ads."
    )

    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": f"Write an email about: {req.topic}"}
    ]

    result = provider.chat(messages)
    if result.get("error"):
        return result

    content = result.get("content", "")

    # Parse subject and body
    subject = "Generated Email"
    body = content
    if "SUBJECT:" in content:
        parts = content.split("\n", 1)
        subject_line = parts[0].replace("SUBJECT:", "").strip()
        if subject_line:
            subject = subject_line
        if len(parts) > 1:
            body = parts[1].strip()

    # Save template
    template = Template(
        name=f"AI: {req.topic[:50]}",
        subject=subject,
        body=body,
        content_type="html",
        ai_generated=True,
        language=req.language,
        variations_count=1
    )
    db.add(template)
    db.commit()
    db.refresh(template)

    # Generate variations if requested
    if req.variations > 1:
        variations_prompt = (
            f"Now create {req.variations - 1} more variations of the same email. "
            "Each variation should convey the same message but use different wording, "
            "structure, and phrasing. Use spintax format: {{option1|option2|option3}} "
            "to combine all variations into a single template.\n"
            "Return ONLY the spintax version of the body (no subject)."
        )
        var_result = provider.chat([
            {"role": "system", "content": system},
            {"role": "user", "content": f"Original email:\n{body}\n\n{variations_prompt}"}
        ])
        if not var_result.get("error"):
            template.body = var_result.get("content", body)
            template.variations_count = req.variations
            db.commit()

    return {
        "id": template.id,
        "subject": subject,
        "body": template.body,
        "variations_count": template.variations_count,
        "status": "generated"
    }
